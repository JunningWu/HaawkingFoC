//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################

#ifndef F28004X_SDFM_DEFINES_H
#define F28004X_SDFM_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

//
// Macro to read the SDFM1 filter data in 16 bit format
//
#define SDFM1_READ_FILTER1_DATA_16BIT     (((*(volatile Uint32 *)((Uint32)0xC42C)) >> 16) & 0xFFFF)
#define SDFM1_READ_FILTER2_DATA_16BIT     (((*(volatile Uint32 *)((Uint32)0xC45C)) >> 16) & 0xFFFF)
#define SDFM1_READ_FILTER3_DATA_16BIT     (((*(volatile Uint32 *)((Uint32)0xC48C)) >> 16) & 0xFFFF)
#define SDFM1_READ_FILTER4_DATA_16BIT     (((*(volatile Uint32 *)((Uint32)0xC4BC)) >> 16) & 0xFFFF)

//
// Macro to read the SDFM1 filter data in 32 bit format
//
#define SDFM1_READ_FILTER1_DATA_32BIT    (*(volatile Uint32 *)((Uint32)0xC42C))
#define SDFM1_READ_FILTER2_DATA_32BIT    (*(volatile Uint32 *)((Uint32)0xC45C))
#define SDFM1_READ_FILTER3_DATA_32BIT    (*(volatile Uint32 *)((Uint32)0xC48C))
#define SDFM1_READ_FILTER4_DATA_32BIT    (*(volatile Uint32 *)((Uint32)0xC4BC))

#ifdef __cplusplus
}
#endif /* extern "C" */

#endif   // - end of F28004X_SDFM_DEFINES_H

//
// End of file
//
