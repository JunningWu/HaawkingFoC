//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################

#ifndef F28004x_SYSCTRL_DEFINES_H
#define F28004x_SYSCTRL_DEFINES_H

//
// Defines
//
#define LPM_IDLE    0x0
#define LPM_HALT    0x2
#define LPM_HIB     0x3

#endif  // end of F28004x_SYSCTRL_DEFINES_H definition

//
// End of file.
//


