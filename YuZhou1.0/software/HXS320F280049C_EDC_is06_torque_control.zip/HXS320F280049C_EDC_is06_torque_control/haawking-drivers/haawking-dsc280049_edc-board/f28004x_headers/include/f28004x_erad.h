//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:13:45.523001
//
//#############################################################################


#ifndef F28004X_ERAD_H
#define F28004X_ERAD_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// ERAD Individual Register Bit Definitions:

struct GLBL_EVENT_STAT_BITS {                 // bits description
    Uint32 HWBP1:1;                           // 0 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP2:1;                           // 1 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP3:1;                           // 2 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP4:1;                           // 3 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP5:1;                           // 4 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP6:1;                           // 5 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP7:1;                           // 6 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 HWBP8:1;                           // 7 Enhanced Bus Comparator (EBC) Module Event Status
    Uint32 CTM1:1;                            // 8 Counter Module Event Status
    Uint32 CTM2:1;                            // 9 Counter Module Event Status
    Uint32 CTM3:1;                            // 10 Counter Module Event Status
    Uint32 CTM4:1;                            // 11 Counter Module Event Status
    Uint32 rsvd1:20;                          // 31:12 Reserved
};

union GLBL_EVENT_STAT_REG {
    Uint32  all;
    struct  GLBL_EVENT_STAT_BITS  bit;
};

struct GLBL_HALT_STAT_BITS {                  // bits description
    Uint32 HWBP1:1;                           // 0 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP2:1;                           // 1 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP3:1;                           // 2 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP4:1;                           // 3 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP5:1;                           // 4 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP6:1;                           // 5 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP7:1;                           // 6 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 HWBP8:1;                           // 7 Enhanced Bus Comparator (EBC) Module Halt Status
    Uint32 CTM1:1;                            // 8 Counter Module Halt Status
    Uint32 CTM2:1;                            // 9 Counter Module Halt Status
    Uint32 CTM3:1;                            // 10 Counter Module Halt Status
    Uint32 CTM4:1;                            // 11 Counter Module Halt Status
    Uint32 rsvd1:20;                          // 31:12 Reserved
};

union GLBL_HALT_STAT_REG {
    Uint32  all;
    struct  GLBL_HALT_STAT_BITS  bit;
};

struct GLBL_ENABLE_BITS {                     // bits description
    Uint32 HWBP1:1;                           // 0 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP2:1;                           // 1 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP3:1;                           // 2 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP4:1;                           // 3 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP5:1;                           // 4 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP6:1;                           // 5 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP7:1;                           // 6 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 HWBP8:1;                           // 7 Enhanced Bus Comparator (EBC) Module Global Enable
    Uint32 CTM1:1;                            // 8 Counter Module Global Enable
    Uint32 CTM2:1;                            // 9 Counter Module Global Enable
    Uint32 CTM3:1;                            // 10 Counter Module Global Enable
    Uint32 CTM4:1;                            // 11 Counter Module Global Enable
    Uint32 rsvd1:20;                          // 31:12 Reserved
};

union GLBL_ENABLE_REG {
    Uint32  all;
    struct  GLBL_ENABLE_BITS  bit;
};

struct GLBL_CTM_RESET_BITS {                  // bits description
    Uint32 CTM1:1;                            // 0 Global Reset for the counters
    Uint32 CTM2:1;                            // 1 Global Reset for the counters
    Uint32 CTM3:1;                            // 2 Global Reset for the counters
    Uint32 CTM4:1;                            // 3 Global Reset for the counters
    Uint32 rsvd1:28;                          // 31:4 Reserved
};

union GLBL_CTM_RESET_REG {
    Uint32  all;
    struct  GLBL_CTM_RESET_BITS  bit;
};

struct GLBL_OWNER_BITS {                      // bits description
    Uint32 OWNER:2;                           // 1:0 Global Ownership Bits
    Uint32 rsvd1:30;                          // 31:2 Reserved
};

union GLBL_OWNER_REG {
    Uint32  all;
    struct  GLBL_OWNER_BITS  bit;
};

struct  ERAD_GLOBAL_REGS {
    union   GLBL_EVENT_STAT_REG              GLBL_EVENT_STAT;             // 0x0 Global Event Status Register
    union   GLBL_HALT_STAT_REG               GLBL_HALT_STAT;              // 0x4 Global Halt Status Register
    union   GLBL_ENABLE_REG                  GLBL_ENABLE;                 // 0x8 Global Enable Register
    union   GLBL_CTM_RESET_REG               GLBL_CTM_RESET;              // 0xc Global Counter Reset
    Uint32                                   rsvd1;                       // 0x10 Reserved
    union   GLBL_OWNER_REG                   GLBL_OWNER;                  // 0x14 Global Ownership
    Uint32                                   rsvd2[4];                    // 0x18 Reserved
    Uint32                                   GLBL_HWBP_CMP_CNTL;          // 0x28  
};

struct HWBP_CLEAR_BITS {                      // bits description
    Uint32 EVENT_CLR:1;                       // 0 Event Clear register
    Uint32 rsvd1:31;                          // 31:1 Reserved
};

union HWBP_CLEAR_REG {
    Uint32  all;
    struct  HWBP_CLEAR_BITS  bit;
};

struct HWBP_CNTL_BITS {                       // bits description
    Uint32 rsvd1:2;                           // 1:0 Reserved
    Uint32 BUS_SEL:3;                         // 4:2 Bus select bits
    Uint32 STOP:1;                            // 5 Stop bit (Halt/No Halt of CPU)
    Uint32 RTOSINT:1;                         // 6 RTOSINT bit
    Uint32 COMP_MODE:3;                       // 9:7 Compare mode
    Uint32 rsvd2:22;                          // 31:10 Reserved
};

union HWBP_CNTL_REG {
    Uint32  all;
    struct  HWBP_CNTL_BITS  bit;
};

struct HWBP_STATUS_BITS {                     // bits description
    Uint32 EVENT_FIRED:1;                     // 0 HWBP (EBC) Event Fired bits
    Uint32 rsvd1:7;                           // 7:1 Reserved
    Uint32 MODULE_ID:6;                       // 13:8 Identification bits
    Uint32 STATUS:2;                          // 15:14 Status bits
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union HWBP_STATUS_REG {
    Uint32  all;
    struct  HWBP_STATUS_BITS  bit;
};

struct  ERAD_HWBP_REGS {
    Uint32                                   HWBP_MASK;                   // 0x0 HWBP (EBC) Mask Register
    Uint32                                   HWBP_REF;                    // 0x4 HWBP (EBC) Reference Register
    union   HWBP_CLEAR_REG                   HWBP_CLEAR;                  // 0x8 HWBP (EBC) Clear Register
    union   HWBP_CNTL_REG                    HWBP_CNTL;                   // 0xc HWBP (EBC) Control Register
    union   HWBP_STATUS_REG                  HWBP_STATUS;                 // 0x10 HWBP (EBC) Status Register
};

struct CTM_CNTL_BITS {                        // bits description
    Uint32 rsvd1:2;                           // 1:0 Reserved
    Uint32 START_STOP_MODE:1;                 // 2 Start_stop mode bit
    Uint32 EVENT_MODE:1;                      // 3 Event mode bit
    Uint32 RST_ON_MATCH:1;                    // 4 Reset_on_match bit
    Uint32 rsvd2:1;                           // 5 Reserved
    Uint32 STOP:1;                            // 6 Stop bit (Halt/No Halt of CPU)
    Uint32 RTOSINT:1;                         // 7 RTOSINT bit
    Uint32 rsvd3:1;                           // 8 Reserved
    Uint32 rsvd4:1;                           // 9 Reserved
    Uint32 RST_EN:1;                          // 10 Enable Reset
    Uint32 RST_INP_SEL:5;                     // 15:11 Reset Input select
    Uint32 rsvd5:16;                          // 31:16 Reserved
};

union CTM_CNTL_REG {
    Uint32  all;
    struct  CTM_CNTL_BITS  bit;
};

struct CTM_STATUS_BITS {                      // bits description
    Uint32 EVENT_FIRED:1;                     // 0 Counter Event Fired bits
    Uint32 OVERFLOW:1;                        // 1 Counter Overflowed
    Uint32 MODULE_ID:10;                      // 11:2 Identification bits
    Uint32 STATUS:4;                          // 15:12 Status bits
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union CTM_STATUS_REG {
    Uint32  all;
    struct  CTM_STATUS_BITS  bit;
};

struct CTM_INPUT_SEL_BITS {                   // bits description
    Uint32 CTM_INP_SEL_EN:1;                  // 0 Count input select enable
    Uint32 CNT_INP_SEL:5;                     // 5:1 Count input select
    Uint32 STA_INP_SEL:5;                     // 10:6 Start input select
    Uint32 STO_INP_SEL:5;                     // 15:11 Stop input select
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union CTM_INPUT_SEL_REG {
    Uint32  all;
    struct  CTM_INPUT_SEL_BITS  bit;
};

struct CTM_CLEAR_BITS {                       // bits description
    Uint32 EVENT_CLEAR:1;                     // 0 Clear EVENT_FIRED
    Uint32 OVERFLOW_CLEAR:1;                  // 1 Clear OVERFLOW
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CTM_CLEAR_REG {
    Uint32  all;
    struct  CTM_CLEAR_BITS  bit;
};

struct  ERAD_COUNTER_REGS {
    union   CTM_CNTL_REG                     CTM_CNTL;                    // 0x0 Counter Control Register
    union   CTM_STATUS_REG                   CTM_STATUS;                  // 0x4 Counter Status Register
    Uint32                                   CTM_REF;                     // 0x8 Counter Reference Register
    Uint32                                   CTM_COUNT;                   // 0xc Counter Current Value Register
    Uint32                                   CTM_MAX_COUNT;               // 0x10 Counter Max Count Value Register
    union   CTM_INPUT_SEL_REG                CTM_INPUT_SEL;               // 0x14 Counter Input Select Register
    union   CTM_CLEAR_REG                    CTM_CLEAR;                   // 0x18 Counter Clear Register
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
