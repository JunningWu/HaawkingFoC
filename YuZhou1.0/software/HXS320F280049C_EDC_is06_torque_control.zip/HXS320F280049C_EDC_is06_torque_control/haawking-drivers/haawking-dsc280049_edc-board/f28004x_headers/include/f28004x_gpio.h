//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:13:45.627682
//
//#############################################################################


#ifndef F28004X_GPIO_H
#define F28004X_GPIO_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// GPIO Individual Register Bit Definitions:

struct GPACTRL_BITS {                         // bits description
    Uint32 QUALPRD0:8;                        // 7:0 Qualification sampling period for GPIO0 to GPIO7
    Uint32 QUALPRD1:8;                        // 15:8 Qualification sampling period for GPIO8 to GPIO15
    Uint32 QUALPRD2:8;                        // 23:16 Qualification sampling period for GPIO16 to GPIO23
    Uint32 QUALPRD3:8;                        // 31:24 Qualification sampling period for GPIO24 to GPIO31
};

union GPACTRL_REG {
    Uint32  all;
    struct  GPACTRL_BITS  bit;
};

struct GPAQSEL1_BITS {                        // bits description
    Uint32 GPIO0:2;                           // 1:0 Select input qualification type for GPIO0
    Uint32 GPIO1:2;                           // 3:2 Select input qualification type for GPIO1
    Uint32 GPIO2:2;                           // 5:4 Select input qualification type for GPIO2
    Uint32 GPIO3:2;                           // 7:6 Select input qualification type for GPIO3
    Uint32 GPIO4:2;                           // 9:8 Select input qualification type for GPIO4
    Uint32 GPIO5:2;                           // 11:10 Select input qualification type for GPIO5
    Uint32 GPIO6:2;                           // 13:12 Select input qualification type for GPIO6
    Uint32 GPIO7:2;                           // 15:14 Select input qualification type for GPIO7
    Uint32 GPIO8:2;                           // 17:16 Select input qualification type for GPIO8
    Uint32 GPIO9:2;                           // 19:18 Select input qualification type for GPIO9
    Uint32 GPIO10:2;                          // 21:20 Select input qualification type for GPIO10
    Uint32 GPIO11:2;                          // 23:22 Select input qualification type for GPIO11
    Uint32 GPIO12:2;                          // 25:24 Select input qualification type for GPIO12
    Uint32 GPIO13:2;                          // 27:26 Select input qualification type for GPIO13
    Uint32 GPIO14:2;                          // 29:28 Select input qualification type for GPIO14
    Uint32 GPIO15:2;                          // 31:30 Select input qualification type for GPIO15
};

union GPAQSEL1_REG {
    Uint32  all;
    struct  GPAQSEL1_BITS  bit;
};

struct GPAQSEL2_BITS {                        // bits description
    Uint32 GPIO16:2;                          // 1:0 Select input qualification type for GPIO16
    Uint32 GPIO17:2;                          // 3:2 Select input qualification type for GPIO17
    Uint32 GPIO18:2;                          // 5:4 Select input qualification type for GPIO18
    Uint32 GPIO19:2;                          // 7:6 Select input qualification type for GPIO19
    Uint32 GPIO20:2;                          // 9:8 Select input qualification type for GPIO20
    Uint32 GPIO21:2;                          // 11:10 Select input qualification type for GPIO21
    Uint32 GPIO22:2;                          // 13:12 Select input qualification type for GPIO22
    Uint32 GPIO23:2;                          // 15:14 Select input qualification type for GPIO23
    Uint32 GPIO24:2;                          // 17:16 Select input qualification type for GPIO24
    Uint32 GPIO25:2;                          // 19:18 Select input qualification type for GPIO25
    Uint32 GPIO26:2;                          // 21:20 Select input qualification type for GPIO26
    Uint32 GPIO27:2;                          // 23:22 Select input qualification type for GPIO27
    Uint32 GPIO28:2;                          // 25:24 Select input qualification type for GPIO28
    Uint32 GPIO29:2;                          // 27:26 Select input qualification type for GPIO29
    Uint32 GPIO30:2;                          // 29:28 Select input qualification type for GPIO30
    Uint32 GPIO31:2;                          // 31:30 Select input qualification type for GPIO31
};

union GPAQSEL2_REG {
    Uint32  all;
    struct  GPAQSEL2_BITS  bit;
};

struct GPAMUX1_BITS {                         // bits description
    Uint32 GPIO0:2;                           // 1:0 Defines pin-muxing selection for GPIO0
    Uint32 GPIO1:2;                           // 3:2 Defines pin-muxing selection for GPIO1
    Uint32 GPIO2:2;                           // 5:4 Defines pin-muxing selection for GPIO2
    Uint32 GPIO3:2;                           // 7:6 Defines pin-muxing selection for GPIO3
    Uint32 GPIO4:2;                           // 9:8 Defines pin-muxing selection for GPIO4
    Uint32 GPIO5:2;                           // 11:10 Defines pin-muxing selection for GPIO5
    Uint32 GPIO6:2;                           // 13:12 Defines pin-muxing selection for GPIO6
    Uint32 GPIO7:2;                           // 15:14 Defines pin-muxing selection for GPIO7
    Uint32 GPIO8:2;                           // 17:16 Defines pin-muxing selection for GPIO8
    Uint32 GPIO9:2;                           // 19:18 Defines pin-muxing selection for GPIO9
    Uint32 GPIO10:2;                          // 21:20 Defines pin-muxing selection for GPIO10
    Uint32 GPIO11:2;                          // 23:22 Defines pin-muxing selection for GPIO11
    Uint32 GPIO12:2;                          // 25:24 Defines pin-muxing selection for GPIO12
    Uint32 GPIO13:2;                          // 27:26 Defines pin-muxing selection for GPIO13
    Uint32 GPIO14:2;                          // 29:28 Defines pin-muxing selection for GPIO14
    Uint32 GPIO15:2;                          // 31:30 Defines pin-muxing selection for GPIO15
};

union GPAMUX1_REG {
    Uint32  all;
    struct  GPAMUX1_BITS  bit;
};

struct GPAMUX2_BITS {                         // bits description
    Uint32 GPIO16:2;                          // 1:0 Defines pin-muxing selection for GPIO16
    Uint32 GPIO17:2;                          // 3:2 Defines pin-muxing selection for GPIO17
    Uint32 GPIO18:2;                          // 5:4 Defines pin-muxing selection for GPIO18
    Uint32 GPIO19:2;                          // 7:6 Defines pin-muxing selection for GPIO19
    Uint32 GPIO20:2;                          // 9:8 Defines pin-muxing selection for GPIO20
    Uint32 GPIO21:2;                          // 11:10 Defines pin-muxing selection for GPIO21
    Uint32 GPIO22:2;                          // 13:12 Defines pin-muxing selection for GPIO22
    Uint32 GPIO23:2;                          // 15:14 Defines pin-muxing selection for GPIO23
    Uint32 GPIO24:2;                          // 17:16 Defines pin-muxing selection for GPIO24
    Uint32 GPIO25:2;                          // 19:18 Defines pin-muxing selection for GPIO25
    Uint32 GPIO26:2;                          // 21:20 Defines pin-muxing selection for GPIO26
    Uint32 GPIO27:2;                          // 23:22 Defines pin-muxing selection for GPIO27
    Uint32 GPIO28:2;                          // 25:24 Defines pin-muxing selection for GPIO28
    Uint32 GPIO29:2;                          // 27:26 Defines pin-muxing selection for GPIO29
    Uint32 GPIO30:2;                          // 29:28 Defines pin-muxing selection for GPIO30
    Uint32 GPIO31:2;                          // 31:30 Defines pin-muxing selection for GPIO31
};

union GPAMUX2_REG {
    Uint32  all;
    struct  GPAMUX2_BITS  bit;
};

struct GPADIR_BITS {                          // bits description
    Uint32 GPIO0:1;                           // 0 Defines direction for this pin in GPIO mode
    Uint32 GPIO1:1;                           // 1 Defines direction for this pin in GPIO mode
    Uint32 GPIO2:1;                           // 2 Defines direction for this pin in GPIO mode
    Uint32 GPIO3:1;                           // 3 Defines direction for this pin in GPIO mode
    Uint32 GPIO4:1;                           // 4 Defines direction for this pin in GPIO mode
    Uint32 GPIO5:1;                           // 5 Defines direction for this pin in GPIO mode
    Uint32 GPIO6:1;                           // 6 Defines direction for this pin in GPIO mode
    Uint32 GPIO7:1;                           // 7 Defines direction for this pin in GPIO mode
    Uint32 GPIO8:1;                           // 8 Defines direction for this pin in GPIO mode
    Uint32 GPIO9:1;                           // 9 Defines direction for this pin in GPIO mode
    Uint32 GPIO10:1;                          // 10 Defines direction for this pin in GPIO mode
    Uint32 GPIO11:1;                          // 11 Defines direction for this pin in GPIO mode
    Uint32 GPIO12:1;                          // 12 Defines direction for this pin in GPIO mode
    Uint32 GPIO13:1;                          // 13 Defines direction for this pin in GPIO mode
    Uint32 GPIO14:1;                          // 14 Defines direction for this pin in GPIO mode
    Uint32 GPIO15:1;                          // 15 Defines direction for this pin in GPIO mode
    Uint32 GPIO16:1;                          // 16 Defines direction for this pin in GPIO mode
    Uint32 GPIO17:1;                          // 17 Defines direction for this pin in GPIO mode
    Uint32 GPIO18:1;                          // 18 Defines direction for this pin in GPIO mode
    Uint32 GPIO19:1;                          // 19 Defines direction for this pin in GPIO mode
    Uint32 GPIO20:1;                          // 20 Defines direction for this pin in GPIO mode
    Uint32 GPIO21:1;                          // 21 Defines direction for this pin in GPIO mode
    Uint32 GPIO22:1;                          // 22 Defines direction for this pin in GPIO mode
    Uint32 GPIO23:1;                          // 23 Defines direction for this pin in GPIO mode
    Uint32 GPIO24:1;                          // 24 Defines direction for this pin in GPIO mode
    Uint32 GPIO25:1;                          // 25 Defines direction for this pin in GPIO mode
    Uint32 GPIO26:1;                          // 26 Defines direction for this pin in GPIO mode
    Uint32 GPIO27:1;                          // 27 Defines direction for this pin in GPIO mode
    Uint32 GPIO28:1;                          // 28 Defines direction for this pin in GPIO mode
    Uint32 GPIO29:1;                          // 29 Defines direction for this pin in GPIO mode
    Uint32 GPIO30:1;                          // 30 Defines direction for this pin in GPIO mode
    Uint32 GPIO31:1;                          // 31 Defines direction for this pin in GPIO mode
};

union GPADIR_REG {
    Uint32  all;
    struct  GPADIR_BITS  bit;
};

struct GPAPUD_BITS {                          // bits description
    Uint32 GPIO0:1;                           // 0 Pull-Up Disable control for this pin
    Uint32 GPIO1:1;                           // 1 Pull-Up Disable control for this pin
    Uint32 GPIO2:1;                           // 2 Pull-Up Disable control for this pin
    Uint32 GPIO3:1;                           // 3 Pull-Up Disable control for this pin
    Uint32 GPIO4:1;                           // 4 Pull-Up Disable control for this pin
    Uint32 GPIO5:1;                           // 5 Pull-Up Disable control for this pin
    Uint32 GPIO6:1;                           // 6 Pull-Up Disable control for this pin
    Uint32 GPIO7:1;                           // 7 Pull-Up Disable control for this pin
    Uint32 GPIO8:1;                           // 8 Pull-Up Disable control for this pin
    Uint32 GPIO9:1;                           // 9 Pull-Up Disable control for this pin
    Uint32 GPIO10:1;                          // 10 Pull-Up Disable control for this pin
    Uint32 GPIO11:1;                          // 11 Pull-Up Disable control for this pin
    Uint32 GPIO12:1;                          // 12 Pull-Up Disable control for this pin
    Uint32 GPIO13:1;                          // 13 Pull-Up Disable control for this pin
    Uint32 GPIO14:1;                          // 14 Pull-Up Disable control for this pin
    Uint32 GPIO15:1;                          // 15 Pull-Up Disable control for this pin
    Uint32 GPIO16:1;                          // 16 Pull-Up Disable control for this pin
    Uint32 GPIO17:1;                          // 17 Pull-Up Disable control for this pin
    Uint32 GPIO18:1;                          // 18 Pull-Up Disable control for this pin
    Uint32 GPIO19:1;                          // 19 Pull-Up Disable control for this pin
    Uint32 GPIO20:1;                          // 20 Pull-Up Disable control for this pin
    Uint32 GPIO21:1;                          // 21 Pull-Up Disable control for this pin
    Uint32 GPIO22:1;                          // 22 Pull-Up Disable control for this pin
    Uint32 GPIO23:1;                          // 23 Pull-Up Disable control for this pin
    Uint32 GPIO24:1;                          // 24 Pull-Up Disable control for this pin
    Uint32 GPIO25:1;                          // 25 Pull-Up Disable control for this pin
    Uint32 GPIO26:1;                          // 26 Pull-Up Disable control for this pin
    Uint32 GPIO27:1;                          // 27 Pull-Up Disable control for this pin
    Uint32 GPIO28:1;                          // 28 Pull-Up Disable control for this pin
    Uint32 GPIO29:1;                          // 29 Pull-Up Disable control for this pin
    Uint32 GPIO30:1;                          // 30 Pull-Up Disable control for this pin
    Uint32 GPIO31:1;                          // 31 Pull-Up Disable control for this pin
};

union GPAPUD_REG {
    Uint32  all;
    struct  GPAPUD_BITS  bit;
};

struct GPAINV_BITS {                          // bits description
    Uint32 GPIO0:1;                           // 0 Input inversion control for this pin
    Uint32 GPIO1:1;                           // 1 Input inversion control for this pin
    Uint32 GPIO2:1;                           // 2 Input inversion control for this pin
    Uint32 GPIO3:1;                           // 3 Input inversion control for this pin
    Uint32 GPIO4:1;                           // 4 Input inversion control for this pin
    Uint32 GPIO5:1;                           // 5 Input inversion control for this pin
    Uint32 GPIO6:1;                           // 6 Input inversion control for this pin
    Uint32 GPIO7:1;                           // 7 Input inversion control for this pin
    Uint32 GPIO8:1;                           // 8 Input inversion control for this pin
    Uint32 GPIO9:1;                           // 9 Input inversion control for this pin
    Uint32 GPIO10:1;                          // 10 Input inversion control for this pin
    Uint32 GPIO11:1;                          // 11 Input inversion control for this pin
    Uint32 GPIO12:1;                          // 12 Input inversion control for this pin
    Uint32 GPIO13:1;                          // 13 Input inversion control for this pin
    Uint32 GPIO14:1;                          // 14 Input inversion control for this pin
    Uint32 GPIO15:1;                          // 15 Input inversion control for this pin
    Uint32 GPIO16:1;                          // 16 Input inversion control for this pin
    Uint32 GPIO17:1;                          // 17 Input inversion control for this pin
    Uint32 GPIO18:1;                          // 18 Input inversion control for this pin
    Uint32 GPIO19:1;                          // 19 Input inversion control for this pin
    Uint32 GPIO20:1;                          // 20 Input inversion control for this pin
    Uint32 GPIO21:1;                          // 21 Input inversion control for this pin
    Uint32 GPIO22:1;                          // 22 Input inversion control for this pin
    Uint32 GPIO23:1;                          // 23 Input inversion control for this pin
    Uint32 GPIO24:1;                          // 24 Input inversion control for this pin
    Uint32 GPIO25:1;                          // 25 Input inversion control for this pin
    Uint32 GPIO26:1;                          // 26 Input inversion control for this pin
    Uint32 GPIO27:1;                          // 27 Input inversion control for this pin
    Uint32 GPIO28:1;                          // 28 Input inversion control for this pin
    Uint32 GPIO29:1;                          // 29 Input inversion control for this pin
    Uint32 GPIO30:1;                          // 30 Input inversion control for this pin
    Uint32 GPIO31:1;                          // 31 Input inversion control for this pin
};

union GPAINV_REG {
    Uint32  all;
    struct  GPAINV_BITS  bit;
};

struct GPAODR_BITS {                          // bits description
    Uint32 GPIO0:1;                           // 0 Output Open-Drain control for this pin
    Uint32 GPIO1:1;                           // 1 Output Open-Drain control for this pin
    Uint32 GPIO2:1;                           // 2 Output Open-Drain control for this pin
    Uint32 GPIO3:1;                           // 3 Output Open-Drain control for this pin
    Uint32 GPIO4:1;                           // 4 Output Open-Drain control for this pin
    Uint32 GPIO5:1;                           // 5 Output Open-Drain control for this pin
    Uint32 GPIO6:1;                           // 6 Output Open-Drain control for this pin
    Uint32 GPIO7:1;                           // 7 Output Open-Drain control for this pin
    Uint32 GPIO8:1;                           // 8 Output Open-Drain control for this pin
    Uint32 GPIO9:1;                           // 9 Output Open-Drain control for this pin
    Uint32 GPIO10:1;                          // 10 Output Open-Drain control for this pin
    Uint32 GPIO11:1;                          // 11 Output Open-Drain control for this pin
    Uint32 GPIO12:1;                          // 12 Output Open-Drain control for this pin
    Uint32 GPIO13:1;                          // 13 Output Open-Drain control for this pin
    Uint32 GPIO14:1;                          // 14 Output Open-Drain control for this pin
    Uint32 GPIO15:1;                          // 15 Output Open-Drain control for this pin
    Uint32 GPIO16:1;                          // 16 Output Open-Drain control for this pin
    Uint32 GPIO17:1;                          // 17 Output Open-Drain control for this pin
    Uint32 GPIO18:1;                          // 18 Output Open-Drain control for this pin
    Uint32 GPIO19:1;                          // 19 Output Open-Drain control for this pin
    Uint32 GPIO20:1;                          // 20 Output Open-Drain control for this pin
    Uint32 GPIO21:1;                          // 21 Output Open-Drain control for this pin
    Uint32 GPIO22:1;                          // 22 Output Open-Drain control for this pin
    Uint32 GPIO23:1;                          // 23 Output Open-Drain control for this pin
    Uint32 GPIO24:1;                          // 24 Output Open-Drain control for this pin
    Uint32 GPIO25:1;                          // 25 Output Open-Drain control for this pin
    Uint32 GPIO26:1;                          // 26 Output Open-Drain control for this pin
    Uint32 GPIO27:1;                          // 27 Output Open-Drain control for this pin
    Uint32 GPIO28:1;                          // 28 Output Open-Drain control for this pin
    Uint32 GPIO29:1;                          // 29 Output Open-Drain control for this pin
    Uint32 GPIO30:1;                          // 30 Output Open-Drain control for this pin
    Uint32 GPIO31:1;                          // 31 Output Open-Drain control for this pin
};

union GPAODR_REG {
    Uint32  all;
    struct  GPAODR_BITS  bit;
};

struct GPAAMSEL_BITS {                        // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 rsvd2:1;                           // 1 Reserved
    Uint32 rsvd3:1;                           // 2 Reserved
    Uint32 rsvd4:1;                           // 3 Reserved
    Uint32 rsvd5:1;                           // 4 Reserved
    Uint32 rsvd6:1;                           // 5 Reserved
    Uint32 rsvd7:1;                           // 6 Reserved
    Uint32 rsvd8:1;                           // 7 Reserved
    Uint32 rsvd9:1;                           // 8 Reserved
    Uint32 rsvd10:1;                          // 9 Reserved
    Uint32 rsvd11:1;                          // 10 Reserved
    Uint32 rsvd12:1;                          // 11 Reserved
    Uint32 rsvd13:1;                          // 12 Reserved
    Uint32 rsvd14:1;                          // 13 Reserved
    Uint32 rsvd15:1;                          // 14 Reserved
    Uint32 rsvd16:1;                          // 15 Reserved
    Uint32 rsvd17:1;                          // 16 Reserved
    Uint32 rsvd18:1;                          // 17 Reserved
    Uint32 rsvd19:1;                          // 18 Reserved
    Uint32 rsvd20:1;                          // 19 Reserved
    Uint32 rsvd21:1;                          // 20 Reserved
    Uint32 rsvd22:1;                          // 21 Reserved
    Uint32 GPIO22:1;                          // 22 Analog Mode select for this pin
    Uint32 GPIO23:1;                          // 23 Analog Mode select for this pin
    Uint32 rsvd23:1;                          // 24 Reserved
    Uint32 rsvd24:1;                          // 25 Reserved
    Uint32 rsvd25:1;                          // 26 Reserved
    Uint32 rsvd26:1;                          // 27 Reserved
    Uint32 rsvd27:1;                          // 28 Reserved
    Uint32 rsvd28:1;                          // 29 Reserved
    Uint32 rsvd29:1;                          // 30 Reserved
    Uint32 rsvd30:1;                          // 31 Reserved
};

union GPAAMSEL_REG {
    Uint32  all;
    struct  GPAAMSEL_BITS  bit;
};

struct GPAGMUX1_BITS {                        // bits description
    Uint32 GPIO0:2;                           // 1:0 Defines pin-muxing selection for GPIO0
    Uint32 GPIO1:2;                           // 3:2 Defines pin-muxing selection for GPIO1
    Uint32 GPIO2:2;                           // 5:4 Defines pin-muxing selection for GPIO2
    Uint32 GPIO3:2;                           // 7:6 Defines pin-muxing selection for GPIO3
    Uint32 GPIO4:2;                           // 9:8 Defines pin-muxing selection for GPIO4
    Uint32 GPIO5:2;                           // 11:10 Defines pin-muxing selection for GPIO5
    Uint32 GPIO6:2;                           // 13:12 Defines pin-muxing selection for GPIO6
    Uint32 GPIO7:2;                           // 15:14 Defines pin-muxing selection for GPIO7
    Uint32 GPIO8:2;                           // 17:16 Defines pin-muxing selection for GPIO8
    Uint32 GPIO9:2;                           // 19:18 Defines pin-muxing selection for GPIO9
    Uint32 GPIO10:2;                          // 21:20 Defines pin-muxing selection for GPIO10
    Uint32 GPIO11:2;                          // 23:22 Defines pin-muxing selection for GPIO11
    Uint32 GPIO12:2;                          // 25:24 Defines pin-muxing selection for GPIO12
    Uint32 GPIO13:2;                          // 27:26 Defines pin-muxing selection for GPIO13
    Uint32 GPIO14:2;                          // 29:28 Defines pin-muxing selection for GPIO14
    Uint32 GPIO15:2;                          // 31:30 Defines pin-muxing selection for GPIO15
};

union GPAGMUX1_REG {
    Uint32  all;
    struct  GPAGMUX1_BITS  bit;
};

struct GPAGMUX2_BITS {                        // bits description
    Uint32 GPIO16:2;                          // 1:0 Defines pin-muxing selection for GPIO16
    Uint32 GPIO17:2;                          // 3:2 Defines pin-muxing selection for GPIO17
    Uint32 GPIO18:2;                          // 5:4 Defines pin-muxing selection for GPIO18
    Uint32 GPIO19:2;                          // 7:6 Defines pin-muxing selection for GPIO19
    Uint32 GPIO20:2;                          // 9:8 Defines pin-muxing selection for GPIO20
    Uint32 GPIO21:2;                          // 11:10 Defines pin-muxing selection for GPIO21
    Uint32 GPIO22:2;                          // 13:12 Defines pin-muxing selection for GPIO22
    Uint32 GPIO23:2;                          // 15:14 Defines pin-muxing selection for GPIO23
    Uint32 GPIO24:2;                          // 17:16 Defines pin-muxing selection for GPIO24
    Uint32 GPIO25:2;                          // 19:18 Defines pin-muxing selection for GPIO25
    Uint32 GPIO26:2;                          // 21:20 Defines pin-muxing selection for GPIO26
    Uint32 GPIO27:2;                          // 23:22 Defines pin-muxing selection for GPIO27
    Uint32 GPIO28:2;                          // 25:24 Defines pin-muxing selection for GPIO28
    Uint32 GPIO29:2;                          // 27:26 Defines pin-muxing selection for GPIO29
    Uint32 GPIO30:2;                          // 29:28 Defines pin-muxing selection for GPIO30
    Uint32 GPIO31:2;                          // 31:30 Defines pin-muxing selection for GPIO31
};

union GPAGMUX2_REG {
    Uint32  all;
    struct  GPAGMUX2_BITS  bit;
};

struct GPACSEL1_BITS {                        // bits description
    Uint32 GPIO0:4;                           // 3:0 GPIO0 Master CPU Select
    Uint32 GPIO1:4;                           // 7:4 GPIO1 Master CPU Select
    Uint32 GPIO2:4;                           // 11:8 GPIO2 Master CPU Select
    Uint32 GPIO3:4;                           // 15:12 GPIO3 Master CPU Select
    Uint32 GPIO4:4;                           // 19:16 GPIO4 Master CPU Select
    Uint32 GPIO5:4;                           // 23:20 GPIO5 Master CPU Select
    Uint32 GPIO6:4;                           // 27:24 GPIO6 Master CPU Select
    Uint32 GPIO7:4;                           // 31:28 GPIO7 Master CPU Select
};

union GPACSEL1_REG {
    Uint32  all;
    struct  GPACSEL1_BITS  bit;
};

struct GPACSEL2_BITS {                        // bits description
    Uint32 GPIO8:4;                           // 3:0 GPIO8 Master CPU Select
    Uint32 GPIO9:4;                           // 7:4 GPIO9 Master CPU Select
    Uint32 GPIO10:4;                          // 11:8 GPIO10 Master CPU Select
    Uint32 GPIO11:4;                          // 15:12 GPIO11 Master CPU Select
    Uint32 GPIO12:4;                          // 19:16 GPIO12 Master CPU Select
    Uint32 GPIO13:4;                          // 23:20 GPIO13 Master CPU Select
    Uint32 GPIO14:4;                          // 27:24 GPIO14 Master CPU Select
    Uint32 GPIO15:4;                          // 31:28 GPIO15 Master CPU Select
};

union GPACSEL2_REG {
    Uint32  all;
    struct  GPACSEL2_BITS  bit;
};

struct GPACSEL3_BITS {                        // bits description
    Uint32 GPIO16:4;                          // 3:0 GPIO16 Master CPU Select
    Uint32 GPIO17:4;                          // 7:4 GPIO17 Master CPU Select
    Uint32 GPIO18:4;                          // 11:8 GPIO18 Master CPU Select
    Uint32 GPIO19:4;                          // 15:12 GPIO19 Master CPU Select
    Uint32 GPIO20:4;                          // 19:16 GPIO20 Master CPU Select
    Uint32 GPIO21:4;                          // 23:20 GPIO21 Master CPU Select
    Uint32 GPIO22:4;                          // 27:24 GPIO22 Master CPU Select
    Uint32 GPIO23:4;                          // 31:28 GPIO23 Master CPU Select
};

union GPACSEL3_REG {
    Uint32  all;
    struct  GPACSEL3_BITS  bit;
};

struct GPACSEL4_BITS {                        // bits description
    Uint32 GPIO24:4;                          // 3:0 GPIO24 Master CPU Select
    Uint32 GPIO25:4;                          // 7:4 GPIO25 Master CPU Select
    Uint32 GPIO26:4;                          // 11:8 GPIO26 Master CPU Select
    Uint32 GPIO27:4;                          // 15:12 GPIO27 Master CPU Select
    Uint32 GPIO28:4;                          // 19:16 GPIO28 Master CPU Select
    Uint32 GPIO29:4;                          // 23:20 GPIO29 Master CPU Select
    Uint32 GPIO30:4;                          // 27:24 GPIO30 Master CPU Select
    Uint32 GPIO31:4;                          // 31:28 GPIO31 Master CPU Select
};

union GPACSEL4_REG {
    Uint32  all;
    struct  GPACSEL4_BITS  bit;
};

struct GPALOCK_BITS {                         // bits description
    Uint32 GPIO0:1;                           // 0 Configuration Lock bit for this pin
    Uint32 GPIO1:1;                           // 1 Configuration Lock bit for this pin
    Uint32 GPIO2:1;                           // 2 Configuration Lock bit for this pin
    Uint32 GPIO3:1;                           // 3 Configuration Lock bit for this pin
    Uint32 GPIO4:1;                           // 4 Configuration Lock bit for this pin
    Uint32 GPIO5:1;                           // 5 Configuration Lock bit for this pin
    Uint32 GPIO6:1;                           // 6 Configuration Lock bit for this pin
    Uint32 GPIO7:1;                           // 7 Configuration Lock bit for this pin
    Uint32 GPIO8:1;                           // 8 Configuration Lock bit for this pin
    Uint32 GPIO9:1;                           // 9 Configuration Lock bit for this pin
    Uint32 GPIO10:1;                          // 10 Configuration Lock bit for this pin
    Uint32 GPIO11:1;                          // 11 Configuration Lock bit for this pin
    Uint32 GPIO12:1;                          // 12 Configuration Lock bit for this pin
    Uint32 GPIO13:1;                          // 13 Configuration Lock bit for this pin
    Uint32 GPIO14:1;                          // 14 Configuration Lock bit for this pin
    Uint32 GPIO15:1;                          // 15 Configuration Lock bit for this pin
    Uint32 GPIO16:1;                          // 16 Configuration Lock bit for this pin
    Uint32 GPIO17:1;                          // 17 Configuration Lock bit for this pin
    Uint32 GPIO18:1;                          // 18 Configuration Lock bit for this pin
    Uint32 GPIO19:1;                          // 19 Configuration Lock bit for this pin
    Uint32 GPIO20:1;                          // 20 Configuration Lock bit for this pin
    Uint32 GPIO21:1;                          // 21 Configuration Lock bit for this pin
    Uint32 GPIO22:1;                          // 22 Configuration Lock bit for this pin
    Uint32 GPIO23:1;                          // 23 Configuration Lock bit for this pin
    Uint32 GPIO24:1;                          // 24 Configuration Lock bit for this pin
    Uint32 GPIO25:1;                          // 25 Configuration Lock bit for this pin
    Uint32 GPIO26:1;                          // 26 Configuration Lock bit for this pin
    Uint32 GPIO27:1;                          // 27 Configuration Lock bit for this pin
    Uint32 GPIO28:1;                          // 28 Configuration Lock bit for this pin
    Uint32 GPIO29:1;                          // 29 Configuration Lock bit for this pin
    Uint32 GPIO30:1;                          // 30 Configuration Lock bit for this pin
    Uint32 GPIO31:1;                          // 31 Configuration Lock bit for this pin
};

union GPALOCK_REG {
    Uint32  all;
    struct  GPALOCK_BITS  bit;
};

struct GPACR_BITS {                           // bits description
    Uint32 GPIO0:1;                           // 0 Configuration lock commit bit for this pin
    Uint32 GPIO1:1;                           // 1 Configuration lock commit bit for this pin
    Uint32 GPIO2:1;                           // 2 Configuration lock commit bit for this pin
    Uint32 GPIO3:1;                           // 3 Configuration lock commit bit for this pin
    Uint32 GPIO4:1;                           // 4 Configuration lock commit bit for this pin
    Uint32 GPIO5:1;                           // 5 Configuration lock commit bit for this pin
    Uint32 GPIO6:1;                           // 6 Configuration lock commit bit for this pin
    Uint32 GPIO7:1;                           // 7 Configuration lock commit bit for this pin
    Uint32 GPIO8:1;                           // 8 Configuration lock commit bit for this pin
    Uint32 GPIO9:1;                           // 9 Configuration lock commit bit for this pin
    Uint32 GPIO10:1;                          // 10 Configuration lock commit bit for this pin
    Uint32 GPIO11:1;                          // 11 Configuration lock commit bit for this pin
    Uint32 GPIO12:1;                          // 12 Configuration lock commit bit for this pin
    Uint32 GPIO13:1;                          // 13 Configuration lock commit bit for this pin
    Uint32 GPIO14:1;                          // 14 Configuration lock commit bit for this pin
    Uint32 GPIO15:1;                          // 15 Configuration lock commit bit for this pin
    Uint32 GPIO16:1;                          // 16 Configuration lock commit bit for this pin
    Uint32 GPIO17:1;                          // 17 Configuration lock commit bit for this pin
    Uint32 GPIO18:1;                          // 18 Configuration lock commit bit for this pin
    Uint32 GPIO19:1;                          // 19 Configuration lock commit bit for this pin
    Uint32 GPIO20:1;                          // 20 Configuration lock commit bit for this pin
    Uint32 GPIO21:1;                          // 21 Configuration lock commit bit for this pin
    Uint32 GPIO22:1;                          // 22 Configuration lock commit bit for this pin
    Uint32 GPIO23:1;                          // 23 Configuration lock commit bit for this pin
    Uint32 GPIO24:1;                          // 24 Configuration lock commit bit for this pin
    Uint32 GPIO25:1;                          // 25 Configuration lock commit bit for this pin
    Uint32 GPIO26:1;                          // 26 Configuration lock commit bit for this pin
    Uint32 GPIO27:1;                          // 27 Configuration lock commit bit for this pin
    Uint32 GPIO28:1;                          // 28 Configuration lock commit bit for this pin
    Uint32 GPIO29:1;                          // 29 Configuration lock commit bit for this pin
    Uint32 GPIO30:1;                          // 30 Configuration lock commit bit for this pin
    Uint32 GPIO31:1;                          // 31 Configuration lock commit bit for this pin
};

union GPACR_REG {
    Uint32  all;
    struct  GPACR_BITS  bit;
};

struct GPBCTRL_BITS {                         // bits description
    Uint32 QUALPRD0:8;                        // 7:0 Qualification sampling period for GPIO32 to GPIO39
    Uint32 QUALPRD1:8;                        // 15:8 Qualification sampling period for GPIO40 to GPIO47
    Uint32 QUALPRD2:8;                        // 23:16 Qualification sampling period for GPIO48 to GPIO55
    Uint32 QUALPRD3:8;                        // 31:24 Qualification sampling period for GPIO56 to GPIO63
};

union GPBCTRL_REG {
    Uint32  all;
    struct  GPBCTRL_BITS  bit;
};

struct GPBQSEL1_BITS {                        // bits description
    Uint32 GPIO32:2;                          // 1:0 Select input qualification type for GPIO32
    Uint32 GPIO33:2;                          // 3:2 Select input qualification type for GPIO33
    Uint32 GPIO34:2;                          // 5:4 Select input qualification type for GPIO34
    Uint32 GPIO35:2;                          // 7:6 Select input qualification type for GPIO35
    Uint32 rsvd1:2;                           // 9:8 Reserved
    Uint32 GPIO37:2;                          // 11:10 Select input qualification type for GPIO37
    Uint32 rsvd2:2;                           // 13:12 Reserved
    Uint32 GPIO39:2;                          // 15:14 Select input qualification type for GPIO39
    Uint32 GPIO40:2;                          // 17:16 Select input qualification type for GPIO40
    Uint32 GPIO41:2;                          // 19:18 Select input qualification type for GPIO41
    Uint32 GPIO42:2;                          // 21:20 Select input qualification type for GPIO42
    Uint32 GPIO43:2;                          // 23:22 Select input qualification type for GPIO43
    Uint32 GPIO44:2;                          // 25:24 Select input qualification type for GPIO44
    Uint32 GPIO45:2;                          // 27:26 Select input qualification type for GPIO45
    Uint32 GPIO46:2;                          // 29:28 Select input qualification type for GPIO46
    Uint32 GPIO47:2;                          // 31:30 Select input qualification type for GPIO47
};

union GPBQSEL1_REG {
    Uint32  all;
    struct  GPBQSEL1_BITS  bit;
};

struct GPBQSEL2_BITS {                        // bits description
    Uint32 GPIO48:2;                          // 1:0 Select input qualification type for GPIO48
    Uint32 GPIO49:2;                          // 3:2 Select input qualification type for GPIO49
    Uint32 GPIO50:2;                          // 5:4 Select input qualification type for GPIO50
    Uint32 GPIO51:2;                          // 7:6 Select input qualification type for GPIO51
    Uint32 GPIO52:2;                          // 9:8 Select input qualification type for GPIO52
    Uint32 GPIO53:2;                          // 11:10 Select input qualification type for GPIO53
    Uint32 GPIO54:2;                          // 13:12 Select input qualification type for GPIO54
    Uint32 GPIO55:2;                          // 15:14 Select input qualification type for GPIO55
    Uint32 GPIO56:2;                          // 17:16 Select input qualification type for GPIO56
    Uint32 GPIO57:2;                          // 19:18 Select input qualification type for GPIO57
    Uint32 GPIO58:2;                          // 21:20 Select input qualification type for GPIO58
    Uint32 GPIO59:2;                          // 23:22 Select input qualification type for GPIO59
    Uint32 rsvd1:2;                           // 25:24 Reserved
    Uint32 rsvd2:2;                           // 27:26 Reserved
    Uint32 rsvd3:2;                           // 29:28 Reserved
    Uint32 rsvd4:2;                           // 31:30 Reserved
};

union GPBQSEL2_REG {
    Uint32  all;
    struct  GPBQSEL2_BITS  bit;
};

struct GPBMUX1_BITS {                         // bits description
    Uint32 GPIO32:2;                          // 1:0 Defines pin-muxing selection for GPIO32
    Uint32 GPIO33:2;                          // 3:2 Defines pin-muxing selection for GPIO33
    Uint32 GPIO34:2;                          // 5:4 Defines pin-muxing selection for GPIO34
    Uint32 GPIO35:2;                          // 7:6 Defines pin-muxing selection for GPIO35
    Uint32 rsvd1:2;                           // 9:8 Reserved
    Uint32 GPIO37:2;                          // 11:10 Defines pin-muxing selection for GPIO37
    Uint32 rsvd2:2;                           // 13:12 Reserved
    Uint32 GPIO39:2;                          // 15:14 Defines pin-muxing selection for GPIO39
    Uint32 GPIO40:2;                          // 17:16 Defines pin-muxing selection for GPIO40
    Uint32 GPIO41:2;                          // 19:18 Defines pin-muxing selection for GPIO41
    Uint32 GPIO42:2;                          // 21:20 Defines pin-muxing selection for GPIO42
    Uint32 GPIO43:2;                          // 23:22 Defines pin-muxing selection for GPIO43
    Uint32 GPIO44:2;                          // 25:24 Defines pin-muxing selection for GPIO44
    Uint32 GPIO45:2;                          // 27:26 Defines pin-muxing selection for GPIO45
    Uint32 GPIO46:2;                          // 29:28 Defines pin-muxing selection for GPIO46
    Uint32 GPIO47:2;                          // 31:30 Defines pin-muxing selection for GPIO47
};

union GPBMUX1_REG {
    Uint32  all;
    struct  GPBMUX1_BITS  bit;
};

struct GPBMUX2_BITS {                         // bits description
    Uint32 GPIO48:2;                          // 1:0 Defines pin-muxing selection for GPIO48
    Uint32 GPIO49:2;                          // 3:2 Defines pin-muxing selection for GPIO49
    Uint32 GPIO50:2;                          // 5:4 Defines pin-muxing selection for GPIO50
    Uint32 GPIO51:2;                          // 7:6 Defines pin-muxing selection for GPIO51
    Uint32 GPIO52:2;                          // 9:8 Defines pin-muxing selection for GPIO52
    Uint32 GPIO53:2;                          // 11:10 Defines pin-muxing selection for GPIO53
    Uint32 GPIO54:2;                          // 13:12 Defines pin-muxing selection for GPIO54
    Uint32 GPIO55:2;                          // 15:14 Defines pin-muxing selection for GPIO55
    Uint32 GPIO56:2;                          // 17:16 Defines pin-muxing selection for GPIO56
    Uint32 GPIO57:2;                          // 19:18 Defines pin-muxing selection for GPIO57
    Uint32 GPIO58:2;                          // 21:20 Defines pin-muxing selection for GPIO58
    Uint32 GPIO59:2;                          // 23:22 Defines pin-muxing selection for GPIO59
    Uint32 rsvd1:2;                           // 25:24 Reserved
    Uint32 rsvd2:2;                           // 27:26 Reserved
    Uint32 rsvd3:2;                           // 29:28 Reserved
    Uint32 rsvd4:2;                           // 31:30 Reserved
};

union GPBMUX2_REG {
    Uint32  all;
    struct  GPBMUX2_BITS  bit;
};

struct GPBDIR_BITS {                          // bits description
    Uint32 GPIO32:1;                          // 0 Defines direction for this pin in GPIO mode
    Uint32 GPIO33:1;                          // 1 Defines direction for this pin in GPIO mode
    Uint32 GPIO34:1;                          // 2 Defines direction for this pin in GPIO mode
    Uint32 GPIO35:1;                          // 3 Defines direction for this pin in GPIO mode
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Defines direction for this pin in GPIO mode
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Defines direction for this pin in GPIO mode
    Uint32 GPIO40:1;                          // 8 Defines direction for this pin in GPIO mode
    Uint32 GPIO41:1;                          // 9 Defines direction for this pin in GPIO mode
    Uint32 GPIO42:1;                          // 10 Defines direction for this pin in GPIO mode
    Uint32 GPIO43:1;                          // 11 Defines direction for this pin in GPIO mode
    Uint32 GPIO44:1;                          // 12 Defines direction for this pin in GPIO mode
    Uint32 GPIO45:1;                          // 13 Defines direction for this pin in GPIO mode
    Uint32 GPIO46:1;                          // 14 Defines direction for this pin in GPIO mode
    Uint32 GPIO47:1;                          // 15 Defines direction for this pin in GPIO mode
    Uint32 GPIO48:1;                          // 16 Defines direction for this pin in GPIO mode
    Uint32 GPIO49:1;                          // 17 Defines direction for this pin in GPIO mode
    Uint32 GPIO50:1;                          // 18 Defines direction for this pin in GPIO mode
    Uint32 GPIO51:1;                          // 19 Defines direction for this pin in GPIO mode
    Uint32 GPIO52:1;                          // 20 Defines direction for this pin in GPIO mode
    Uint32 GPIO53:1;                          // 21 Defines direction for this pin in GPIO mode
    Uint32 GPIO54:1;                          // 22 Defines direction for this pin in GPIO mode
    Uint32 GPIO55:1;                          // 23 Defines direction for this pin in GPIO mode
    Uint32 GPIO56:1;                          // 24 Defines direction for this pin in GPIO mode
    Uint32 GPIO57:1;                          // 25 Defines direction for this pin in GPIO mode
    Uint32 GPIO58:1;                          // 26 Defines direction for this pin in GPIO mode
    Uint32 GPIO59:1;                          // 27 Defines direction for this pin in GPIO mode
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBDIR_REG {
    Uint32  all;
    struct  GPBDIR_BITS  bit;
};

struct GPBPUD_BITS {                          // bits description
    Uint32 GPIO32:1;                          // 0 Pull-Up Disable control for this pin
    Uint32 GPIO33:1;                          // 1 Pull-Up Disable control for this pin
    Uint32 GPIO34:1;                          // 2 Pull-Up Disable control for this pin
    Uint32 GPIO35:1;                          // 3 Pull-Up Disable control for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Pull-Up Disable control for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Pull-Up Disable control for this pin
    Uint32 GPIO40:1;                          // 8 Pull-Up Disable control for this pin
    Uint32 GPIO41:1;                          // 9 Pull-Up Disable control for this pin
    Uint32 GPIO42:1;                          // 10 Pull-Up Disable control for this pin
    Uint32 GPIO43:1;                          // 11 Pull-Up Disable control for this pin
    Uint32 GPIO44:1;                          // 12 Pull-Up Disable control for this pin
    Uint32 GPIO45:1;                          // 13 Pull-Up Disable control for this pin
    Uint32 GPIO46:1;                          // 14 Pull-Up Disable control for this pin
    Uint32 GPIO47:1;                          // 15 Pull-Up Disable control for this pin
    Uint32 GPIO48:1;                          // 16 Pull-Up Disable control for this pin
    Uint32 GPIO49:1;                          // 17 Pull-Up Disable control for this pin
    Uint32 GPIO50:1;                          // 18 Pull-Up Disable control for this pin
    Uint32 GPIO51:1;                          // 19 Pull-Up Disable control for this pin
    Uint32 GPIO52:1;                          // 20 Pull-Up Disable control for this pin
    Uint32 GPIO53:1;                          // 21 Pull-Up Disable control for this pin
    Uint32 GPIO54:1;                          // 22 Pull-Up Disable control for this pin
    Uint32 GPIO55:1;                          // 23 Pull-Up Disable control for this pin
    Uint32 GPIO56:1;                          // 24 Pull-Up Disable control for this pin
    Uint32 GPIO57:1;                          // 25 Pull-Up Disable control for this pin
    Uint32 GPIO58:1;                          // 26 Pull-Up Disable control for this pin
    Uint32 GPIO59:1;                          // 27 Pull-Up Disable control for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBPUD_REG {
    Uint32  all;
    struct  GPBPUD_BITS  bit;
};

struct GPBINV_BITS {                          // bits description
    Uint32 GPIO32:1;                          // 0 Input inversion control for this pin
    Uint32 GPIO33:1;                          // 1 Input inversion control for this pin
    Uint32 GPIO34:1;                          // 2 Input inversion control for this pin
    Uint32 GPIO35:1;                          // 3 Input inversion control for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Input inversion control for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Input inversion control for this pin
    Uint32 GPIO40:1;                          // 8 Input inversion control for this pin
    Uint32 GPIO41:1;                          // 9 Input inversion control for this pin
    Uint32 GPIO42:1;                          // 10 Input inversion control for this pin
    Uint32 GPIO43:1;                          // 11 Input inversion control for this pin
    Uint32 GPIO44:1;                          // 12 Input inversion control for this pin
    Uint32 GPIO45:1;                          // 13 Input inversion control for this pin
    Uint32 GPIO46:1;                          // 14 Input inversion control for this pin
    Uint32 GPIO47:1;                          // 15 Input inversion control for this pin
    Uint32 GPIO48:1;                          // 16 Input inversion control for this pin
    Uint32 GPIO49:1;                          // 17 Input inversion control for this pin
    Uint32 GPIO50:1;                          // 18 Input inversion control for this pin
    Uint32 GPIO51:1;                          // 19 Input inversion control for this pin
    Uint32 GPIO52:1;                          // 20 Input inversion control for this pin
    Uint32 GPIO53:1;                          // 21 Input inversion control for this pin
    Uint32 GPIO54:1;                          // 22 Input inversion control for this pin
    Uint32 GPIO55:1;                          // 23 Input inversion control for this pin
    Uint32 GPIO56:1;                          // 24 Input inversion control for this pin
    Uint32 GPIO57:1;                          // 25 Input inversion control for this pin
    Uint32 GPIO58:1;                          // 26 Input inversion control for this pin
    Uint32 GPIO59:1;                          // 27 Input inversion control for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBINV_REG {
    Uint32  all;
    struct  GPBINV_BITS  bit;
};

struct GPBODR_BITS {                          // bits description
    Uint32 GPIO32:1;                          // 0 Output Open-Drain control for this pin
    Uint32 GPIO33:1;                          // 1 Output Open-Drain control for this pin
    Uint32 GPIO34:1;                          // 2 Output Open-Drain control for this pin
    Uint32 GPIO35:1;                          // 3 Output Open-Drain control for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Output Open-Drain control for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Output Open-Drain control for this pin
    Uint32 GPIO40:1;                          // 8 Output Open-Drain control for this pin
    Uint32 GPIO41:1;                          // 9 Output Open-Drain control for this pin
    Uint32 GPIO42:1;                          // 10 Output Open-Drain control for this pin
    Uint32 GPIO43:1;                          // 11 Output Open-Drain control for this pin
    Uint32 GPIO44:1;                          // 12 Output Open-Drain control for this pin
    Uint32 GPIO45:1;                          // 13 Output Open-Drain control for this pin
    Uint32 GPIO46:1;                          // 14 Output Open-Drain control for this pin
    Uint32 GPIO47:1;                          // 15 Output Open-Drain control for this pin
    Uint32 GPIO48:1;                          // 16 Output Open-Drain control for this pin
    Uint32 GPIO49:1;                          // 17 Output Open-Drain control for this pin
    Uint32 GPIO50:1;                          // 18 Output Open-Drain control for this pin
    Uint32 GPIO51:1;                          // 19 Output Open-Drain control for this pin
    Uint32 GPIO52:1;                          // 20 Output Open-Drain control for this pin
    Uint32 GPIO53:1;                          // 21 Output Open-Drain control for this pin
    Uint32 GPIO54:1;                          // 22 Output Open-Drain control for this pin
    Uint32 GPIO55:1;                          // 23 Output Open-Drain control for this pin
    Uint32 GPIO56:1;                          // 24 Output Open-Drain control for this pin
    Uint32 GPIO57:1;                          // 25 Output Open-Drain control for this pin
    Uint32 GPIO58:1;                          // 26 Output Open-Drain control for this pin
    Uint32 GPIO59:1;                          // 27 Output Open-Drain control for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBODR_REG {
    Uint32  all;
    struct  GPBODR_BITS  bit;
};

struct GPBGMUX1_BITS {                        // bits description
    Uint32 GPIO32:2;                          // 1:0 Defines pin-muxing selection for GPIO32
    Uint32 GPIO33:2;                          // 3:2 Defines pin-muxing selection for GPIO33
    Uint32 GPIO34:2;                          // 5:4 Defines pin-muxing selection for GPIO34
    Uint32 GPIO35:2;                          // 7:6 Defines pin-muxing selection for GPIO35
    Uint32 rsvd1:2;                           // 9:8 Reserved
    Uint32 GPIO37:2;                          // 11:10 Defines pin-muxing selection for GPIO37
    Uint32 rsvd2:2;                           // 13:12 Reserved
    Uint32 GPIO39:2;                          // 15:14 Defines pin-muxing selection for GPIO39
    Uint32 GPIO40:2;                          // 17:16 Defines pin-muxing selection for GPIO40
    Uint32 GPIO41:2;                          // 19:18 Defines pin-muxing selection for GPIO41
    Uint32 GPIO42:2;                          // 21:20 Defines pin-muxing selection for GPIO42
    Uint32 GPIO43:2;                          // 23:22 Defines pin-muxing selection for GPIO43
    Uint32 GPIO44:2;                          // 25:24 Defines pin-muxing selection for GPIO44
    Uint32 GPIO45:2;                          // 27:26 Defines pin-muxing selection for GPIO45
    Uint32 GPIO46:2;                          // 29:28 Defines pin-muxing selection for GPIO46
    Uint32 GPIO47:2;                          // 31:30 Defines pin-muxing selection for GPIO47
};

union GPBGMUX1_REG {
    Uint32  all;
    struct  GPBGMUX1_BITS  bit;
};

struct GPBGMUX2_BITS {                        // bits description
    Uint32 GPIO48:2;                          // 1:0 Defines pin-muxing selection for GPIO48
    Uint32 GPIO49:2;                          // 3:2 Defines pin-muxing selection for GPIO49
    Uint32 GPIO50:2;                          // 5:4 Defines pin-muxing selection for GPIO50
    Uint32 GPIO51:2;                          // 7:6 Defines pin-muxing selection for GPIO51
    Uint32 GPIO52:2;                          // 9:8 Defines pin-muxing selection for GPIO52
    Uint32 GPIO53:2;                          // 11:10 Defines pin-muxing selection for GPIO53
    Uint32 GPIO54:2;                          // 13:12 Defines pin-muxing selection for GPIO54
    Uint32 GPIO55:2;                          // 15:14 Defines pin-muxing selection for GPIO55
    Uint32 GPIO56:2;                          // 17:16 Defines pin-muxing selection for GPIO56
    Uint32 GPIO57:2;                          // 19:18 Defines pin-muxing selection for GPIO57
    Uint32 GPIO58:2;                          // 21:20 Defines pin-muxing selection for GPIO58
    Uint32 GPIO59:2;                          // 23:22 Defines pin-muxing selection for GPIO59
    Uint32 rsvd1:2;                           // 25:24 Reserved
    Uint32 rsvd2:2;                           // 27:26 Reserved
    Uint32 rsvd3:2;                           // 29:28 Reserved
    Uint32 rsvd4:2;                           // 31:30 Reserved
};

union GPBGMUX2_REG {
    Uint32  all;
    struct  GPBGMUX2_BITS  bit;
};

struct GPBCSEL1_BITS {                        // bits description
    Uint32 GPIO32:4;                          // 3:0 GPIO32 Master CPU Select
    Uint32 GPIO33:4;                          // 7:4 GPIO33 Master CPU Select
    Uint32 GPIO34:4;                          // 11:8 GPIO34 Master CPU Select
    Uint32 GPIO35:4;                          // 15:12 GPIO35 Master CPU Select
    Uint32 rsvd1:4;                           // 19:16 Reserved
    Uint32 GPIO37:4;                          // 23:20 GPIO37 Master CPU Select
    Uint32 rsvd2:4;                           // 27:24 Reserved
    Uint32 GPIO39:4;                          // 31:28 GPIO39 Master CPU Select
};

union GPBCSEL1_REG {
    Uint32  all;
    struct  GPBCSEL1_BITS  bit;
};

struct GPBCSEL2_BITS {                        // bits description
    Uint32 GPIO40:4;                          // 3:0 GPIO40 Master CPU Select
    Uint32 GPIO41:4;                          // 7:4 GPIO41 Master CPU Select
    Uint32 GPIO42:4;                          // 11:8 GPIO42 Master CPU Select
    Uint32 GPIO43:4;                          // 15:12 GPIO43 Master CPU Select
    Uint32 GPIO44:4;                          // 19:16 GPIO44 Master CPU Select
    Uint32 GPIO45:4;                          // 23:20 GPIO45 Master CPU Select
    Uint32 GPIO46:4;                          // 27:24 GPIO46 Master CPU Select
    Uint32 GPIO47:4;                          // 31:28 GPIO47 Master CPU Select
};

union GPBCSEL2_REG {
    Uint32  all;
    struct  GPBCSEL2_BITS  bit;
};

struct GPBCSEL3_BITS {                        // bits description
    Uint32 GPIO48:4;                          // 3:0 GPIO48 Master CPU Select
    Uint32 GPIO49:4;                          // 7:4 GPIO49 Master CPU Select
    Uint32 GPIO50:4;                          // 11:8 GPIO50 Master CPU Select
    Uint32 GPIO51:4;                          // 15:12 GPIO51 Master CPU Select
    Uint32 GPIO52:4;                          // 19:16 GPIO52 Master CPU Select
    Uint32 GPIO53:4;                          // 23:20 GPIO53 Master CPU Select
    Uint32 GPIO54:4;                          // 27:24 GPIO54 Master CPU Select
    Uint32 GPIO55:4;                          // 31:28 GPIO55 Master CPU Select
};

union GPBCSEL3_REG {
    Uint32  all;
    struct  GPBCSEL3_BITS  bit;
};

struct GPBCSEL4_BITS {                        // bits description
    Uint32 GPIO56:4;                          // 3:0 GPIO56 Master CPU Select
    Uint32 GPIO57:4;                          // 7:4 GPIO57 Master CPU Select
    Uint32 GPIO58:4;                          // 11:8 GPIO58 Master CPU Select
    Uint32 GPIO59:4;                          // 15:12 GPIO59 Master CPU Select
    Uint32 rsvd1:4;                           // 19:16 Reserved
    Uint32 rsvd2:4;                           // 23:20 Reserved
    Uint32 rsvd3:4;                           // 27:24 Reserved
    Uint32 rsvd4:4;                           // 31:28 Reserved
};

union GPBCSEL4_REG {
    Uint32  all;
    struct  GPBCSEL4_BITS  bit;
};

struct GPBLOCK_BITS {                         // bits description
    Uint32 GPIO32:1;                          // 0 Configuration Lock bit for this pin
    Uint32 GPIO33:1;                          // 1 Configuration Lock bit for this pin
    Uint32 GPIO34:1;                          // 2 Configuration Lock bit for this pin
    Uint32 GPIO35:1;                          // 3 Configuration Lock bit for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Configuration Lock bit for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Configuration Lock bit for this pin
    Uint32 GPIO40:1;                          // 8 Configuration Lock bit for this pin
    Uint32 GPIO41:1;                          // 9 Configuration Lock bit for this pin
    Uint32 GPIO42:1;                          // 10 Configuration Lock bit for this pin
    Uint32 GPIO43:1;                          // 11 Configuration Lock bit for this pin
    Uint32 GPIO44:1;                          // 12 Configuration Lock bit for this pin
    Uint32 GPIO45:1;                          // 13 Configuration Lock bit for this pin
    Uint32 GPIO46:1;                          // 14 Configuration Lock bit for this pin
    Uint32 GPIO47:1;                          // 15 Configuration Lock bit for this pin
    Uint32 GPIO48:1;                          // 16 Configuration Lock bit for this pin
    Uint32 GPIO49:1;                          // 17 Configuration Lock bit for this pin
    Uint32 GPIO50:1;                          // 18 Configuration Lock bit for this pin
    Uint32 GPIO51:1;                          // 19 Configuration Lock bit for this pin
    Uint32 GPIO52:1;                          // 20 Configuration Lock bit for this pin
    Uint32 GPIO53:1;                          // 21 Configuration Lock bit for this pin
    Uint32 GPIO54:1;                          // 22 Configuration Lock bit for this pin
    Uint32 GPIO55:1;                          // 23 Configuration Lock bit for this pin
    Uint32 GPIO56:1;                          // 24 Configuration Lock bit for this pin
    Uint32 GPIO57:1;                          // 25 Configuration Lock bit for this pin
    Uint32 GPIO58:1;                          // 26 Configuration Lock bit for this pin
    Uint32 GPIO59:1;                          // 27 Configuration Lock bit for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBLOCK_REG {
    Uint32  all;
    struct  GPBLOCK_BITS  bit;
};

struct GPBCR_BITS {                           // bits description
    Uint32 GPIO32:1;                          // 0 Configuration lock commit bit for this pin
    Uint32 GPIO33:1;                          // 1 Configuration lock commit bit for this pin
    Uint32 GPIO34:1;                          // 2 Configuration lock commit bit for this pin
    Uint32 GPIO35:1;                          // 3 Configuration lock commit bit for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Configuration lock commit bit for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Configuration lock commit bit for this pin
    Uint32 GPIO40:1;                          // 8 Configuration lock commit bit for this pin
    Uint32 GPIO41:1;                          // 9 Configuration lock commit bit for this pin
    Uint32 GPIO42:1;                          // 10 Configuration lock commit bit for this pin
    Uint32 GPIO43:1;                          // 11 Configuration lock commit bit for this pin
    Uint32 GPIO44:1;                          // 12 Configuration lock commit bit for this pin
    Uint32 GPIO45:1;                          // 13 Configuration lock commit bit for this pin
    Uint32 GPIO46:1;                          // 14 Configuration lock commit bit for this pin
    Uint32 GPIO47:1;                          // 15 Configuration lock commit bit for this pin
    Uint32 GPIO48:1;                          // 16 Configuration lock commit bit for this pin
    Uint32 GPIO49:1;                          // 17 Configuration lock commit bit for this pin
    Uint32 GPIO50:1;                          // 18 Configuration lock commit bit for this pin
    Uint32 GPIO51:1;                          // 19 Configuration lock commit bit for this pin
    Uint32 GPIO52:1;                          // 20 Configuration lock commit bit for this pin
    Uint32 GPIO53:1;                          // 21 Configuration lock commit bit for this pin
    Uint32 GPIO54:1;                          // 22 Configuration lock commit bit for this pin
    Uint32 GPIO55:1;                          // 23 Configuration lock commit bit for this pin
    Uint32 GPIO56:1;                          // 24 Configuration lock commit bit for this pin
    Uint32 GPIO57:1;                          // 25 Configuration lock commit bit for this pin
    Uint32 GPIO58:1;                          // 26 Configuration lock commit bit for this pin
    Uint32 GPIO59:1;                          // 27 Configuration lock commit bit for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBCR_REG {
    Uint32  all;
    struct  GPBCR_BITS  bit;
};

struct GPADR1_BITS {                          // bits description
    Uint32 GPIO0:2;                           // 1:0 Control the actuation capability of this pin
    Uint32 GPIO1:2;                           // 3:2 Control the actuation capability of this pin
    Uint32 GPIO2:2;                           // 5:4 Control the actuation capability of this pin
    Uint32 GPIO3:2;                           // 7:6 Control the actuation capability of this pin
    Uint32 GPIO4:2;                           // 9:8 Control the actuation capability of this pin
    Uint32 GPIO5:2;                           // 11:10 Control the actuation capability of this pin
    Uint32 GPIO6:2;                           // 13:12 Control the actuation capability of this pin
    Uint32 GPIO7:2;                           // 15:14 Control the actuation capability of this pin
    Uint32 GPIO8:2;                           // 17:16 Control the actuation capability of this pin
    Uint32 GPIO9:2;                           // 19:18 Control the actuation capability of this pin
    Uint32 GPIO10:2;                          // 21:20 Control the actuation capability of this pin
    Uint32 GPIO11:2;                          // 23:22 Control the actuation capability of this pin
    Uint32 GPIO12:2;                          // 25:24 Control the actuation capability of this pin
    Uint32 GPIO13:2;                          // 27:26 Control the actuation capability of this pin
    Uint32 GPIO14:2;                          // 29:28 Control the actuation capability of this pin
    Uint32 GPIO15:2;                          // 31:30 Control the actuation capability of this pin
};

union GPADR1_REG {
    Uint32  all;
    struct  GPADR1_BITS  bit;
};

struct GPADR2_BITS {                          // bits description
    Uint32 GPIO16:2;                          // 1:0 Control the actuation capability of this pin
    Uint32 GPIO17:2;                          // 3:2 Control the actuation capability of this pin
    Uint32 GPIO18:2;                          // 5:4 Control the actuation capability of this pin
    Uint32 GPIO19:2;                          // 7:6 Control the actuation capability of this pin
    Uint32 GPIO20:2;                          // 9:8 Control the actuation capability of this pin
    Uint32 GPIO21:2;                          // 11:10 Control the actuation capability of this pin
    Uint32 GPIO22:2;                          // 13:12 Control the actuation capability of this pin
    Uint32 GPIO23:2;                          // 15:14 Control the actuation capability of this pin
    Uint32 GPIO24:2;                          // 17:16 Control the actuation capability of this pin
    Uint32 GPIO25:2;                          // 19:18 Control the actuation capability of this pin
    Uint32 GPIO26:2;                          // 21:20 Control the actuation capability of this pin
    Uint32 GPIO27:2;                          // 23:22 Control the actuation capability of this pin
    Uint32 GPIO28:2;                          // 25:24 Control the actuation capability of this pin
    Uint32 GPIO29:2;                          // 27:26 Control the actuation capability of this pin
    Uint32 GPIO30:2;                          // 29:28 Control the actuation capability of this pin
    Uint32 GPIO31:2;                          // 31:30 Control the actuation capability of this pin
};

union GPADR2_REG {
    Uint32  all;
    struct  GPADR2_BITS  bit;
};

struct GPBDR1_BITS {                          // bits description
    Uint32 GPIO32:2;                          // 1:0 Control the actuation capability of this pin
    Uint32 GPIO33:2;                          // 3:2 Control the actuation capability of this pin
    Uint32 GPIO34:2;                          // 5:4 Control the actuation capability of this pin
    Uint32 GPIO35:2;                          // 7:6 Control the actuation capability of this pin
    Uint32 rsvd1:2;                           // 9:8 Reserved
    Uint32 GPIO37:2;                          // 11:10 Control the actuation capability of this pin
    Uint32 rsvd2:2;                           // 13:12 Reserved
    Uint32 GPIO39:2;                          // 15:14 Control the actuation capability of this pin
    Uint32 GPIO40:2;                          // 17:16 Control the actuation capability of this pin
    Uint32 GPIO41:2;                          // 19:18 Control the actuation capability of this pin
    Uint32 GPIO42:2;                          // 21:20 Control the actuation capability of this pin
    Uint32 GPIO43:2;                          // 23:22 Control the actuation capability of this pin
    Uint32 GPIO44:2;                          // 25:24 Control the actuation capability of this pin
    Uint32 GPIO45:2;                          // 27:26 Control the actuation capability of this pin
    Uint32 GPIO46:2;                          // 29:28 Control the actuation capability of this pin
    Uint32 GPIO47:2;                          // 31:30 Control the actuation capability of this pin
};

union GPBDR1_REG {
    Uint32  all;
    struct  GPBDR1_BITS  bit;
};

struct GPBDR2_BITS {                          // bits description
    Uint32 GPIO48:2;                          // 1:0 Control the actuation capability of this pin
    Uint32 GPIO49:2;                          // 3:2 Control the actuation capability of this pin
    Uint32 GPIO50:2;                          // 5:4 Control the actuation capability of this pin
    Uint32 GPIO51:2;                          // 7:6 Control the actuation capability of this pin
    Uint32 GPIO52:2;                          // 9:8 Control the actuation capability of this pin
    Uint32 GPIO53:2;                          // 11:10 Control the actuation capability of this pin
    Uint32 GPIO54:2;                          // 13:12 Control the actuation capability of this pin
    Uint32 GPIO55:2;                          // 15:14 Control the actuation capability of this pin
    Uint32 GPIO56:2;                          // 17:16 Control the actuation capability of this pin
    Uint32 GPIO57:2;                          // 19:18 Control the actuation capability of this pin
    Uint32 GPIO58:2;                          // 21:20 Control the actuation capability of this pin
    Uint32 GPIO59:2;                          // 23:22 Control the actuation capability of this pin
    Uint32 rsvd1:2;                           // 25:24 Reserved
    Uint32 rsvd2:2;                           // 27:26 Reserved
    Uint32 rsvd3:2;                           // 29:28 Reserved
    Uint32 rsvd4:2;                           // 31:30 Reserved
};

union GPBDR2_REG {
    Uint32  all;
    struct  GPBDR2_BITS  bit;
};

struct GPCDR1_BITS {                          // bits description
    Uint32 GPIO64:2;                          // 1:0 Control the actuation capability of this pin
    Uint32 GPIO65:2;                          // 3:2 Control the actuation capability of this pin
    Uint32 GPIO66:2;                          // 5:4 Control the actuation capability of this pin
    Uint32 GPIO67:2;                          // 7:6 Control the actuation capability of this pin
    Uint32 GPIO68:2;                          // 9:8 Control the actuation capability of this pin
    Uint32 GPIO69:2;                          // 11:10 Control the actuation capability of this pin
    Uint32 GPIO70:2;                          // 13:12 Control the actuation capability of this pin
    Uint32 GPIO71:2;                          // 15:14 Control the actuation capability of this pin
    Uint32 GPIO72:2;                          // 17:16 Control the actuation capability of this pin
    Uint32 GPIO73:2;                          // 19:18 Control the actuation capability of this pin
    Uint32 GPIO74:2;                          // 21:20 Control the actuation capability of this pin
    Uint32 GPIO75:2;                          // 23:22 Control the actuation capability of this pin
    Uint32 GPIO76:2;                          // 25:24 Control the actuation capability of this pin
    Uint32 GPIO77:2;                          // 27:26 Control the actuation capability of this pin
    Uint32 GPIO78:2;                          // 29:28 Control the actuation capability of this pin
    Uint32 GPIO79:2;                          // 31:30 Control the actuation capability of this pin
};

union GPCDR1_REG {
    Uint32  all;
    struct  GPCDR1_BITS  bit;
};

struct GPCDR2_BITS {                          // bits description
    Uint32 GPIO80:2;                          // 1:0 Control the actuation capability of this pin
    Uint32 GPIO81:2;                          // 3:2 Control the actuation capability of this pin
    Uint32 GPIO82:2;                          // 5:4 Control the actuation capability of this pin
    Uint32 GPIO83:2;                          // 7:6 Control the actuation capability of this pin
    Uint32 GPIO84:2;                          // 9:8 Control the actuation capability of this pin
    Uint32 GPIO85:2;                          // 11:10 Control the actuation capability of this pin
    Uint32 GPIO86:2;                          // 13:12 Control the actuation capability of this pin
    Uint32 GPIO87:2;                          // 15:14 Control the actuation capability of this pin
    Uint32 GPIO88:2;                          // 17:16 Control the actuation capability of this pin
    Uint32 GPIO89:2;                          // 19:18 Control the actuation capability of this pin
    Uint32 GPIO90:2;                          // 21:20 Control the actuation capability of this pin
    Uint32 GPIO91:2;                          // 23:22 Control the actuation capability of this pin
    Uint32 GPIO92:2;                          // 25:24 Control the actuation capability of this pin
    Uint32 GPIO93:2;                          // 27:26 Control the actuation capability of this pin
    Uint32 GPIO94:2;                          // 29:28 Control the actuation capability of this pin
    Uint32 GPIO95:2;                          // 31:30 Control the actuation capability of this pin
};

union GPCDR2_REG {
    Uint32  all;
    struct  GPCDR2_BITS  bit;
};

struct GPCCTRL_BITS {                         // bits description
    Uint32 QUALPRD0:8;                        // 7:0 Qualification sampling period for GPIO64 to GPIO71
    Uint32 QUALPRD1:8;                        // 15:8 Qualification sampling period for GPIO72 to GPIO79
    Uint32 QUALPRD2:8;                        // 23:16 Qualification sampling period for GPIO80 to GPIO87
    Uint32 QUALPRD3:8;                        // 31:24 Qualification sampling period for GPIO88 to GPIO95
};

union GPCCTRL_REG {
    Uint32  all;
    struct  GPCCTRL_BITS  bit;
};

struct GPCQSEL1_BITS {                        // bits description
    Uint32 GPIO64:2;                          // 1:0 Select input qualification type for GPIO64
    Uint32 GPIO65:2;                          // 3:2 Select input qualification type for GPIO65
    Uint32 GPIO66:2;                          // 5:4 Select input qualification type for GPIO66
    Uint32 GPIO67:2;                          // 7:6 Select input qualification type for GPIO67
    Uint32 GPIO68:2;                          // 9:8 Select input qualification type for GPIO68
    Uint32 GPIO69:2;                          // 11:10 Select input qualification type for GPIO69
    Uint32 GPIO70:2;                          // 13:12 Select input qualification type for GPIO70
    Uint32 GPIO71:2;                          // 15:14 Select input qualification type for GPIO71
    Uint32 GPIO72:2;                          // 17:16 Select input qualification type for GPIO72
    Uint32 GPIO73:2;                          // 19:18 Select input qualification type for GPIO73
    Uint32 GPIO74:2;                          // 21:20 Select input qualification type for GPIO74
    Uint32 GPIO75:2;                          // 23:22 Select input qualification type for GPIO75
    Uint32 GPIO76:2;                          // 25:24 Select input qualification type for GPIO76
    Uint32 GPIO77:2;                          // 27:26 Select input qualification type for GPIO77
    Uint32 GPIO78:2;                          // 29:28 Select input qualification type for GPIO78
    Uint32 GPIO79:2;                          // 31:30 Select input qualification type for GPIO79
};

union GPCQSEL1_REG {
    Uint32  all;
    struct  GPCQSEL1_BITS  bit;
};

struct GPCQSEL2_BITS {                        // bits description
    Uint32 GPIO80:2;                          // 1:0 Select input qualification type for GPIO80
    Uint32 GPIO81:2;                          // 3:2 Select input qualification type for GPIO81
    Uint32 GPIO82:2;                          // 5:4 Select input qualification type for GPIO82
    Uint32 GPIO83:2;                          // 7:6 Select input qualification type for GPIO83
    Uint32 GPIO84:2;                          // 9:8 Select input qualification type for GPIO84
    Uint32 GPIO85:2;                          // 11:10 Select input qualification type for GPIO85
    Uint32 GPIO86:2;                          // 13:12 Select input qualification type for GPIO86
    Uint32 GPIO87:2;                          // 15:14 Select input qualification type for GPIO87
    Uint32 GPIO88:2;                          // 17:16 Select input qualification type for GPIO88
    Uint32 GPIO89:2;                          // 19:18 Select input qualification type for GPIO89
    Uint32 GPIO90:2;                          // 21:20 Select input qualification type for GPIO90
    Uint32 GPIO91:2;                          // 23:22 Select input qualification type for GPIO91
    Uint32 GPIO92:2;                          // 25:24 Select input qualification type for GPIO92
    Uint32 GPIO93:2;                          // 27:26 Select input qualification type for GPIO93
    Uint32 GPIO94:2;                          // 29:28 Select input qualification type for GPIO94
    Uint32 GPIO95:2;                          // 31:30 Select input qualification type for GPIO95
};

union GPCQSEL2_REG {
    Uint32  all;
    struct  GPCQSEL2_BITS  bit;
};

struct GPCDIR_BITS {                          // bits description
    Uint32 GPIO64:1;                          // 0 Defines pin-muxing selection for GPIO64
    Uint32 GPIO65:1;                          // 1 Defines pin-muxing selection for GPIO65
    Uint32 GPIO66:1;                          // 2 Defines pin-muxing selection for GPIO66
    Uint32 GPIO67:1;                          // 3 Defines pin-muxing selection for GPIO67
    Uint32 GPIO68:1;                          // 4 Defines pin-muxing selection for GPIO68
    Uint32 GPIO69:1;                          // 5 Defines pin-muxing selection for GPIO69
    Uint32 GPIO70:1;                          // 6 Defines pin-muxing selection for GPIO70
    Uint32 GPIO71:1;                          // 7 Defines pin-muxing selection for GPIO71
    Uint32 GPIO72:1;                          // 8 Defines pin-muxing selection for GPIO72
    Uint32 GPIO73:1;                          // 9 Defines pin-muxing selection for GPIO73
    Uint32 GPIO74:1;                          // 10 Defines pin-muxing selection for GPIO74
    Uint32 GPIO75:1;                          // 11 Defines pin-muxing selection for GPIO75
    Uint32 GPIO76:1;                          // 12 Defines pin-muxing selection for GPIO76
    Uint32 GPIO77:1;                          // 13 Defines pin-muxing selection for GPIO77
    Uint32 GPIO78:1;                          // 14 Defines pin-muxing selection for GPIO78
    Uint32 GPIO79:1;                          // 15 Defines pin-muxing selection for GPIO79
    Uint32 GPIO80:1;                          // 16 Defines pin-muxing selection for GPIO80
    Uint32 GPIO81:1;                          // 17 Defines pin-muxing selection for GPIO81
    Uint32 GPIO82:1;                          // 18 Defines pin-muxing selection for GPIO82
    Uint32 GPIO83:1;                          // 19 Defines pin-muxing selection for GPIO83
    Uint32 GPIO84:1;                          // 20 Defines pin-muxing selection for GPIO84
    Uint32 GPIO85:1;                          // 21 Defines pin-muxing selection for GPIO85
    Uint32 GPIO86:1;                          // 22 Defines pin-muxing selection for GPIO86
    Uint32 GPIO87:1;                          // 23 Defines pin-muxing selection for GPIO87
    Uint32 GPIO88:1;                          // 24 Defines pin-muxing selection for GPIO88
    Uint32 GPIO89:1;                          // 25 Defines pin-muxing selection for GPIO89
    Uint32 GPIO90:1;                          // 26 Defines pin-muxing selection for GPIO90
    Uint32 GPIO91:1;                          // 27 Defines pin-muxing selection for GPIO91
    Uint32 GPIO92:1;                          // 28 Defines pin-muxing selection for GPIO92
    Uint32 GPIO93:1;                          // 29 Defines pin-muxing selection for GPIO93
    Uint32 GPIO94:1;                          // 30 Defines pin-muxing selection for GPIO94
    Uint32 GPIO95:1;                          // 31 Defines pin-muxing selection for GPIO95
};

union GPCDIR_REG {
    Uint32  all;
    struct  GPCDIR_BITS  bit;
};

struct GPCPUD_BITS {                          // bits description
    Uint32 GPIO64:1;                          // 0 Defines pin-muxing selection for GPIO64
    Uint32 GPIO65:1;                          // 1 Defines pin-muxing selection for GPIO65
    Uint32 GPIO66:1;                          // 2 Defines pin-muxing selection for GPIO66
    Uint32 GPIO67:1;                          // 3 Defines pin-muxing selection for GPIO67
    Uint32 GPIO68:1;                          // 4 Defines pin-muxing selection for GPIO68
    Uint32 GPIO69:1;                          // 5 Defines pin-muxing selection for GPIO69
    Uint32 GPIO70:1;                          // 6 Defines pin-muxing selection for GPIO70
    Uint32 GPIO71:1;                          // 7 Defines pin-muxing selection for GPIO71
    Uint32 GPIO72:1;                          // 8 Defines pin-muxing selection for GPIO72
    Uint32 GPIO73:1;                          // 9 Defines pin-muxing selection for GPIO73
    Uint32 GPIO74:1;                          // 10 Defines pin-muxing selection for GPIO74
    Uint32 GPIO75:1;                          // 11 Defines pin-muxing selection for GPIO75
    Uint32 GPIO76:1;                          // 12 Defines pin-muxing selection for GPIO76
    Uint32 GPIO77:1;                          // 13 Defines pin-muxing selection for GPIO77
    Uint32 GPIO78:1;                          // 14 Defines pin-muxing selection for GPIO78
    Uint32 GPIO79:1;                          // 15 Defines pin-muxing selection for GPIO79
    Uint32 GPIO80:1;                          // 16 Defines pin-muxing selection for GPIO80
    Uint32 GPIO81:1;                          // 17 Defines pin-muxing selection for GPIO81
    Uint32 GPIO82:1;                          // 18 Defines pin-muxing selection for GPIO82
    Uint32 GPIO83:1;                          // 19 Defines pin-muxing selection for GPIO83
    Uint32 GPIO84:1;                          // 20 Defines pin-muxing selection for GPIO84
    Uint32 GPIO85:1;                          // 21 Defines pin-muxing selection for GPIO85
    Uint32 GPIO86:1;                          // 22 Defines pin-muxing selection for GPIO86
    Uint32 GPIO87:1;                          // 23 Defines pin-muxing selection for GPIO87
    Uint32 GPIO88:1;                          // 24 Defines pin-muxing selection for GPIO88
    Uint32 GPIO89:1;                          // 25 Defines pin-muxing selection for GPIO89
    Uint32 GPIO90:1;                          // 26 Defines pin-muxing selection for GPIO90
    Uint32 GPIO91:1;                          // 27 Defines pin-muxing selection for GPIO91
    Uint32 GPIO92:1;                          // 28 Defines pin-muxing selection for GPIO92
    Uint32 GPIO93:1;                          // 29 Defines pin-muxing selection for GPIO93
    Uint32 GPIO94:1;                          // 30 Defines pin-muxing selection for GPIO94
    Uint32 GPIO95:1;                          // 31 Defines pin-muxing selection for GPIO95
};

union GPCPUD_REG {
    Uint32  all;
    struct  GPCPUD_BITS  bit;
};

struct GPCINV_BITS {                          // bits description
    Uint32 GPIO64:1;                          // 0 Defines direction for this pin in GPIO mode
    Uint32 GPIO65:1;                          // 1 Defines direction for this pin in GPIO mode
    Uint32 GPIO66:1;                          // 2 Defines direction for this pin in GPIO mode
    Uint32 GPIO67:1;                          // 3 Defines direction for this pin in GPIO mode
    Uint32 GPIO68:1;                          // 4 Defines direction for this pin in GPIO mode
    Uint32 GPIO69:1;                          // 5 Defines direction for this pin in GPIO mode
    Uint32 GPIO70:1;                          // 6 Defines direction for this pin in GPIO mode
    Uint32 GPIO71:1;                          // 7 Defines direction for this pin in GPIO mode
    Uint32 GPIO72:1;                          // 8 Defines direction for this pin in GPIO mode
    Uint32 GPIO73:1;                          // 9 Defines direction for this pin in GPIO mode
    Uint32 GPIO74:1;                          // 10 Defines direction for this pin in GPIO mode
    Uint32 GPIO75:1;                          // 11 Defines direction for this pin in GPIO mode
    Uint32 GPIO76:1;                          // 12 Defines direction for this pin in GPIO mode
    Uint32 GPIO77:1;                          // 13 Defines direction for this pin in GPIO mode
    Uint32 GPIO78:1;                          // 14 Defines direction for this pin in GPIO mode
    Uint32 GPIO79:1;                          // 15 Defines direction for this pin in GPIO mode
    Uint32 GPIO80:1;                          // 16 Defines direction for this pin in GPIO mode
    Uint32 GPIO81:1;                          // 17 Defines direction for this pin in GPIO mode
    Uint32 GPIO82:1;                          // 18 Defines direction for this pin in GPIO mode
    Uint32 GPIO83:1;                          // 19 Defines direction for this pin in GPIO mode
    Uint32 GPIO84:1;                          // 20 Defines direction for this pin in GPIO mode
    Uint32 GPIO85:1;                          // 21 Defines direction for this pin in GPIO mode
    Uint32 GPIO86:1;                          // 22 Defines direction for this pin in GPIO mode
    Uint32 GPIO87:1;                          // 23 Defines direction for this pin in GPIO mode
    Uint32 GPIO88:1;                          // 24 Defines direction for this pin in GPIO mode
    Uint32 GPIO89:1;                          // 25 Defines direction for this pin in GPIO mode
    Uint32 GPIO90:1;                          // 26 Defines direction for this pin in GPIO mode
    Uint32 GPIO91:1;                          // 27 Defines direction for this pin in GPIO mode
    Uint32 GPIO92:1;                          // 28 Defines direction for this pin in GPIO mode
    Uint32 GPIO93:1;                          // 29 Defines direction for this pin in GPIO mode
    Uint32 GPIO94:1;                          // 30 Defines direction for this pin in GPIO mode
    Uint32 GPIO95:1;                          // 31 Defines direction for this pin in GPIO mode
};

union GPCINV_REG {
    Uint32  all;
    struct  GPCINV_BITS  bit;
};

struct GPCODR_BITS {                          // bits description
    Uint32 GPIO64:1;                          // 0 Output Open-Drain control for this pin
    Uint32 GPIO65:1;                          // 1 Output Open-Drain control for this pin
    Uint32 GPIO66:1;                          // 2 Output Open-Drain control for this pin
    Uint32 GPIO67:1;                          // 3 Output Open-Drain control for this pin
    Uint32 GPIO68:1;                          // 4 Output Open-Drain control for this pin
    Uint32 GPIO69:1;                          // 5 Output Open-Drain control for this pin
    Uint32 GPIO70:1;                          // 6 Output Open-Drain control for this pin
    Uint32 GPIO71:1;                          // 7 Output Open-Drain control for this pin
    Uint32 GPIO72:1;                          // 8 Output Open-Drain control for this pin
    Uint32 GPIO73:1;                          // 9 Output Open-Drain control for this pin
    Uint32 GPIO74:1;                          // 10 Output Open-Drain control for this pin
    Uint32 GPIO75:1;                          // 11 Output Open-Drain control for this pin
    Uint32 GPIO76:1;                          // 12 Output Open-Drain control for this pin
    Uint32 GPIO77:1;                          // 13 Output Open-Drain control for this pin
    Uint32 GPIO78:1;                          // 14 Output Open-Drain control for this pin
    Uint32 GPIO79:1;                          // 15 Output Open-Drain control for this pin
    Uint32 GPIO80:1;                          // 16 Output Open-Drain control for this pin
    Uint32 GPIO81:1;                          // 17 Output Open-Drain control for this pin
    Uint32 GPIO82:1;                          // 18 Output Open-Drain control for this pin
    Uint32 GPIO83:1;                          // 19 Output Open-Drain control for this pin
    Uint32 GPIO84:1;                          // 20 Output Open-Drain control for this pin
    Uint32 GPIO85:1;                          // 21 Output Open-Drain control for this pin
    Uint32 GPIO86:1;                          // 22 Output Open-Drain control for this pin
    Uint32 GPIO87:1;                          // 23 Output Open-Drain control for this pin
    Uint32 GPIO88:1;                          // 24 Output Open-Drain control for this pin
    Uint32 GPIO89:1;                          // 25 Output Open-Drain control for this pin
    Uint32 GPIO90:1;                          // 26 Output Open-Drain control for this pin
    Uint32 GPIO91:1;                          // 27 Output Open-Drain control for this pin
    Uint32 GPIO92:1;                          // 28 Output Open-Drain control for this pin
    Uint32 GPIO93:1;                          // 29 Output Open-Drain control for this pin
    Uint32 GPIO94:1;                          // 30 Output Open-Drain control for this pin
    Uint32 GPIO95:1;                          // 31 Output Open-Drain control for this pin
};

union GPCODR_REG {
    Uint32  all;
    struct  GPCODR_BITS  bit;
};

struct GPCCSEL1_BITS {                        // bits description
    Uint32 GPIO64:4;                          // 3:0 GPIO64 Master CPU Select
    Uint32 GPIO65:4;                          // 7:4 GPIO65 Master CPU Select
    Uint32 GPIO66:4;                          // 11:8 GPIO66 Master CPU Select
    Uint32 GPIO67:4;                          // 15:12 GPIO67 Master CPU Select
    Uint32 GPIO68:4;                          // 19:16 GPIO68 Master CPU Select
    Uint32 GPIO69:4;                          // 23:20 GPIO69 Master CPU Select
    Uint32 GPIO70:4;                          // 27:24 GPIO70 Master CPU Select
    Uint32 GPIO71:4;                          // 31:28 GPIO71 Master CPU Select
};

union GPCCSEL1_REG {
    Uint32  all;
    struct  GPCCSEL1_BITS  bit;
};

struct GPCCSEL2_BITS {                        // bits description
    Uint32 GPIO72:4;                          // 3:0 GPIO72 Master CPU Select
    Uint32 GPIO73:4;                          // 7:4 GPIO73 Master CPU Select
    Uint32 GPIO74:4;                          // 11:8 GPIO74 Master CPU Select
    Uint32 GPIO75:4;                          // 15:12 GPIO75 Master CPU Select
    Uint32 GPIO76:4;                          // 19:16 GPIO76 Master CPU Select
    Uint32 GPIO77:4;                          // 23:20 GPIO77 Master CPU Select
    Uint32 GPIO78:4;                          // 27:24 GPIO78 Master CPU Select
    Uint32 GPIO79:4;                          // 31:28 GPIO79 Master CPU Select
};

union GPCCSEL2_REG {
    Uint32  all;
    struct  GPCCSEL2_BITS  bit;
};

struct GPCCSEL3_BITS {                        // bits description
    Uint32 GPIO80:4;                          // 3:0 GPIO80 Master CPU Select
    Uint32 GPIO81:4;                          // 7:4 GPIO81 Master CPU Select
    Uint32 GPIO82:4;                          // 11:8 GPIO82 Master CPU Select
    Uint32 GPIO83:4;                          // 15:12 GPIO83 Master CPU Select
    Uint32 GPIO84:4;                          // 19:16 GPIO84 Master CPU Select
    Uint32 GPIO85:4;                          // 23:20 GPIO85 Master CPU Select
    Uint32 GPIO86:4;                          // 27:24 GPIO86 Master CPU Select
    Uint32 GPIO87:4;                          // 31:28 GPIO87 Master CPU Select
};

union GPCCSEL3_REG {
    Uint32  all;
    struct  GPCCSEL3_BITS  bit;
};

struct GPCCSEL4_BITS {                        // bits description
    Uint32 GPIO88:4;                          // 3:0 GPIO88 Master CPU Select
    Uint32 GPIO89:4;                          // 7:4 GPIO89 Master CPU Select
    Uint32 GPIO90:4;                          // 11:8 GPIO90 Master CPU Select
    Uint32 GPIO91:4;                          // 15:12 GPIO91 Master CPU Select
    Uint32 GPIO92:4;                          // 19:16 GPIO92 Master CPU Select
    Uint32 GPIO93:4;                          // 23:20 GPIO93 Master CPU Select
    Uint32 GPIO94:4;                          // 27:24 GPIO94 Master CPU Select
    Uint32 GPIO95:4;                          // 31:28 GPIO95 Master CPU Select
};

union GPCCSEL4_REG {
    Uint32  all;
    struct  GPCCSEL4_BITS  bit;
};

struct GPCLOCK_BITS {                         // bits description
    Uint32 GPIO64:1;                          // 0 Configuration Lock bit for this pin
    Uint32 GPIO65:1;                          // 1 Configuration Lock bit for this pin
    Uint32 GPIO66:1;                          // 2 Configuration Lock bit for this pin
    Uint32 GPIO67:1;                          // 3 Configuration Lock bit for this pin
    Uint32 GPIO68:1;                          // 4 Configuration Lock bit for this pin
    Uint32 GPIO69:1;                          // 5 Configuration Lock bit for this pin
    Uint32 GPIO70:1;                          // 6 Configuration Lock bit for this pin
    Uint32 GPIO71:1;                          // 7 Configuration Lock bit for this pin
    Uint32 GPIO72:1;                          // 8 Configuration Lock bit for this pin
    Uint32 GPIO73:1;                          // 9 Configuration Lock bit for this pin
    Uint32 GPIO74:1;                          // 10 Configuration Lock bit for this pin
    Uint32 GPIO75:1;                          // 11 Configuration Lock bit for this pin
    Uint32 GPIO76:1;                          // 12 Configuration Lock bit for this pin
    Uint32 GPIO77:1;                          // 13 Configuration Lock bit for this pin
    Uint32 GPIO78:1;                          // 14 Configuration Lock bit for this pin
    Uint32 GPIO79:1;                          // 15 Configuration Lock bit for this pin
    Uint32 GPIO80:1;                          // 16 Configuration Lock bit for this pin
    Uint32 GPIO81:1;                          // 17 Configuration Lock bit for this pin
    Uint32 GPIO82:1;                          // 18 Configuration Lock bit for this pin
    Uint32 GPIO83:1;                          // 19 Configuration Lock bit for this pin
    Uint32 GPIO84:1;                          // 20 Configuration Lock bit for this pin
    Uint32 GPIO85:1;                          // 21 Configuration Lock bit for this pin
    Uint32 GPIO86:1;                          // 22 Configuration Lock bit for this pin
    Uint32 GPIO87:1;                          // 23 Configuration Lock bit for this pin
    Uint32 GPIO88:1;                          // 24 Configuration Lock bit for this pin
    Uint32 GPIO89:1;                          // 25 Configuration Lock bit for this pin
    Uint32 GPIO90:1;                          // 26 Configuration Lock bit for this pin
    Uint32 GPIO91:1;                          // 27 Configuration Lock bit for this pin
    Uint32 GPIO92:1;                          // 28 Configuration Lock bit for this pin
    Uint32 GPIO93:1;                          // 29 Configuration Lock bit for this pin
    Uint32 GPIO94:1;                          // 30 Configuration Lock bit for this pin
    Uint32 GPIO95:1;                          // 31 Configuration Lock bit for this pin
};

union GPCLOCK_REG {
    Uint32  all;
    struct  GPCLOCK_BITS  bit;
};

struct GPCCR_BITS {                           // bits description
    Uint32 GPIO64:1;                          // 0 Configuration lock commit bit for this pin
    Uint32 GPIO65:1;                          // 1 Configuration lock commit bit for this pin
    Uint32 GPIO66:1;                          // 2 Configuration lock commit bit for this pin
    Uint32 GPIO67:1;                          // 3 Configuration lock commit bit for this pin
    Uint32 GPIO68:1;                          // 4 Configuration lock commit bit for this pin
    Uint32 GPIO69:1;                          // 5 Configuration lock commit bit for this pin
    Uint32 GPIO70:1;                          // 6 Configuration lock commit bit for this pin
    Uint32 GPIO71:1;                          // 7 Configuration lock commit bit for this pin
    Uint32 GPIO72:1;                          // 8 Configuration lock commit bit for this pin
    Uint32 GPIO73:1;                          // 9 Configuration lock commit bit for this pin
    Uint32 GPIO74:1;                          // 10 Configuration lock commit bit for this pin
    Uint32 GPIO75:1;                          // 11 Configuration lock commit bit for this pin
    Uint32 GPIO76:1;                          // 12 Configuration lock commit bit for this pin
    Uint32 GPIO77:1;                          // 13 Configuration lock commit bit for this pin
    Uint32 GPIO78:1;                          // 14 Configuration lock commit bit for this pin
    Uint32 GPIO79:1;                          // 15 Configuration lock commit bit for this pin
    Uint32 GPIO80:1;                          // 16 Configuration lock commit bit for this pin
    Uint32 GPIO81:1;                          // 17 Configuration lock commit bit for this pin
    Uint32 GPIO82:1;                          // 18 Configuration lock commit bit for this pin
    Uint32 GPIO83:1;                          // 19 Configuration lock commit bit for this pin
    Uint32 GPIO84:1;                          // 20 Configuration lock commit bit for this pin
    Uint32 GPIO85:1;                          // 21 Configuration lock commit bit for this pin
    Uint32 GPIO86:1;                          // 22 Configuration lock commit bit for this pin
    Uint32 GPIO87:1;                          // 23 Configuration lock commit bit for this pin
    Uint32 GPIO88:1;                          // 24 Configuration lock commit bit for this pin
    Uint32 GPIO89:1;                          // 25 Configuration lock commit bit for this pin
    Uint32 GPIO90:1;                          // 26 Configuration lock commit bit for this pin
    Uint32 GPIO91:1;                          // 27 Configuration lock commit bit for this pin
    Uint32 GPIO92:1;                          // 28 Configuration lock commit bit for this pin
    Uint32 GPIO93:1;                          // 29 Configuration lock commit bit for this pin
    Uint32 GPIO94:1;                          // 30 Configuration lock commit bit for this pin
    Uint32 GPIO95:1;                          // 31 Configuration lock commit bit for this pin
};

union GPCCR_REG {
    Uint32  all;
    struct  GPCCR_BITS  bit;
};

struct GPHCTRL_BITS {                         // bits description
    Uint32 QUALPRD0:8;                        // 7:0 Qualification sampling period for GPIO224 to GPIO231
    Uint32 QUALPRD1:8;                        // 15:8 Qualification sampling period for GPIO232 to GPIO239
    Uint32 QUALPRD2:8;                        // 23:16 Qualification sampling period for GPIO240 to GPIO247
    Uint32 rsvd1:8;                           // 31:24 Reserved
};

union GPHCTRL_REG {
    Uint32  all;
    struct  GPHCTRL_BITS  bit;
};

struct GPHQSEL1_BITS {                        // bits description
    Uint32 GPIO224:2;                         // 1:0 Select input qualification type for this GPIO Pin
    Uint32 GPIO225:2;                         // 3:2 Select input qualification type for this GPIO Pin
    Uint32 GPIO226:2;                         // 5:4 Select input qualification type for this GPIO Pin
    Uint32 GPIO227:2;                         // 7:6 Select input qualification type for this GPIO Pin
    Uint32 GPIO228:2;                         // 9:8 Select input qualification type for this GPIO Pin
    Uint32 GPIO229:2;                         // 11:10 Select input qualification type for this GPIO Pin
    Uint32 GPIO230:2;                         // 13:12 Select input qualification type for this GPIO Pin
    Uint32 GPIO231:2;                         // 15:14 Select input qualification type for this GPIO Pin
    Uint32 GPIO232:2;                         // 17:16 Select input qualification type for this GPIO Pin
    Uint32 GPIO233:2;                         // 19:18 Select input qualification type for this GPIO Pin
    Uint32 GPIO234:2;                         // 21:20 Select input qualification type for this GPIO Pin
    Uint32 GPIO235:2;                         // 23:22 Select input qualification type for this GPIO Pin
    Uint32 GPIO236:2;                         // 25:24 Select input qualification type for this GPIO Pin
    Uint32 GPIO237:2;                         // 27:26 Select input qualification type for this GPIO Pin
    Uint32 GPIO238:2;                         // 29:28 Select input qualification type for this GPIO Pin
    Uint32 GPIO239:2;                         // 31:30 Select input qualification type for this GPIO Pin
};

union GPHQSEL1_REG {
    Uint32  all;
    struct  GPHQSEL1_BITS  bit;
};

struct GPHQSEL2_BITS {                        // bits description
    Uint32 GPIO240:2;                         // 1:0 Select input qualification type for this GPIO Pin
    Uint32 GPIO241:2;                         // 3:2 Select input qualification type for this GPIO Pin
    Uint32 GPIO242:2;                         // 5:4 Select input qualification type for this GPIO Pin
    Uint32 GPIO243:2;                         // 7:6 Select input qualification type for this GPIO Pin
    Uint32 GPIO244:2;                         // 9:8 Select input qualification type for this GPIO Pin
    Uint32 GPIO245:2;                         // 11:10 Select input qualification type for this GPIO Pin
    Uint32 GPIO246:2;                         // 13:12 Select input qualification type for this GPIO Pin
    Uint32 GPIO247:2;                         // 15:14 Select input qualification type for this GPIO Pin
    Uint32 rsvd1:2;                           // 17:16 Reserved
    Uint32 rsvd2:2;                           // 19:18 Reserved
    Uint32 rsvd3:2;                           // 21:20 Reserved
    Uint32 rsvd4:2;                           // 23:22 Reserved
    Uint32 rsvd5:2;                           // 25:24 Reserved
    Uint32 rsvd6:2;                           // 27:26 Reserved
    Uint32 rsvd7:2;                           // 29:28 Reserved
    Uint32 rsvd8:2;                           // 31:30 Reserved
};

union GPHQSEL2_REG {
    Uint32  all;
    struct  GPHQSEL2_BITS  bit;
};

struct GPHPUD_BITS {                          // bits description
    Uint32 GPIO224:1;                         // 0 Pull-Up Disable control for this pin
    Uint32 GPIO225:1;                         // 1 Pull-Up Disable control for this pin
    Uint32 GPIO226:1;                         // 2 Pull-Up Disable control for this pin
    Uint32 GPIO227:1;                         // 3 Pull-Up Disable control for this pin
    Uint32 GPIO228:1;                         // 4 Pull-Up Disable control for this pin
    Uint32 GPIO229:1;                         // 5 Pull-Up Disable control for this pin
    Uint32 GPIO230:1;                         // 6 Pull-Up Disable control for this pin
    Uint32 GPIO231:1;                         // 7 Pull-Up Disable control for this pin
    Uint32 GPIO232:1;                         // 8 Pull-Up Disable control for this pin
    Uint32 GPIO233:1;                         // 9 Pull-Up Disable control for this pin
    Uint32 GPIO234:1;                         // 10 Pull-Up Disable control for this pin
    Uint32 GPIO235:1;                         // 11 Pull-Up Disable control for this pin
    Uint32 GPIO236:1;                         // 12 Pull-Up Disable control for this pin
    Uint32 GPIO237:1;                         // 13 Pull-Up Disable control for this pin
    Uint32 GPIO238:1;                         // 14 Pull-Up Disable control for this pin
    Uint32 GPIO239:1;                         // 15 Pull-Up Disable control for this pin
    Uint32 GPIO240:1;                         // 16 Pull-Up Disable control for this pin
    Uint32 GPIO241:1;                         // 17 Pull-Up Disable control for this pin
    Uint32 GPIO242:1;                         // 18 Pull-Up Disable control for this pin
    Uint32 GPIO243:1;                         // 19 Pull-Up Disable control for this pin
    Uint32 GPIO244:1;                         // 20 Pull-Up Disable control for this pin
    Uint32 GPIO245:1;                         // 21 Pull-Up Disable control for this pin
    Uint32 GPIO246:1;                         // 22 Pull-Up Disable control for this pin
    Uint32 GPIO247:1;                         // 23 Pull-Up Disable control for this pin
    Uint32 rsvd1:1;                           // 24 Reserved
    Uint32 rsvd2:1;                           // 25 Reserved
    Uint32 rsvd3:1;                           // 26 Reserved
    Uint32 rsvd4:1;                           // 27 Reserved
    Uint32 rsvd5:1;                           // 28 Reserved
    Uint32 rsvd6:1;                           // 29 Reserved
    Uint32 rsvd7:1;                           // 30 Reserved
    Uint32 rsvd8:1;                           // 31 Reserved
};

union GPHPUD_REG {
    Uint32  all;
    struct  GPHPUD_BITS  bit;
};

struct GPHINV_BITS {                          // bits description
    Uint32 GPIO224:1;                         // 0 Input inversion control for this pin
    Uint32 GPIO225:1;                         // 1 Input inversion control for this pin
    Uint32 GPIO226:1;                         // 2 Input inversion control for this pin
    Uint32 GPIO227:1;                         // 3 Input inversion control for this pin
    Uint32 GPIO228:1;                         // 4 Input inversion control for this pin
    Uint32 GPIO229:1;                         // 5 Input inversion control for this pin
    Uint32 GPIO230:1;                         // 6 Input inversion control for this pin
    Uint32 GPIO231:1;                         // 7 Input inversion control for this pin
    Uint32 GPIO232:1;                         // 8 Input inversion control for this pin
    Uint32 GPIO233:1;                         // 9 Input inversion control for this pin
    Uint32 GPIO234:1;                         // 10 Input inversion control for this pin
    Uint32 GPIO235:1;                         // 11 Input inversion control for this pin
    Uint32 GPIO236:1;                         // 12 Input inversion control for this pin
    Uint32 GPIO237:1;                         // 13 Input inversion control for this pin
    Uint32 GPIO238:1;                         // 14 Input inversion control for this pin
    Uint32 GPIO239:1;                         // 15 Input inversion control for this pin
    Uint32 GPIO240:1;                         // 16 Input inversion control for this pin
    Uint32 GPIO241:1;                         // 17 Input inversion control for this pin
    Uint32 GPIO242:1;                         // 18 Input inversion control for this pin
    Uint32 GPIO243:1;                         // 19 Input inversion control for this pin
    Uint32 GPIO244:1;                         // 20 Input inversion control for this pin
    Uint32 GPIO245:1;                         // 21 Input inversion control for this pin
    Uint32 GPIO246:1;                         // 22 Input inversion control for this pin
    Uint32 GPIO247:1;                         // 23 Input inversion control for this pin
    Uint32 rsvd1:1;                           // 24 Reserved
    Uint32 rsvd2:1;                           // 25 Reserved
    Uint32 rsvd3:1;                           // 26 Reserved
    Uint32 rsvd4:1;                           // 27 Reserved
    Uint32 rsvd5:1;                           // 28 Reserved
    Uint32 rsvd6:1;                           // 29 Reserved
    Uint32 rsvd7:1;                           // 30 Reserved
    Uint32 rsvd8:1;                           // 31 Reserved
};

union GPHINV_REG {
    Uint32  all;
    struct  GPHINV_BITS  bit;
};

struct GPHAMSEL_BITS {                        // bits description
    Uint32 GPIO224:1;                         // 0 Analog Mode select for this pin
    Uint32 GPIO225:1;                         // 1 Analog Mode select for this pin
    Uint32 GPIO226:1;                         // 2 Analog Mode select for this pin
    Uint32 GPIO227:1;                         // 3 Analog Mode select for this pin
    Uint32 GPIO228:1;                         // 4 Analog Mode select for this pin
    Uint32 GPIO229:1;                         // 5 Analog Mode select for this pin
    Uint32 GPIO230:1;                         // 6 Analog Mode select for this pin
    Uint32 GPIO231:1;                         // 7 Analog Mode select for this pin
    Uint32 GPIO232:1;                         // 8 Analog Mode select for this pin
    Uint32 GPIO233:1;                         // 9 Analog Mode select for this pin
    Uint32 GPIO234:1;                         // 10 Analog Mode select for this pin
    Uint32 GPIO235:1;                         // 11 Analog Mode select for this pin
    Uint32 GPIO236:1;                         // 12 Analog Mode select for this pin
    Uint32 GPIO237:1;                         // 13 Analog Mode select for this pin
    Uint32 GPIO238:1;                         // 14 Analog Mode select for this pin
    Uint32 GPIO239:1;                         // 15 Analog Mode select for this pin
    Uint32 GPIO240:1;                         // 16 Analog Mode select for this pin
    Uint32 GPIO241:1;                         // 17 Analog Mode select for this pin
    Uint32 GPIO242:1;                         // 18 Analog Mode select for this pin
    Uint32 GPIO243:1;                         // 19 Analog Mode select for this pin
    Uint32 GPIO244:1;                         // 20 Analog Mode select for this pin
    Uint32 GPIO245:1;                         // 21 Analog Mode select for this pin
    Uint32 GPIO246:1;                         // 22 Analog Mode select for this pin
    Uint32 GPIO247:1;                         // 23 Analog Mode select for this pin
    Uint32 rsvd1:1;                           // 24 Reserved
    Uint32 rsvd2:1;                           // 25 Reserved
    Uint32 rsvd3:1;                           // 26 Reserved
    Uint32 rsvd4:1;                           // 27 Reserved
    Uint32 rsvd5:1;                           // 28 Reserved
    Uint32 rsvd6:1;                           // 29 Reserved
    Uint32 rsvd7:1;                           // 30 Reserved
    Uint32 rsvd8:1;                           // 31 Reserved
};

union GPHAMSEL_REG {
    Uint32  all;
    struct  GPHAMSEL_BITS  bit;
};

struct GPHLOCK_BITS {                         // bits description
    Uint32 GPIO224:1;                         // 0 Configuration Lock bit for this pin
    Uint32 GPIO225:1;                         // 1 Configuration Lock bit for this pin
    Uint32 GPIO226:1;                         // 2 Configuration Lock bit for this pin
    Uint32 GPIO227:1;                         // 3 Configuration Lock bit for this pin
    Uint32 GPIO228:1;                         // 4 Configuration Lock bit for this pin
    Uint32 GPIO229:1;                         // 5 Configuration Lock bit for this pin
    Uint32 GPIO230:1;                         // 6 Configuration Lock bit for this pin
    Uint32 GPIO231:1;                         // 7 Configuration Lock bit for this pin
    Uint32 GPIO232:1;                         // 8 Configuration Lock bit for this pin
    Uint32 GPIO233:1;                         // 9 Configuration Lock bit for this pin
    Uint32 GPIO234:1;                         // 10 Configuration Lock bit for this pin
    Uint32 GPIO235:1;                         // 11 Configuration Lock bit for this pin
    Uint32 GPIO236:1;                         // 12 Configuration Lock bit for this pin
    Uint32 GPIO237:1;                         // 13 Configuration Lock bit for this pin
    Uint32 GPIO238:1;                         // 14 Configuration Lock bit for this pin
    Uint32 GPIO239:1;                         // 15 Configuration Lock bit for this pin
    Uint32 GPIO240:1;                         // 16 Configuration Lock bit for this pin
    Uint32 GPIO241:1;                         // 17 Configuration Lock bit for this pin
    Uint32 GPIO242:1;                         // 18 Configuration Lock bit for this pin
    Uint32 GPIO243:1;                         // 19 Configuration Lock bit for this pin
    Uint32 GPIO244:1;                         // 20 Configuration Lock bit for this pin
    Uint32 GPIO245:1;                         // 21 Configuration Lock bit for this pin
    Uint32 GPIO246:1;                         // 22 Configuration Lock bit for this pin
    Uint32 GPIO247:1;                         // 23 Configuration Lock bit for this pin
    Uint32 rsvd1:1;                           // 24 Reserved
    Uint32 rsvd2:1;                           // 25 Reserved
    Uint32 rsvd3:1;                           // 26 Reserved
    Uint32 rsvd4:1;                           // 27 Reserved
    Uint32 rsvd5:1;                           // 28 Reserved
    Uint32 rsvd6:1;                           // 29 Reserved
    Uint32 rsvd7:1;                           // 30 Reserved
    Uint32 rsvd8:1;                           // 31 Reserved
};

union GPHLOCK_REG {
    Uint32  all;
    struct  GPHLOCK_BITS  bit;
};

struct GPHCR_BITS {                           // bits description
    Uint32 GPIO224:1;                         // 0 Configuration lock commit bit for this pin
    Uint32 GPIO225:1;                         // 1 Configuration lock commit bit for this pin
    Uint32 GPIO226:1;                         // 2 Configuration lock commit bit for this pin
    Uint32 GPIO227:1;                         // 3 Configuration lock commit bit for this pin
    Uint32 GPIO228:1;                         // 4 Configuration lock commit bit for this pin
    Uint32 GPIO229:1;                         // 5 Configuration lock commit bit for this pin
    Uint32 GPIO230:1;                         // 6 Configuration lock commit bit for this pin
    Uint32 GPIO231:1;                         // 7 Configuration lock commit bit for this pin
    Uint32 GPIO232:1;                         // 8 Configuration lock commit bit for this pin
    Uint32 GPIO233:1;                         // 9 Configuration lock commit bit for this pin
    Uint32 GPIO234:1;                         // 10 Configuration lock commit bit for this pin
    Uint32 GPIO235:1;                         // 11 Configuration lock commit bit for this pin
    Uint32 GPIO236:1;                         // 12 Configuration lock commit bit for this pin
    Uint32 GPIO237:1;                         // 13 Configuration lock commit bit for this pin
    Uint32 GPIO238:1;                         // 14 Configuration lock commit bit for this pin
    Uint32 GPIO239:1;                         // 15 Configuration lock commit bit for this pin
    Uint32 GPIO240:1;                         // 16 Configuration lock commit bit for this pin
    Uint32 GPIO241:1;                         // 17 Configuration lock commit bit for this pin
    Uint32 GPIO242:1;                         // 18 Configuration lock commit bit for this pin
    Uint32 GPIO243:1;                         // 19 Configuration lock commit bit for this pin
    Uint32 GPIO244:1;                         // 20 Configuration lock commit bit for this pin
    Uint32 GPIO245:1;                         // 21 Configuration lock commit bit for this pin
    Uint32 GPIO246:1;                         // 22 Configuration lock commit bit for this pin
    Uint32 GPIO247:1;                         // 23 Configuration lock commit bit for this pin
    Uint32 rsvd1:1;                           // 24 Reserved
    Uint32 rsvd2:1;                           // 25 Reserved
    Uint32 rsvd3:1;                           // 26 Reserved
    Uint32 rsvd4:1;                           // 27 Reserved
    Uint32 rsvd5:1;                           // 28 Reserved
    Uint32 rsvd6:1;                           // 29 Reserved
    Uint32 rsvd7:1;                           // 30 Reserved
    Uint32 rsvd8:1;                           // 31 Reserved
};

union GPHCR_REG {
    Uint32  all;
    struct  GPHCR_BITS  bit;
};

struct GPHDR1_BITS {                          // bits description
    Uint32 GPIO224:2;                         // 1:0 Control the actuation capability of this pin
    Uint32 GPIO225:2;                         // 3:2 Control the actuation capability of this pin
    Uint32 GPIO226:2;                         // 5:4 Control the actuation capability of this pin
    Uint32 GPIO227:2;                         // 7:6 Control the actuation capability of this pin
    Uint32 GPIO228:2;                         // 9:8 Control the actuation capability of this pin
    Uint32 GPIO229:2;                         // 11:10 Control the actuation capability of this pin
    Uint32 GPIO230:2;                         // 13:12 Control the actuation capability of this pin
    Uint32 GPIO231:2;                         // 15:14 Control the actuation capability of this pin
    Uint32 GPIO232:2;                         // 17:16 Control the actuation capability of this pin
    Uint32 GPIO233:2;                         // 19:18 Control the actuation capability of this pin
    Uint32 GPIO234:2;                         // 21:20 Control the actuation capability of this pin
    Uint32 GPIO235:2;                         // 23:22 Control the actuation capability of this pin
    Uint32 GPIO236:2;                         // 25:24 Control the actuation capability of this pin
    Uint32 GPIO237:2;                         // 27:26 Control the actuation capability of this pin
    Uint32 GPIO238:2;                         // 29:28 Control the actuation capability of this pin
    Uint32 GPIO239:2;                         // 31:30 Control the actuation capability of this pin
};

union GPHDR1_REG {
    Uint32  all;
    struct  GPHDR1_BITS  bit;
};

struct GPHDR2_BITS {                          // bits description
    Uint32 GPIO240:2;                         // 1:0 Control the actuation capability of this pin
    Uint32 GPIO241:2;                         // 3:2 Control the actuation capability of this pin
    Uint32 GPIO242:2;                         // 5:4 Control the actuation capability of this pin
    Uint32 GPIO243:2;                         // 7:6 Control the actuation capability of this pin
    Uint32 GPIO244:2;                         // 9:8 Control the actuation capability of this pin
    Uint32 GPIO245:2;                         // 11:10 Control the actuation capability of this pin
    Uint32 GPIO246:2;                         // 13:12 Control the actuation capability of this pin
    Uint32 GPIO247:2;                         // 15:14 Control the actuation capability of this pin
    Uint32 rsvd1:2;                           // 17:16 Reserved
    Uint32 rsvd2:2;                           // 19:18 Reserved
    Uint32 rsvd3:2;                           // 21:20 Reserved
    Uint32 rsvd4:2;                           // 23:22 Reserved
    Uint32 rsvd5:2;                           // 25:24 Reserved
    Uint32 rsvd6:2;                           // 27:26 Reserved
    Uint32 rsvd7:2;                           // 29:28 Reserved
    Uint32 rsvd8:2;                           // 31:30 Reserved
};

union GPHDR2_REG {
    Uint32  all;
    struct  GPHDR2_BITS  bit;
};

struct  GPIO_CTRL_REGS {
    union   GPACTRL_REG                      GPACTRL;                     // 0x0 GPIO A Qualification Sampling Period (GPIO0 to GPIO31)
    union   GPAQSEL1_REG                     GPAQSEL1;                    // 0x4 GPIO A Qualification Type (GPIO0 to GPIO15)
    union   GPAQSEL2_REG                     GPAQSEL2;                    // 0x8 GPIO A Qualification Type (GPIO16 to GPIO31)
    union   GPAMUX1_REG                      GPAMUX1;                     // 0xc GPIO A Peripheral Mux (GPIO0 to GPIO15)
    union   GPAMUX2_REG                      GPAMUX2;                     // 0x10 GPIO A Peripheral Mux (GPIO16 to GPIO31)
    union   GPADIR_REG                       GPADIR;                      // 0x14 GPIO A Direction (GPIO0 to GPIO31)
    union   GPAPUD_REG                       GPAPUD;                      // 0x18 GPIO A Pull-Up Disable (GPIO0 to GPIO31)
    Uint32                                   rsvd1;                       // 0x1c Reserved
    union   GPAINV_REG                       GPAINV;                      // 0x20 GPIO A Input Inversion (GPIO0 to GPIO31)
    union   GPAODR_REG                       GPAODR;                      // 0x24 GPIO A Open Drain Output Mode (GPIO0 to GPIO31)
    union   GPAAMSEL_REG                     GPAAMSEL;                    // 0x28 GPIO A Analog Mode Select (GPIO0 to GPIO31)
    Uint32                                   rsvd2[5];                    // 0x2c Reserved
    union   GPAGMUX1_REG                     GPAGMUX1;                    // 0x40 GPIO A Peripheral Group Mux (GPIO0 to GPIO15)
    union   GPAGMUX2_REG                     GPAGMUX2;                    // 0x44 GPIO A Peripheral Group Mux (GPIO16 to GPIO31)
    Uint32                                   rsvd3[2];                    // 0x48 Reserved
    union   GPACSEL1_REG                     GPACSEL1;                    // 0x50 GPIO A Master Core Select (GPIO0 to GPIO7)
    union   GPACSEL2_REG                     GPACSEL2;                    // 0x54 GPIO A Master Core Select (GPIO8 to GPIO15)
    union   GPACSEL3_REG                     GPACSEL3;                    // 0x58 GPIO A Master Core Select (GPIO16 to GPIO23)
    union   GPACSEL4_REG                     GPACSEL4;                    // 0x5c GPIO A Master Core Select (GPIO24 to GPIO31)
    Uint32                                   rsvd4[6];                    // 0x60 Reserved
    union   GPALOCK_REG                      GPALOCK;                     // 0x78 GPIO A Lock Register (GPIO0 to GPIO31)
    union   GPACR_REG                        GPACR;                       // 0x7c GPIO A Lock Commit Register (GPIO0 to GPIO31)
    union   GPBCTRL_REG                      GPBCTRL;                     // 0x80 GPIO B Qualification Sampling Period (GPIO32 to GPIO63)
    union   GPBQSEL1_REG                     GPBQSEL1;                    // 0x84 GPIO B Qualification Type (GPIO32 to GPIO47)
    union   GPBQSEL2_REG                     GPBQSEL2;                    // 0x88 GPIO B Qualification Type (GPIO48 to GPIO63)
    union   GPBMUX1_REG                      GPBMUX1;                     // 0x8c GPIO B Peripheral Mux (GPIO32 to GPIO47)
    union   GPBMUX2_REG                      GPBMUX2;                     // 0x90 GPIO B Peripheral Mux (GPIO48 to GPIO63)
    union   GPBDIR_REG                       GPBDIR;                      // 0x94 GPIO B Direction (GPIO32 to GPIO63)
    union   GPBPUD_REG                       GPBPUD;                      // 0x98 GPIO B Pull-Up Disable (GPIO32 to GPIO63)
    Uint32                                   rsvd5;                       // 0x9c Reserved
    union   GPBINV_REG                       GPBINV;                      // 0xa0 GPIO B Input Inversion (GPIO32 to GPIO63)
    union   GPBODR_REG                       GPBODR;                      // 0xa4 GPIO B Open Drain Output Mode (GPIO32 to GPIO63)
    Uint32                                   rsvd6[6];                    // 0xa8 Reserved
    union   GPBGMUX1_REG                     GPBGMUX1;                    // 0xc0 GPIO B Peripheral Group Mux (GPIO32 to GPIO47)
    union   GPBGMUX2_REG                     GPBGMUX2;                    // 0xc4 GPIO B Peripheral Group Mux (GPIO48 to GPIO63)
    Uint32                                   rsvd7[2];                    // 0xc8 Reserved
    union   GPBCSEL1_REG                     GPBCSEL1;                    // 0xd0 GPIO B Master Core Select (GPIO32 to GPIO39)
    union   GPBCSEL2_REG                     GPBCSEL2;                    // 0xd4 GPIO B Master Core Select (GPIO40 to GPIO47)
    union   GPBCSEL3_REG                     GPBCSEL3;                    // 0xd8 GPIO B Master Core Select (GPIO48 to GPIO55)
    union   GPBCSEL4_REG                     GPBCSEL4;                    // 0xdc GPIO B Master Core Select (GPIO56 to GPIO63)
    Uint32                                   rsvd8[6];                    // 0xe0 Reserved
    union   GPBLOCK_REG                      GPBLOCK;                     // 0xf8 GPIO B Lock Register (GPIO32 to GPIO63)
    union   GPBCR_REG                        GPBCR;                       // 0xfc GPIO B Lock Commit Register (GPIO32 to GPIO63)
    union   GPADR1_REG                       GPADR1;                      // 0x100 GPIO A Driving strength Register (GPIO0 to 15)
    union   GPADR2_REG                       GPADR2;                      // 0x104 GPIO A Driving strength Register (GPIO16 to 31)
    union   GPBDR1_REG                       GPBDR1;                      // 0x108 GPIO B Driving strength Register (GPIO32 to 47) 
    union   GPBDR2_REG                       GPBDR2;                      // 0x10c GPIO B Driving strength Register (GPIO48 to 63) 
    union   GPCDR1_REG                       GPCDR1;                      // 0x110 GPIO C Driving strength Register
    union   GPCDR2_REG                       GPCDR2;                      // 0x114 GPIO C Driving strength Register
    Uint32                                   rsvd9[10];                   // 0x118 Reserved
    union   GPCCTRL_REG                      GPCCTRL;                     // 0x140 GPIO C Qualification Sampling Period (GPIO64 to GPIO95)
    union   GPCQSEL1_REG                     GPCQSEL1;                    // 0x144 GPIO C Qualification Type (GPIO64 to GPIO79)
    union   GPCQSEL2_REG                     GPCQSEL2;                    // 0x148 GPIO C Qualification Type (GPIO80 to GPIO95)
    Uint32                                   rsvd10[2];                   // 0x14c Reserved
    union   GPCDIR_REG                       GPCDIR;                      // 0x154 GPIO C Peripheral Mux (GPIO64 to GPIO95)
    union   GPCPUD_REG                       GPCPUD;                      // 0x158 GPIO C Pull-Up Disable (GPIO64 to GPIO95)
    Uint32                                   rsvd11;                      // 0x15c Reserved
    union   GPCINV_REG                       GPCINV;                      // 0x160 GPIO C Input Inversion (GPIO32 to GPIO63)
    union   GPCODR_REG                       GPCODR;                      // 0x164 GPIO C Open Drain Output Mode (GPIO64 to GPIO95)
    Uint32                                   rsvd12[10];                  // 0x168 Reserved
    union   GPCCSEL1_REG                     GPCCSEL1;                    // 0x190 GPIO C Master Core Select (GPIO64 to GPIO71)
    union   GPCCSEL2_REG                     GPCCSEL2;                    // 0x194 GPIO C Master Core Select (GPIO72 to GPIO79)
    union   GPCCSEL3_REG                     GPCCSEL3;                    // 0x198 GPIO C Master Core Select (GPIO80 to GPIO87)
    union   GPCCSEL4_REG                     GPCCSEL4;                    // 0x19c GPIO C Master Core Select (GPIO88 to GPIO95)
    Uint32                                   rsvd13[6];                   // 0x1a0 Reserved
    union   GPCLOCK_REG                      GPCLOCK;                     // 0x1b8 GPIO C Lock Register (GPIO64 to GPIO95)
    union   GPCCR_REG                        GPCCR;                       // 0x1bc GPIO C Lock Commit Register (GPIO64 to GPIO95)
    Uint32                                   rsvd14[112];                 // 0x1c0 Reserved
    union   GPHCTRL_REG                      GPHCTRL;                     // 0x380 GPIO H Qualification Sampling Period (GPIO224 to GPIO255)
    union   GPHQSEL1_REG                     GPHQSEL1;                    // 0x384 GPIO H Qualification Type (GPIO224 to GPIO239)
    union   GPHQSEL2_REG                     GPHQSEL2;                    // 0x388 GPIO H Qualification Type (GPIO240 to GPIO255)
    Uint32                                   rsvd15[3];                   // 0x38c Reserved
    union   GPHPUD_REG                       GPHPUD;                      // 0x398 GPIO H Pull-Up Disable (GPIO224 to GPIO255)
    Uint32                                   rsvd16;                      // 0x39c Reserved
    union   GPHINV_REG                       GPHINV;                      // 0x3a0 GPIO H Input Inversion (GPIO224 to GPIO255)
    Uint32                                   rsvd17;                      // 0x3a4 Reserved
    union   GPHAMSEL_REG                     GPHAMSEL;                    // 0x3a8 GPIO H Analog Mode Select (GPIO224 to GPIO255)
    Uint32                                   rsvd18[19];                  // 0x3ac Reserved
    union   GPHLOCK_REG                      GPHLOCK;                     // 0x3f8 GPIO H Lock Register (GPIO224 to GPIO255)
    union   GPHCR_REG                        GPHCR;                       // 0x3fc GPIO H Lock Commit Register (GPIO224 to GPIO255)
    union   GPHDR1_REG                       GPHDR1;                      // 0x400 GPIO H Driving strength Register (GPIO224 to 239) 
    union   GPHDR2_REG                       GPHDR2;                      // 0x404 GPIO H Driving strength Register (GPIO240 to 255) 
};

struct GPADAT_BITS {                          // bits description
    Uint32 GPIO0:1;                           // 0 Data Register for this pin
    Uint32 GPIO1:1;                           // 1 Data Register for this pin
    Uint32 GPIO2:1;                           // 2 Data Register for this pin
    Uint32 GPIO3:1;                           // 3 Data Register for this pin
    Uint32 GPIO4:1;                           // 4 Data Register for this pin
    Uint32 GPIO5:1;                           // 5 Data Register for this pin
    Uint32 GPIO6:1;                           // 6 Data Register for this pin
    Uint32 GPIO7:1;                           // 7 Data Register for this pin
    Uint32 GPIO8:1;                           // 8 Data Register for this pin
    Uint32 GPIO9:1;                           // 9 Data Register for this pin
    Uint32 GPIO10:1;                          // 10 Data Register for this pin
    Uint32 GPIO11:1;                          // 11 Data Register for this pin
    Uint32 GPIO12:1;                          // 12 Data Register for this pin
    Uint32 GPIO13:1;                          // 13 Data Register for this pin
    Uint32 GPIO14:1;                          // 14 Data Register for this pin
    Uint32 GPIO15:1;                          // 15 Data Register for this pin
    Uint32 GPIO16:1;                          // 16 Data Register for this pin
    Uint32 GPIO17:1;                          // 17 Data Register for this pin
    Uint32 GPIO18:1;                          // 18 Data Register for this pin
    Uint32 GPIO19:1;                          // 19 Data Register for this pin
    Uint32 GPIO20:1;                          // 20 Data Register for this pin
    Uint32 GPIO21:1;                          // 21 Data Register for this pin
    Uint32 GPIO22:1;                          // 22 Data Register for this pin
    Uint32 GPIO23:1;                          // 23 Data Register for this pin
    Uint32 GPIO24:1;                          // 24 Data Register for this pin
    Uint32 GPIO25:1;                          // 25 Data Register for this pin
    Uint32 GPIO26:1;                          // 26 Data Register for this pin
    Uint32 GPIO27:1;                          // 27 Data Register for this pin
    Uint32 GPIO28:1;                          // 28 Data Register for this pin
    Uint32 GPIO29:1;                          // 29 Data Register for this pin
    Uint32 GPIO30:1;                          // 30 Data Register for this pin
    Uint32 GPIO31:1;                          // 31 Data Register for this pin
};

union GPADAT_REG {
    Uint32  all;
    struct  GPADAT_BITS  bit;
};

struct GPASET_BITS {                          // bits description
    Uint32 GPIO0:1;                           // 0 Output Set bit for this pin
    Uint32 GPIO1:1;                           // 1 Output Set bit for this pin
    Uint32 GPIO2:1;                           // 2 Output Set bit for this pin
    Uint32 GPIO3:1;                           // 3 Output Set bit for this pin
    Uint32 GPIO4:1;                           // 4 Output Set bit for this pin
    Uint32 GPIO5:1;                           // 5 Output Set bit for this pin
    Uint32 GPIO6:1;                           // 6 Output Set bit for this pin
    Uint32 GPIO7:1;                           // 7 Output Set bit for this pin
    Uint32 GPIO8:1;                           // 8 Output Set bit for this pin
    Uint32 GPIO9:1;                           // 9 Output Set bit for this pin
    Uint32 GPIO10:1;                          // 10 Output Set bit for this pin
    Uint32 GPIO11:1;                          // 11 Output Set bit for this pin
    Uint32 GPIO12:1;                          // 12 Output Set bit for this pin
    Uint32 GPIO13:1;                          // 13 Output Set bit for this pin
    Uint32 GPIO14:1;                          // 14 Output Set bit for this pin
    Uint32 GPIO15:1;                          // 15 Output Set bit for this pin
    Uint32 GPIO16:1;                          // 16 Output Set bit for this pin
    Uint32 GPIO17:1;                          // 17 Output Set bit for this pin
    Uint32 GPIO18:1;                          // 18 Output Set bit for this pin
    Uint32 GPIO19:1;                          // 19 Output Set bit for this pin
    Uint32 GPIO20:1;                          // 20 Output Set bit for this pin
    Uint32 GPIO21:1;                          // 21 Output Set bit for this pin
    Uint32 GPIO22:1;                          // 22 Output Set bit for this pin
    Uint32 GPIO23:1;                          // 23 Output Set bit for this pin
    Uint32 GPIO24:1;                          // 24 Output Set bit for this pin
    Uint32 GPIO25:1;                          // 25 Output Set bit for this pin
    Uint32 GPIO26:1;                          // 26 Output Set bit for this pin
    Uint32 GPIO27:1;                          // 27 Output Set bit for this pin
    Uint32 GPIO28:1;                          // 28 Output Set bit for this pin
    Uint32 GPIO29:1;                          // 29 Output Set bit for this pin
    Uint32 GPIO30:1;                          // 30 Output Set bit for this pin
    Uint32 GPIO31:1;                          // 31 Output Set bit for this pin
};

union GPASET_REG {
    Uint32  all;
    struct  GPASET_BITS  bit;
};

struct GPACLEAR_BITS {                        // bits description
    Uint32 GPIO0:1;                           // 0 Output Clear bit for this pin
    Uint32 GPIO1:1;                           // 1 Output Clear bit for this pin
    Uint32 GPIO2:1;                           // 2 Output Clear bit for this pin
    Uint32 GPIO3:1;                           // 3 Output Clear bit for this pin
    Uint32 GPIO4:1;                           // 4 Output Clear bit for this pin
    Uint32 GPIO5:1;                           // 5 Output Clear bit for this pin
    Uint32 GPIO6:1;                           // 6 Output Clear bit for this pin
    Uint32 GPIO7:1;                           // 7 Output Clear bit for this pin
    Uint32 GPIO8:1;                           // 8 Output Clear bit for this pin
    Uint32 GPIO9:1;                           // 9 Output Clear bit for this pin
    Uint32 GPIO10:1;                          // 10 Output Clear bit for this pin
    Uint32 GPIO11:1;                          // 11 Output Clear bit for this pin
    Uint32 GPIO12:1;                          // 12 Output Clear bit for this pin
    Uint32 GPIO13:1;                          // 13 Output Clear bit for this pin
    Uint32 GPIO14:1;                          // 14 Output Clear bit for this pin
    Uint32 GPIO15:1;                          // 15 Output Clear bit for this pin
    Uint32 GPIO16:1;                          // 16 Output Clear bit for this pin
    Uint32 GPIO17:1;                          // 17 Output Clear bit for this pin
    Uint32 GPIO18:1;                          // 18 Output Clear bit for this pin
    Uint32 GPIO19:1;                          // 19 Output Clear bit for this pin
    Uint32 GPIO20:1;                          // 20 Output Clear bit for this pin
    Uint32 GPIO21:1;                          // 21 Output Clear bit for this pin
    Uint32 GPIO22:1;                          // 22 Output Clear bit for this pin
    Uint32 GPIO23:1;                          // 23 Output Clear bit for this pin
    Uint32 GPIO24:1;                          // 24 Output Clear bit for this pin
    Uint32 GPIO25:1;                          // 25 Output Clear bit for this pin
    Uint32 GPIO26:1;                          // 26 Output Clear bit for this pin
    Uint32 GPIO27:1;                          // 27 Output Clear bit for this pin
    Uint32 GPIO28:1;                          // 28 Output Clear bit for this pin
    Uint32 GPIO29:1;                          // 29 Output Clear bit for this pin
    Uint32 GPIO30:1;                          // 30 Output Clear bit for this pin
    Uint32 GPIO31:1;                          // 31 Output Clear bit for this pin
};

union GPACLEAR_REG {
    Uint32  all;
    struct  GPACLEAR_BITS  bit;
};

struct GPATOGGLE_BITS {                       // bits description
    Uint32 GPIO0:1;                           // 0 Output Toggle bit for this pin
    Uint32 GPIO1:1;                           // 1 Output Toggle bit for this pin
    Uint32 GPIO2:1;                           // 2 Output Toggle bit for this pin
    Uint32 GPIO3:1;                           // 3 Output Toggle bit for this pin
    Uint32 GPIO4:1;                           // 4 Output Toggle bit for this pin
    Uint32 GPIO5:1;                           // 5 Output Toggle bit for this pin
    Uint32 GPIO6:1;                           // 6 Output Toggle bit for this pin
    Uint32 GPIO7:1;                           // 7 Output Toggle bit for this pin
    Uint32 GPIO8:1;                           // 8 Output Toggle bit for this pin
    Uint32 GPIO9:1;                           // 9 Output Toggle bit for this pin
    Uint32 GPIO10:1;                          // 10 Output Toggle bit for this pin
    Uint32 GPIO11:1;                          // 11 Output Toggle bit for this pin
    Uint32 GPIO12:1;                          // 12 Output Toggle bit for this pin
    Uint32 GPIO13:1;                          // 13 Output Toggle bit for this pin
    Uint32 GPIO14:1;                          // 14 Output Toggle bit for this pin
    Uint32 GPIO15:1;                          // 15 Output Toggle bit for this pin
    Uint32 GPIO16:1;                          // 16 Output Toggle bit for this pin
    Uint32 GPIO17:1;                          // 17 Output Toggle bit for this pin
    Uint32 GPIO18:1;                          // 18 Output Toggle bit for this pin
    Uint32 GPIO19:1;                          // 19 Output Toggle bit for this pin
    Uint32 GPIO20:1;                          // 20 Output Toggle bit for this pin
    Uint32 GPIO21:1;                          // 21 Output Toggle bit for this pin
    Uint32 GPIO22:1;                          // 22 Output Toggle bit for this pin
    Uint32 GPIO23:1;                          // 23 Output Toggle bit for this pin
    Uint32 GPIO24:1;                          // 24 Output Toggle bit for this pin
    Uint32 GPIO25:1;                          // 25 Output Toggle bit for this pin
    Uint32 GPIO26:1;                          // 26 Output Toggle bit for this pin
    Uint32 GPIO27:1;                          // 27 Output Toggle bit for this pin
    Uint32 GPIO28:1;                          // 28 Output Toggle bit for this pin
    Uint32 GPIO29:1;                          // 29 Output Toggle bit for this pin
    Uint32 GPIO30:1;                          // 30 Output Toggle bit for this pin
    Uint32 GPIO31:1;                          // 31 Output Toggle bit for this pin
};

union GPATOGGLE_REG {
    Uint32  all;
    struct  GPATOGGLE_BITS  bit;
};

struct GPBDAT_BITS {                          // bits description
    Uint32 GPIO32:1;                          // 0 Data Register for this pin
    Uint32 GPIO33:1;                          // 1 Data Register for this pin
    Uint32 GPIO34:1;                          // 2 Data Register for this pin
    Uint32 GPIO35:1;                          // 3 Data Register for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Data Register for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Data Register for this pin
    Uint32 GPIO40:1;                          // 8 Data Register for this pin
    Uint32 GPIO41:1;                          // 9 Data Register for this pin
    Uint32 GPIO42:1;                          // 10 Data Register for this pin
    Uint32 GPIO43:1;                          // 11 Data Register for this pin
    Uint32 GPIO44:1;                          // 12 Data Register for this pin
    Uint32 GPIO45:1;                          // 13 Data Register for this pin
    Uint32 GPIO46:1;                          // 14 Data Register for this pin
    Uint32 GPIO47:1;                          // 15 Data Register for this pin
    Uint32 GPIO48:1;                          // 16 Data Register for this pin
    Uint32 GPIO49:1;                          // 17 Data Register for this pin
    Uint32 GPIO50:1;                          // 18 Data Register for this pin
    Uint32 GPIO51:1;                          // 19 Data Register for this pin
    Uint32 GPIO52:1;                          // 20 Data Register for this pin
    Uint32 GPIO53:1;                          // 21 Data Register for this pin
    Uint32 GPIO54:1;                          // 22 Data Register for this pin
    Uint32 GPIO55:1;                          // 23 Data Register for this pin
    Uint32 GPIO56:1;                          // 24 Data Register for this pin
    Uint32 GPIO57:1;                          // 25 Data Register for this pin
    Uint32 GPIO58:1;                          // 26 Data Register for this pin
    Uint32 GPIO59:1;                          // 27 Data Register for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBDAT_REG {
    Uint32  all;
    struct  GPBDAT_BITS  bit;
};

struct GPBSET_BITS {                          // bits description
    Uint32 GPIO32:1;                          // 0 Output Set bit for this pin
    Uint32 GPIO33:1;                          // 1 Output Set bit for this pin
    Uint32 GPIO34:1;                          // 2 Output Set bit for this pin
    Uint32 GPIO35:1;                          // 3 Output Set bit for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Output Set bit for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Output Set bit for this pin
    Uint32 GPIO40:1;                          // 8 Output Set bit for this pin
    Uint32 GPIO41:1;                          // 9 Output Set bit for this pin
    Uint32 GPIO42:1;                          // 10 Output Set bit for this pin
    Uint32 GPIO43:1;                          // 11 Output Set bit for this pin
    Uint32 GPIO44:1;                          // 12 Output Set bit for this pin
    Uint32 GPIO45:1;                          // 13 Output Set bit for this pin
    Uint32 GPIO46:1;                          // 14 Output Set bit for this pin
    Uint32 GPIO47:1;                          // 15 Output Set bit for this pin
    Uint32 GPIO48:1;                          // 16 Output Set bit for this pin
    Uint32 GPIO49:1;                          // 17 Output Set bit for this pin
    Uint32 GPIO50:1;                          // 18 Output Set bit for this pin
    Uint32 GPIO51:1;                          // 19 Output Set bit for this pin
    Uint32 GPIO52:1;                          // 20 Output Set bit for this pin
    Uint32 GPIO53:1;                          // 21 Output Set bit for this pin
    Uint32 GPIO54:1;                          // 22 Output Set bit for this pin
    Uint32 GPIO55:1;                          // 23 Output Set bit for this pin
    Uint32 GPIO56:1;                          // 24 Output Set bit for this pin
    Uint32 GPIO57:1;                          // 25 Output Set bit for this pin
    Uint32 GPIO58:1;                          // 26 Output Set bit for this pin
    Uint32 GPIO59:1;                          // 27 Output Set bit for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBSET_REG {
    Uint32  all;
    struct  GPBSET_BITS  bit;
};

struct GPBCLEAR_BITS {                        // bits description
    Uint32 GPIO32:1;                          // 0 Output Clear bit for this pin
    Uint32 GPIO33:1;                          // 1 Output Clear bit for this pin
    Uint32 GPIO34:1;                          // 2 Output Clear bit for this pin
    Uint32 GPIO35:1;                          // 3 Output Clear bit for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Output Clear bit for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Output Clear bit for this pin
    Uint32 GPIO40:1;                          // 8 Output Clear bit for this pin
    Uint32 GPIO41:1;                          // 9 Output Clear bit for this pin
    Uint32 GPIO42:1;                          // 10 Output Clear bit for this pin
    Uint32 GPIO43:1;                          // 11 Output Clear bit for this pin
    Uint32 GPIO44:1;                          // 12 Output Clear bit for this pin
    Uint32 GPIO45:1;                          // 13 Output Clear bit for this pin
    Uint32 GPIO46:1;                          // 14 Output Clear bit for this pin
    Uint32 GPIO47:1;                          // 15 Output Clear bit for this pin
    Uint32 GPIO48:1;                          // 16 Output Clear bit for this pin
    Uint32 GPIO49:1;                          // 17 Output Clear bit for this pin
    Uint32 GPIO50:1;                          // 18 Output Clear bit for this pin
    Uint32 GPIO51:1;                          // 19 Output Clear bit for this pin
    Uint32 GPIO52:1;                          // 20 Output Clear bit for this pin
    Uint32 GPIO53:1;                          // 21 Output Clear bit for this pin
    Uint32 GPIO54:1;                          // 22 Output Clear bit for this pin
    Uint32 GPIO55:1;                          // 23 Output Clear bit for this pin
    Uint32 GPIO56:1;                          // 24 Output Clear bit for this pin
    Uint32 GPIO57:1;                          // 25 Output Clear bit for this pin
    Uint32 GPIO58:1;                          // 26 Output Clear bit for this pin
    Uint32 GPIO59:1;                          // 27 Output Clear bit for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBCLEAR_REG {
    Uint32  all;
    struct  GPBCLEAR_BITS  bit;
};

struct GPBTOGGLE_BITS {                       // bits description
    Uint32 GPIO32:1;                          // 0 Output Toggle bit for this pin
    Uint32 GPIO33:1;                          // 1 Output Toggle bit for this pin
    Uint32 GPIO34:1;                          // 2 Output Toggle bit for this pin
    Uint32 GPIO35:1;                          // 3 Output Toggle bit for this pin
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 GPIO37:1;                          // 5 Output Toggle bit for this pin
    Uint32 rsvd2:1;                           // 6 Reserved
    Uint32 GPIO39:1;                          // 7 Output Toggle bit for this pin
    Uint32 GPIO40:1;                          // 8 Output Toggle bit for this pin
    Uint32 GPIO41:1;                          // 9 Output Toggle bit for this pin
    Uint32 GPIO42:1;                          // 10 Output Toggle bit for this pin
    Uint32 GPIO43:1;                          // 11 Output Toggle bit for this pin
    Uint32 GPIO44:1;                          // 12 Output Toggle bit for this pin
    Uint32 GPIO45:1;                          // 13 Output Toggle bit for this pin
    Uint32 GPIO46:1;                          // 14 Output Toggle bit for this pin
    Uint32 GPIO47:1;                          // 15 Output Toggle bit for this pin
    Uint32 GPIO48:1;                          // 16 Output Toggle bit for this pin
    Uint32 GPIO49:1;                          // 17 Output Toggle bit for this pin
    Uint32 GPIO50:1;                          // 18 Output Toggle bit for this pin
    Uint32 GPIO51:1;                          // 19 Output Toggle bit for this pin
    Uint32 GPIO52:1;                          // 20 Output Toggle bit for this pin
    Uint32 GPIO53:1;                          // 21 Output Toggle bit for this pin
    Uint32 GPIO54:1;                          // 22 Output Toggle bit for this pin
    Uint32 GPIO55:1;                          // 23 Output Toggle bit for this pin
    Uint32 GPIO56:1;                          // 24 Output Toggle bit for this pin
    Uint32 GPIO57:1;                          // 25 Output Toggle bit for this pin
    Uint32 GPIO58:1;                          // 26 Output Toggle bit for this pin
    Uint32 GPIO59:1;                          // 27 Output Toggle bit for this pin
    Uint32 rsvd3:1;                           // 28 Reserved
    Uint32 rsvd4:1;                           // 29 Reserved
    Uint32 rsvd5:1;                           // 30 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union GPBTOGGLE_REG {
    Uint32  all;
    struct  GPBTOGGLE_BITS  bit;
};

struct GPCDAT_BITS {                          // bits description
    Uint32 GPIO64:1;                          // 0 Data Register for this pin
    Uint32 GPIO65:1;                          // 1 Data Register for this pin
    Uint32 GPIO66:1;                          // 2 Data Register for this pin
    Uint32 GPIO67:1;                          // 3 Data Register for this pin
    Uint32 GPIO68:1;                          // 4 Data Register for this pin
    Uint32 GPIO69:1;                          // 5 Data Register for this pin
    Uint32 GPIO70:1;                          // 6 Data Register for this pin
    Uint32 GPIO71:1;                          // 7 Data Register for this pin
    Uint32 GPIO72:1;                          // 8 Data Register for this pin
    Uint32 GPIO73:1;                          // 9 Data Register for this pin
    Uint32 GPIO74:1;                          // 10 Data Register for this pin
    Uint32 GPIO75:1;                          // 11 Data Register for this pin
    Uint32 GPIO76:1;                          // 12 Data Register for this pin
    Uint32 GPIO77:1;                          // 13 Data Register for this pin
    Uint32 GPIO78:1;                          // 14 Data Register for this pin
    Uint32 GPIO79:1;                          // 15 Data Register for this pin
    Uint32 GPIO80:1;                          // 16 Data Register for this pin
    Uint32 GPIO81:1;                          // 17 Data Register for this pin
    Uint32 GPIO82:1;                          // 18 Data Register for this pin
    Uint32 GPIO83:1;                          // 19 Data Register for this pin
    Uint32 GPIO84:1;                          // 20 Data Register for this pin
    Uint32 GPIO85:1;                          // 21 Data Register for this pin
    Uint32 GPIO86:1;                          // 22 Data Register for this pin
    Uint32 GPIO87:1;                          // 23 Data Register for this pin
    Uint32 GPIO88:1;                          // 24 Data Register for this pin
    Uint32 GPIO89:1;                          // 25 Data Register for this pin
    Uint32 GPIO90:1;                          // 26 Data Register for this pin
    Uint32 GPIO91:1;                          // 27 Data Register for this pin
    Uint32 GPIO92:1;                          // 28 Data Register for this pin
    Uint32 GPIO93:1;                          // 29 Data Register for this pin
    Uint32 GPIO94:1;                          // 30 Data Register for this pin
    Uint32 GPIO95:1;                          // 31 Data Register for this pin
};

union GPCDAT_REG {
    Uint32  all;
    struct  GPCDAT_BITS  bit;
};

struct GPCSET_BITS {                          // bits description
    Uint32 GPIO64:1;                          // 0 Output Set bit for this pin
    Uint32 GPIO65:1;                          // 1 Output Set bit for this pin
    Uint32 GPIO66:1;                          // 2 Output Set bit for this pin
    Uint32 GPIO67:1;                          // 3 Output Set bit for this pin
    Uint32 GPIO68:1;                          // 4 Output Set bit for this pin
    Uint32 GPIO69:1;                          // 5 Output Set bit for this pin
    Uint32 GPIO70:1;                          // 6 Output Set bit for this pin
    Uint32 GPIO71:1;                          // 7 Output Set bit for this pin
    Uint32 GPIO72:1;                          // 8 Output Set bit for this pin
    Uint32 GPIO73:1;                          // 9 Output Set bit for this pin
    Uint32 GPIO74:1;                          // 10 Output Set bit for this pin
    Uint32 GPIO75:1;                          // 11 Output Set bit for this pin
    Uint32 GPIO76:1;                          // 12 Output Set bit for this pin
    Uint32 GPIO77:1;                          // 13 Output Set bit for this pin
    Uint32 GPIO78:1;                          // 14 Output Set bit for this pin
    Uint32 GPIO79:1;                          // 15 Output Set bit for this pin
    Uint32 GPIO80:1;                          // 16 Output Set bit for this pin
    Uint32 GPIO81:1;                          // 17 Output Set bit for this pin
    Uint32 GPIO82:1;                          // 18 Output Set bit for this pin
    Uint32 GPIO83:1;                          // 19 Output Set bit for this pin
    Uint32 GPIO84:1;                          // 20 Output Set bit for this pin
    Uint32 GPIO85:1;                          // 21 Output Set bit for this pin
    Uint32 GPIO86:1;                          // 22 Output Set bit for this pin
    Uint32 GPIO87:1;                          // 23 Output Set bit for this pin
    Uint32 GPIO88:1;                          // 24 Output Set bit for this pin
    Uint32 GPIO89:1;                          // 25 Output Set bit for this pin
    Uint32 GPIO90:1;                          // 26 Output Set bit for this pin
    Uint32 GPIO91:1;                          // 27 Output Set bit for this pin
    Uint32 GPIO92:1;                          // 28 Output Set bit for this pin
    Uint32 GPIO93:1;                          // 29 Output Set bit for this pin
    Uint32 GPIO94:1;                          // 30 Output Set bit for this pin
    Uint32 GPIO95:1;                          // 31 Output Set bit for this pin
};

union GPCSET_REG {
    Uint32  all;
    struct  GPCSET_BITS  bit;
};

struct GPCCLEAR_BITS {                        // bits description
    Uint32 GPIO64:1;                          // 0 Output Clear bit for this pin
    Uint32 GPIO65:1;                          // 1 Output Clear bit for this pin
    Uint32 GPIO66:1;                          // 2 Output Clear bit for this pin
    Uint32 GPIO67:1;                          // 3 Output Clear bit for this pin
    Uint32 GPIO68:1;                          // 4 Output Clear bit for this pin
    Uint32 GPIO69:1;                          // 5 Output Clear bit for this pin
    Uint32 GPIO70:1;                          // 6 Output Clear bit for this pin
    Uint32 GPIO71:1;                          // 7 Output Clear bit for this pin
    Uint32 GPIO72:1;                          // 8 Output Clear bit for this pin
    Uint32 GPIO73:1;                          // 9 Output Clear bit for this pin
    Uint32 GPIO74:1;                          // 10 Output Clear bit for this pin
    Uint32 GPIO75:1;                          // 11 Output Clear bit for this pin
    Uint32 GPIO76:1;                          // 12 Output Clear bit for this pin
    Uint32 GPIO77:1;                          // 13 Output Clear bit for this pin
    Uint32 GPIO78:1;                          // 14 Output Clear bit for this pin
    Uint32 GPIO79:1;                          // 15 Output Clear bit for this pin
    Uint32 GPIO80:1;                          // 16 Output Clear bit for this pin
    Uint32 GPIO81:1;                          // 17 Output Clear bit for this pin
    Uint32 GPIO82:1;                          // 18 Output Clear bit for this pin
    Uint32 GPIO83:1;                          // 19 Output Clear bit for this pin
    Uint32 GPIO84:1;                          // 20 Output Clear bit for this pin
    Uint32 GPIO85:1;                          // 21 Output Clear bit for this pin
    Uint32 GPIO86:1;                          // 22 Output Clear bit for this pin
    Uint32 GPIO87:1;                          // 23 Output Clear bit for this pin
    Uint32 GPIO88:1;                          // 24 Output Clear bit for this pin
    Uint32 GPIO89:1;                          // 25 Output Clear bit for this pin
    Uint32 GPIO90:1;                          // 26 Output Clear bit for this pin
    Uint32 GPIO91:1;                          // 27 Output Clear bit for this pin
    Uint32 GPIO92:1;                          // 28 Output Clear bit for this pin
    Uint32 GPIO93:1;                          // 29 Output Clear bit for this pin
    Uint32 GPIO94:1;                          // 30 Output Clear bit for this pin
    Uint32 GPIO95:1;                          // 31 Output Clear bit for this pin
};

union GPCCLEAR_REG {
    Uint32  all;
    struct  GPCCLEAR_BITS  bit;
};

struct GPCTOGGLE_BITS {                       // bits description
    Uint32 GPIO64:1;                          // 0 Output Toggle bit for this pin
    Uint32 GPIO65:1;                          // 1 Output Toggle bit for this pin
    Uint32 GPIO66:1;                          // 2 Output Toggle bit for this pin
    Uint32 GPIO67:1;                          // 3 Output Toggle bit for this pin
    Uint32 GPIO68:1;                          // 4 Output Toggle bit for this pin
    Uint32 GPIO69:1;                          // 5 Output Toggle bit for this pin
    Uint32 GPIO70:1;                          // 6 Output Toggle bit for this pin
    Uint32 GPIO71:1;                          // 7 Output Toggle bit for this pin
    Uint32 GPIO72:1;                          // 8 Output Toggle bit for this pin
    Uint32 GPIO73:1;                          // 9 Output Toggle bit for this pin
    Uint32 GPIO74:1;                          // 10 Output Toggle bit for this pin
    Uint32 GPIO75:1;                          // 11 Output Toggle bit for this pin
    Uint32 GPIO76:1;                          // 12 Output Toggle bit for this pin
    Uint32 GPIO77:1;                          // 13 Output Toggle bit for this pin
    Uint32 GPIO78:1;                          // 14 Output Toggle bit for this pin
    Uint32 GPIO79:1;                          // 15 Output Toggle bit for this pin
    Uint32 GPIO80:1;                          // 16 Output Toggle bit for this pin
    Uint32 GPIO81:1;                          // 17 Output Toggle bit for this pin
    Uint32 GPIO82:1;                          // 18 Output Toggle bit for this pin
    Uint32 GPIO83:1;                          // 19 Output Toggle bit for this pin
    Uint32 GPIO84:1;                          // 20 Output Toggle bit for this pin
    Uint32 GPIO85:1;                          // 21 Output Toggle bit for this pin
    Uint32 GPIO86:1;                          // 22 Output Toggle bit for this pin
    Uint32 GPIO87:1;                          // 23 Output Toggle bit for this pin
    Uint32 GPIO88:1;                          // 24 Output Toggle bit for this pin
    Uint32 GPIO89:1;                          // 25 Output Toggle bit for this pin
    Uint32 GPIO90:1;                          // 26 Output Toggle bit for this pin
    Uint32 GPIO91:1;                          // 27 Output Toggle bit for this pin
    Uint32 GPIO92:1;                          // 28 Output Toggle bit for this pin
    Uint32 GPIO93:1;                          // 29 Output Toggle bit for this pin
    Uint32 GPIO94:1;                          // 30 Output Toggle bit for this pin
    Uint32 GPIO95:1;                          // 31 Output Toggle bit for this pin
};

union GPCTOGGLE_REG {
    Uint32  all;
    struct  GPCTOGGLE_BITS  bit;
};

struct GPHDAT_BITS {                          // bits description
    Uint32 GPIO224:1;                         // 0 Data Register for this pin
    Uint32 GPIO225:1;                         // 1 Data Register for this pin
    Uint32 GPIO226:1;                         // 2 Data Register for this pin
    Uint32 GPIO227:1;                         // 3 Data Register for this pin
    Uint32 GPIO228:1;                         // 4 Data Register for this pin
    Uint32 GPIO229:1;                         // 5 Data Register for this pin
    Uint32 GPIO230:1;                         // 6 Data Register for this pin
    Uint32 GPIO231:1;                         // 7 Data Register for this pin
    Uint32 GPIO232:1;                         // 8 Data Register for this pin
    Uint32 GPIO233:1;                         // 9 Data Register for this pin
    Uint32 GPIO234:1;                         // 10 Data Register for this pin
    Uint32 GPIO235:1;                         // 11 Data Register for this pin
    Uint32 GPIO236:1;                         // 12 Data Register for this pin
    Uint32 GPIO237:1;                         // 13 Data Register for this pin
    Uint32 GPIO238:1;                         // 14 Data Register for this pin
    Uint32 GPIO239:1;                         // 15 Data Register for this pin
    Uint32 GPIO240:1;                         // 16 Data Register for this pin
    Uint32 GPIO241:1;                         // 17 Data Register for this pin
    Uint32 GPIO242:1;                         // 18 Data Register for this pin
    Uint32 GPIO243:1;                         // 19 Data Register for this pin
    Uint32 GPIO244:1;                         // 20 Data Register for this pin
    Uint32 GPIO245:1;                         // 21 Data Register for this pin
    Uint32 GPIO246:1;                         // 22 Data Register for this pin
    Uint32 GPIO247:1;                         // 23 Data Register for this pin
    Uint32 rsvd1:1;                           // 24 Reserved
    Uint32 rsvd2:1;                           // 25 Reserved
    Uint32 rsvd3:1;                           // 26 Reserved
    Uint32 rsvd4:1;                           // 27 Reserved
    Uint32 rsvd5:1;                           // 28 Reserved
    Uint32 rsvd6:1;                           // 29 Reserved
    Uint32 rsvd7:1;                           // 30 Reserved
    Uint32 rsvd8:1;                           // 31 Reserved
};

union GPHDAT_REG {
    Uint32  all;
    struct  GPHDAT_BITS  bit;
};

struct  GPIO_DATA_REGS {
    union   GPADAT_REG                       GPADAT;                      // 0x0 GPIO A Data Register (GPIO0 to GPIO31)
    union   GPASET_REG                       GPASET;                      // 0x4 GPIO A Output Set (GPIO0 to GPIO31)
    union   GPACLEAR_REG                     GPACLEAR;                    // 0x8 GPIO A Output Clear (GPIO0 to GPIO31)
    union   GPATOGGLE_REG                    GPATOGGLE;                   // 0xc GPIO A Output Toggle (GPIO0 to GPIO31)
    union   GPBDAT_REG                       GPBDAT;                      // 0x10 GPIO B Data Register (GPIO32 to GPIO64)
    union   GPBSET_REG                       GPBSET;                      // 0x14 GPIO B Output Set (GPIO32 to GPIO64)
    union   GPBCLEAR_REG                     GPBCLEAR;                    // 0x18 GPIO B Output Clear (GPIO32 to GPIO64)
    union   GPBTOGGLE_REG                    GPBTOGGLE;                   // 0x1c GPIO B Output Toggle (GPIO32 to GPIO64)
    union   GPCDAT_REG                       GPCDAT;                      // 0x20 GPIO C Data Register (GPIO64 to GPIO95)
    union   GPCSET_REG                       GPCSET;                      // 0x24 GPIO C Output Set  (GPIO64 to GPIO95)
    union   GPCCLEAR_REG                     GPCCLEAR;                    // 0x28 GPIO C Output Clear  (GPIO64 to GPIO95)
    union   GPCTOGGLE_REG                    GPCTOGGLE;                   // 0x2c GPIO C Output Toggle (GPIO64 to GPIO95)
    Uint32                                   rsvd1[16];                   // 0x30 Reserved
    union   GPHDAT_REG                       GPHDAT;                      // 0x70 GPIO H Data Register (GPIO0 to GPIO255)
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
