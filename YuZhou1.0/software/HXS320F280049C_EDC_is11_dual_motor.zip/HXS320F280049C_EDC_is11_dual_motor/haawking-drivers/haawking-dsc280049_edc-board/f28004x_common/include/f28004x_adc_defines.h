//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################

#ifndef F28004X_ADC_DEFINES_H
#define F28004X_ADC_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

//
// Defines
//

//
// Definitions for specifying an ADC
//
#define ADC_ADCA        0
#define ADC_ADCB        1
#define ADC_ADCC        2
#define ADC_ADCD        3

//
// Definitions for specifying reference mode
//
#define ADC_INTERNAL    0
#define ADC_EXTERNAL    1

//
// Definitions for specifying reference voltage
//
#define ADC_VREF3P3     0
#define ADC_VREF2P5     1


#ifdef __cplusplus
}
#endif /* extern "C" */

#endif

//
// End of file
//
