//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:13:45.324820
//
//#############################################################################


#ifndef F28004X_ECAP_H
#define F28004X_ECAP_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// ECAP Individual Register Bit Definitions:

struct ECCTL0_BITS {                          // bits description
    Uint32 INPUTSEL:7;                        // 6:0 INPUT source select
    Uint32 rsvd1:9;                           // 15:7 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECCTL0_REG {
    Uint32  all;
    struct  ECCTL0_BITS  bit;
};

struct ECCTL1_BITS {                          // bits description
    Uint32 CAP1POL:1;                         // 0 Capture Event 1 Polarity select
    Uint32 CTRRST1:1;                         // 1 Counter Reset on Capture Event 1
    Uint32 CAP2POL:1;                         // 2 Capture Event 2 Polarity select
    Uint32 CTRRST2:1;                         // 3 Counter Reset on Capture Event 2
    Uint32 CAP3POL:1;                         // 4 Capture Event 3 Polarity select
    Uint32 CTRRST3:1;                         // 5 Counter Reset on Capture Event 3
    Uint32 CAP4POL:1;                         // 6 Capture Event 4 Polarity select
    Uint32 CTRRST4:1;                         // 7 Counter Reset on Capture Event 4
    Uint32 CAPLDEN:1;                         // 8 Enable Loading CAP1-4 regs on a Cap Event
    Uint32 PRESCALE:5;                        // 13:9 Event Filter prescale select
    Uint32 FREE_SOFT:2;                       // 15:14 Emulation mode
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union ECCTL1_REG {
    Uint32  all;
    struct  ECCTL1_BITS  bit;
};

struct ECCTL2_BITS {                          // bits description
    Uint32 CONT_ONESHT:1;                     // 0 Continuous or one-shot
    Uint32 STOP_WRAP:2;                       // 2:1 Stop value for one-shot, Wrap for continuous
    Uint32 REARM:1;                           // 3 One-shot re-arm
    Uint32 TSCTRSTOP:1;                       // 4 TSCNT counter stop
    Uint32 SYNCI_EN:1;                        // 5 Counter sync-in select
    Uint32 SYNCO_SEL:2;                       // 7:6 Sync-out mode
    Uint32 SWSYNC:1;                          // 8 SW forced counter sync
    Uint32 CAP_APWM:1;                        // 9 CAP/APWM operating mode select
    Uint32 APWMPOL:1;                         // 10 APWM output polarity select
    Uint32 CTRFILTRESET:1;                    // 11 Reset event filter, modulus counter, and interrupt flags.
    Uint32 DMAEVTSEL:2;                       // 13:12 DMA event select
    Uint32 MODCNTRSTS:2;                      // 15:14 modulo counter status
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union ECCTL2_REG {
    Uint32  all;
    struct  ECCTL2_BITS  bit;
};

struct ECEINT_BITS {                          // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 CEVT1:1;                           // 1 Capture Event 1 Interrupt Enable
    Uint32 CEVT2:1;                           // 2 Capture Event 2 Interrupt Enable
    Uint32 CEVT3:1;                           // 3 Capture Event 3 Interrupt Enable
    Uint32 CEVT4:1;                           // 4 Capture Event 4 Interrupt Enable
    Uint32 CTROVF:1;                          // 5 Counter Overflow Interrupt Enable
    Uint32 CTR_EQ_PRD:1;                      // 6 Period Equal Interrupt Enable
    Uint32 CTR_EQ_CMP:1;                      // 7 Compare Equal Interrupt Enable
    Uint32 rsvd2:1;                           // 8 Reserved
    Uint32 rsvd3:7;                           // 15:9 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union ECEINT_REG {
    Uint32  all;
    struct  ECEINT_BITS  bit;
};

struct ECFLG_BITS {                           // bits description
    Uint32 INT:1;                             // 0 Global Flag
    Uint32 CEVT1:1;                           // 1 Capture Event 1 Interrupt Flag
    Uint32 CEVT2:1;                           // 2 Capture Event 2 Interrupt Flag
    Uint32 CEVT3:1;                           // 3 Capture Event 3 Interrupt Flag
    Uint32 CEVT4:1;                           // 4 Capture Event 4 Interrupt Flag
    Uint32 CTROVF:1;                          // 5 Counter Overflow Interrupt Flag
    Uint32 CTR_PRD:1;                         // 6 Period Equal Interrupt Flag
    Uint32 CTR_CMP:1;                         // 7 Compare Equal Interrupt Flag
    Uint32 rsvd1:1;                           // 8 Reserved
    Uint32 rsvd2:23;                          // 31:9 Reserved
};

union ECFLG_REG {
    Uint32  all;
    struct  ECFLG_BITS  bit;
};

struct ECCLR_BITS {                           // bits description
    Uint32 INT:1;                             // 0 ECAP Global Interrupt Status Clear
    Uint32 CEVT1:1;                           // 1 Capture Event 1 Status Clear
    Uint32 CEVT2:1;                           // 2 Capture Event 2 Status Clear
    Uint32 CEVT3:1;                           // 3 Capture Event 3 Status Clear
    Uint32 CEVT4:1;                           // 4 Capture Event 4 Status Clear
    Uint32 CTROVF:1;                          // 5 Counter Overflow Status Clear
    Uint32 CTR_PRD:1;                         // 6 Period Equal Status Clear
    Uint32 CTR_CMP:1;                         // 7 Compare Equal Status Clear
    Uint32 rsvd1:1;                           // 8 Reserved
    Uint32 rsvd2:23;                          // 31:9 Reserved
};

union ECCLR_REG {
    Uint32  all;
    struct  ECCLR_BITS  bit;
};

struct ECFRC_BITS {                           // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 CEVT1:1;                           // 1 Capture Event 1 Force Interrupt
    Uint32 CEVT2:1;                           // 2 Capture Event 2 Force Interrupt
    Uint32 CEVT3:1;                           // 3 Capture Event 3 Force Interrupt
    Uint32 CEVT4:1;                           // 4 Capture Event 4 Force Interrupt
    Uint32 CTROVF:1;                          // 5 Counter Overflow Force Interrupt
    Uint32 CTR_PRD:1;                         // 6 Period Equal Force Interrupt
    Uint32 CTR_CMP:1;                         // 7 Compare Equal Force Interrupt
    Uint32 rsvd2:1;                           // 8 Reserved
    Uint32 rsvd3:23;                          // 31:9 Reserved
};

union ECFRC_REG {
    Uint32  all;
    struct  ECFRC_BITS  bit;
};

struct  ECAP_REGS {
    Uint32                                   TSCTR;                       // 0x0 Time-Stamp Counter
    Uint32                                   CTRPHS;                      // 0x4 Counter Phase Offset Value Register
    Uint32                                   CAP1;                        // 0x8 Capture 1 Register
    Uint32                                   CAP2;                        // 0xc Capture 2 Register
    Uint32                                   CAP3;                        // 0x10 Capture 3 Register
    Uint32                                   CAP4;                        // 0x14 Capture 4 Register
    Uint32                                   rsvd1[2];                    // 0x18 Reserved
    union   ECCTL0_REG                       ECCTL0;                      // 0x20 Capture Control Register 0
    union   ECCTL1_REG                       ECCTL1;                      // 0x24 Capture Control Register 1
    union   ECCTL2_REG                       ECCTL2;                      // 0x28 Capture Control Register 2
    union   ECEINT_REG                       ECEINT;                      // 0x2c Capture Interrupt Enable Register
    union   ECFLG_REG                        ECFLG;                       // 0x30 Capture Interrupt Flag Register
    union   ECCLR_REG                        ECCLR;                       // 0x34 Capture Interrupt Clear Register
    union   ECFRC_REG                        ECFRC;                       // 0x38 Capture Interrupt Force Register
    Uint32                                   ECAPSYNCINSEL;               // 0x3c  
};

struct HRCTL_BITS {                           // bits description
    Uint32 HRE:1;                             // 0 High Resolution Enable
    Uint32 HRCLKE:1;                          // 1 High Resolution Clock Enable
    Uint32 PRDSEL:1;                          // 2 Calibration Period Match
    Uint32 CALIBSTART:1;                      // 3 Calibration start
    Uint32 CALIBSTS:1;                        // 4 Calibration status
    Uint32 CALIBCONT:1;                       // 5 Continuous mode Calibration Select
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union HRCTL_REG {
    Uint32  all;
    struct  HRCTL_BITS  bit;
};

struct HRINTEN_BITS {                         // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 CALIBDONE:1;                       // 1 Calibration doe interrupt enable
    Uint32 CALPRDCHKSTS:1;                    // 2 Calibration period check status enable
    Uint32 rsvd2:13;                          // 15:3 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union HRINTEN_REG {
    Uint32  all;
    struct  HRINTEN_BITS  bit;
};

struct HRFLG_BITS {                           // bits description
    Uint32 CALIBINT:1;                        // 0 Global calibration Interrupt Status Flag
    Uint32 CALIBDONE:1;                       // 1 Calibration Done Interrupt Flag Bit
    Uint32 CALPRDCHKSTS:1;                    // 2 Calibration period check status Flag Bi
    Uint32 rsvd1:13;                          // 15:3 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union HRFLG_REG {
    Uint32  all;
    struct  HRFLG_BITS  bit;
};

struct HRCLR_BITS {                           // bits description
    Uint32 CALIBINT:1;                        // 0 Clear Global calibration Interrupt Flag
    Uint32 CALIBDONE:1;                       // 1 Clear Calibration Done Interrupt Flag Bit
    Uint32 CALPRDCHKSTS:1;                    // 2 Clear Calibration period check status Flag Bit
    Uint32 rsvd1:13;                          // 15:3 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union HRCLR_REG {
    Uint32  all;
    struct  HRCLR_BITS  bit;
};

struct HRFRC_BITS {                           // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 CALIBDONE:1;                       // 1 Force Calibration Done Interrupt Flag Bit
    Uint32 CALPRDCHKSTS:1;                    // 2 Force Calibration period check status Flag Bit
    Uint32 rsvd2:13;                          // 15:3 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union HRFRC_REG {
    Uint32  all;
    struct  HRFRC_BITS  bit;
};

struct  HRCAP_REGS {
    union   HRCTL_REG                        HRCTL;                       // 0x0 High-Res Control Register
    Uint32                                   rsvd1;                       // 0x4 Reserved
    union   HRINTEN_REG                      HRINTEN;                     // 0x8 High-Res Calibration Interrupt Enable Register
    union   HRFLG_REG                        HRFLG;                       // 0xc High-Res Calibration Interrupt Flag Register
    union   HRCLR_REG                        HRCLR;                       // 0x10 High-Res Calibration Interrupt Clear Register
    union   HRFRC_REG                        HRFRC;                       // 0x14 High-Res Calibration Interrupt Force Register
    Uint32                                   HRCALPRD;                    // 0x18 High-Res Calibration Period Register
    Uint32                                   HRSYSCLKCTR;                 // 0x1c High-Res Calibration SYSCLK Counter Register
    Uint32                                   HRSYSCLKCAP;                 // 0x20 High-Res Calibration SYSCLK Capture Register
    Uint32                                   HRCLKCTR;                    // 0x24 High-Res Calibration HRCLK Counter Register
    Uint32                                   HRCLKCAP;                    // 0x28 High-Res Calibration HRCLK Capture Register
    Uint32                                   HRPLL;                       // 0x2c  
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
