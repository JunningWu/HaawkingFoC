
#include "F28x_Project.h"
#include <syscalls.h>


#define SCI_BAUD_230400 230400
#define SCI_BAUD_115200 115200
extern void Scia_Send(uint8 data);
extern void Scia_Config(uint32 baud);
extern void InitSciGpio();
