//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:13:46.236769
//
//#############################################################################


#ifndef F28004X_SYSCTRL_H
#define F28004X_SYSCTRL_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// SYSCTRL Individual Register Bit Definitions:

struct REVID_BITS {                           // bits description
    Uint32 REVID:16;                          // 15:0 Device Revision ID. This is specific to the Device
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union REVID_REG {
    Uint32  all;
    struct  REVID_BITS  bit;
};

struct DC21_BITS {                            // bits description
    Uint32 CLB1:1;                            // 0 CLB1 Present
    Uint32 CLB2:1;                            // 1 CLB2 Present
    Uint32 CLB3:1;                            // 2 CLB3 Present
    Uint32 CLB4:1;                            // 3 CLB4 Present
    Uint32 rsvd1:12;                          // 15:4 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union DC21_REG {
    Uint32  all;
    struct  DC21_BITS  bit;
};

struct FUSEERR_BITS {                         // bits description
    Uint32 ALERR:5;                           // 4:0 Efuse Autoload Error Status
    Uint32 ERR:1;                             // 5 Efuse Self Test Error Status
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union FUSEERR_REG {
    Uint32  all;
    struct  FUSEERR_BITS  bit;
};

struct SOFTPRES0_BITS {                       // bits description
    Uint32 CPU1_CLA1:1;                       // 0 CPU1_CLA1 software reset bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:1;                           // 2 Reserved
    Uint32 rsvd3:1;                           // 3 Reserved
    Uint32 rsvd4:12;                          // 15:4 Reserved
    Uint32 rsvd5:16;                          // 31:16 Reserved
};

union SOFTPRES0_REG {
    Uint32  all;
    struct  SOFTPRES0_BITS  bit;
};

struct SOFTPRES2_BITS {                       // bits description
    Uint32 EPWM1:1;                           // 0 EPWM1 software reset bit
    Uint32 EPWM2:1;                           // 1 EPWM2 software reset bit
    Uint32 EPWM3:1;                           // 2 EPWM3 software reset bit
    Uint32 EPWM4:1;                           // 3 EPWM4 software reset bit
    Uint32 EPWM5:1;                           // 4 EPWM5 software reset bit
    Uint32 EPWM6:1;                           // 5 EPWM6 software reset bit
    Uint32 EPWM7:1;                           // 6 EPWM7 software reset bit
    Uint32 EPWM8:1;                           // 7 EPWM8 software reset bit
    Uint32 rsvd1:1;                           // 8 Reserved
    Uint32 rsvd2:1;                           // 9 Reserved
    Uint32 rsvd3:1;                           // 10 Reserved
    Uint32 rsvd4:1;                           // 11 Reserved
    Uint32 rsvd5:1;                           // 12 Reserved
    Uint32 rsvd6:1;                           // 13 Reserved
    Uint32 rsvd7:1;                           // 14 Reserved
    Uint32 rsvd8:1;                           // 15 Reserved
    Uint32 rsvd9:16;                          // 31:16 Reserved
};

union SOFTPRES2_REG {
    Uint32  all;
    struct  SOFTPRES2_BITS  bit;
};

struct SOFTPRES3_BITS {                       // bits description
    Uint32 ECAP1:1;                           // 0 ECAP1 software reset bit
    Uint32 ECAP2:1;                           // 1 ECAP2 software reset bit
    Uint32 ECAP3:1;                           // 2 ECAP3 software reset bit
    Uint32 ECAP4:1;                           // 3 ECAP4 software reset bit
    Uint32 ECAP5:1;                           // 4 ECAP5 software reset bit
    Uint32 ECAP6:1;                           // 5 ECAP6 software reset bit
    Uint32 ECAP7:1;                           // 6 ECAP7 software reset bit
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union SOFTPRES3_REG {
    Uint32  all;
    struct  SOFTPRES3_BITS  bit;
};

struct SOFTPRES4_BITS {                       // bits description
    Uint32 EQEP1:1;                           // 0 EQEP1 software reset bit
    Uint32 EQEP2:1;                           // 1 EQEP2 software reset bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union SOFTPRES4_REG {
    Uint32  all;
    struct  SOFTPRES4_BITS  bit;
};

struct SOFTPRES6_BITS {                       // bits description
    Uint32 SD1:1;                             // 0 SD1 software reset bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:1;                           // 2 Reserved
    Uint32 rsvd3:1;                           // 3 Reserved
    Uint32 rsvd4:1;                           // 4 Reserved
    Uint32 rsvd5:1;                           // 5 Reserved
    Uint32 rsvd6:1;                           // 6 Reserved
    Uint32 rsvd7:1;                           // 7 Reserved
    Uint32 rsvd8:8;                           // 15:8 Reserved
    Uint32 rsvd9:16;                          // 31:16 Reserved
};

union SOFTPRES6_REG {
    Uint32  all;
    struct  SOFTPRES6_BITS  bit;
};

struct SOFTPRES7_BITS {                       // bits description
    Uint32 SCI_A:1;                           // 0 SCI_A software reset bit
    Uint32 SCI_B:1;                           // 1 SCI_B software reset bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union SOFTPRES7_REG {
    Uint32  all;
    struct  SOFTPRES7_BITS  bit;
};

struct SOFTPRES8_BITS {                       // bits description
    Uint32 SPI_A:1;                           // 0 SPI_A software reset bit
    Uint32 SPI_B:1;                           // 1 SPI_B software reset bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:1;                           // 16 Reserved
    Uint32 rsvd5:1;                           // 17 Reserved
    Uint32 rsvd6:14;                          // 31:18 Reserved
};

union SOFTPRES8_REG {
    Uint32  all;
    struct  SOFTPRES8_BITS  bit;
};

struct SOFTPRES9_BITS {                       // bits description
    Uint32 I2C_A:1;                           // 0 I2C_A software reset bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:14;                          // 15:2 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union SOFTPRES9_REG {
    Uint32  all;
    struct  SOFTPRES9_BITS  bit;
};

struct SOFTPRES10_BITS {                      // bits description
    Uint32 CAN_A:1;                           // 0 CAN_A software reset bit
    Uint32 CAN_B:1;                           // 1 CAN_B software reset bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union SOFTPRES10_REG {
    Uint32  all;
    struct  SOFTPRES10_BITS  bit;
};

struct SOFTPRES13_BITS {                      // bits description
    Uint32 ADC_A:1;                           // 0 ADC_A software reset bit
    Uint32 ADC_B:1;                           // 1 ADC_B software reset bit
    Uint32 ADC_C:1;                           // 2 ADC_C software reset bit
    Uint32 rsvd1:1;                           // 3 Reserved
    Uint32 rsvd2:12;                          // 15:4 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union SOFTPRES13_REG {
    Uint32  all;
    struct  SOFTPRES13_BITS  bit;
};

struct SOFTPRES14_BITS {                      // bits description
    Uint32 CMPSS1:1;                          // 0 CMPSS1 software reset bit
    Uint32 CMPSS2:1;                          // 1 CMPSS2 software reset bit
    Uint32 CMPSS3:1;                          // 2 CMPSS3 software reset bit
    Uint32 CMPSS4:1;                          // 3 CMPSS4 software reset bit
    Uint32 CMPSS5:1;                          // 4 CMPSS5 software reset bit
    Uint32 CMPSS6:1;                          // 5 CMPSS6 software reset bit
    Uint32 CMPSS7:1;                          // 6 CMPSS7 software reset bit
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union SOFTPRES14_REG {
    Uint32  all;
    struct  SOFTPRES14_BITS  bit;
};

struct SOFTPRES15_BITS {                      // bits description
    Uint32 PGA1:1;                            // 0 PGA1 software reset bit
    Uint32 PGA2:1;                            // 1 PGA2 software reset bit
    Uint32 PGA3:1;                            // 2 PGA3 software reset bit
    Uint32 PGA4:1;                            // 3 PGA4 software reset bit
    Uint32 PGA5:1;                            // 4 PGA5 software reset bit
    Uint32 PGA6:1;                            // 5 PGA6 software reset bit
    Uint32 PGA7:1;                            // 6 PGA7 software reset bit
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union SOFTPRES15_REG {
    Uint32  all;
    struct  SOFTPRES15_BITS  bit;
};

struct SOFTPRES16_BITS {                      // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 rsvd2:1;                           // 1 Reserved
    Uint32 rsvd3:1;                           // 2 Reserved
    Uint32 rsvd4:1;                           // 3 Reserved
    Uint32 rsvd5:12;                          // 15:4 Reserved
    Uint32 DAC_A:1;                           // 16 Buffered_DAC_A software reset bit
    Uint32 DAC_B:1;                           // 17 Buffered_DAC_B software reset bit
    Uint32 rsvd6:1;                           // 18 Reserved
    Uint32 rsvd7:1;                           // 19 Reserved
    Uint32 rsvd8:12;                          // 31:20 Reserved
};

union SOFTPRES16_REG {
    Uint32  all;
    struct  SOFTPRES16_BITS  bit;
};

struct SOFTPRES17_BITS {                      // bits description
    Uint32 CLB1:1;                            // 0 CLB1 software reset bit
    Uint32 CLB2:1;                            // 1 CLB2 software reset bit
    Uint32 CLB3:1;                            // 2 CLB3 software reset bit
    Uint32 CLB4:1;                            // 3 CLB4 software reset bit
    Uint32 rsvd1:12;                          // 15:4 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SOFTPRES17_REG {
    Uint32  all;
    struct  SOFTPRES17_BITS  bit;
};

struct SOFTPRES18_BITS {                      // bits description
    Uint32 FSITX_A:1;                         // 0 FSITX_A software reset bit 
    Uint32 FSIRX_A:1;                         // 1 FSIRX_A software reset bit 
    Uint32 rsvd1:30;                          // 31:2 Reserved
};

union SOFTPRES18_REG {
    Uint32  all;
    struct  SOFTPRES18_BITS  bit;
};

struct SOFTPRES19_BITS {                      // bits description
    Uint32 LIN_A:1;                           // 0 LIN_A software reset bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:1;                           // 2 Reserved
    Uint32 rsvd3:1;                           // 3 Reserved
    Uint32 rsvd4:12;                          // 15:4 Reserved
    Uint32 rsvd5:16;                          // 31:16 Reserved
};

union SOFTPRES19_REG {
    Uint32  all;
    struct  SOFTPRES19_BITS  bit;
};

struct SOFTPRES20_BITS {                      // bits description
    Uint32 PMBUS_A:1;                         // 0 PMBUS_A software reset bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:14;                          // 15:2 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union SOFTPRES20_REG {
    Uint32  all;
    struct  SOFTPRES20_BITS  bit;
};

struct SOFTPRES21_BITS {                      // bits description
    Uint32 DCC_0:1;                           // 0 DCC_0 software reset bit
    Uint32 rsvd1:31;                          // 31:1 Reserved
};

union SOFTPRES21_REG {
    Uint32  all;
    struct  SOFTPRES21_BITS  bit;
};

struct SOFTPRES26_BITS {                      // bits description
    Uint32 I2S_A:1;                           // 0 I2S_A software reset bit
    Uint32 rsvd1:31;                          // 31:1 Reserved
};

union SOFTPRES26_REG {
    Uint32  all;
    struct  SOFTPRES26_BITS  bit;
};

struct TAP_STATUS_BITS {                      // bits description
    Uint32 TAP_STATE:16;                      // 15:0 Present JTAG TAP State
    Uint32 rsvd1:15;                          // 30:16 Reserved
    Uint32 DCON:1;                            // 31 Debugger Connect Indication
};

union TAP_STATUS_REG {
    Uint32  all;
    struct  TAP_STATUS_BITS  bit;
};

struct  DEV_CFG_REGS {
    Uint32                                   rsvd1[6];                    // 0x0 Reserved
    union   REVID_REG                        REVID;                       // 0x18 Device Revision Number
    Uint32                                   rsvd2[22];                   // 0x1c Reserved
    union   DC21_REG                         DC21;                        // 0x74 Device Capability: CLB
    Uint32                                   rsvd3[28];                   // 0x78 Reserved
    union   FUSEERR_REG                      FUSEERR;                     // 0xe8 e-Fuse error Status register
    Uint32                                   rsvd4[6];                    // 0xec Reserved
    union   SOFTPRES0_REG                    SOFTPRES0;                   // 0x104 Processing Block Software Reset register
    Uint32                                   rsvd5;                       // 0x108 Reserved
    union   SOFTPRES2_REG                    SOFTPRES2;                   // 0x10c Peripheral Software Reset register
    union   SOFTPRES3_REG                    SOFTPRES3;                   // 0x110 Peripheral Software Reset register
    union   SOFTPRES4_REG                    SOFTPRES4;                   // 0x114 Peripheral Software Reset register
    Uint32                                   rsvd6;                       // 0x118 Reserved
    union   SOFTPRES6_REG                    SOFTPRES6;                   // 0x11c Peripheral Software Reset register
    union   SOFTPRES7_REG                    SOFTPRES7;                   // 0x120 Peripheral Software Reset register
    union   SOFTPRES8_REG                    SOFTPRES8;                   // 0x124 Peripheral Software Reset register
    union   SOFTPRES9_REG                    SOFTPRES9;                   // 0x128 Peripheral Software Reset register
    union   SOFTPRES10_REG                   SOFTPRES10;                  // 0x12c Peripheral Software Reset register
    Uint32                                   rsvd7[2];                    // 0x130 Reserved
    union   SOFTPRES13_REG                   SOFTPRES13;                  // 0x138 Peripheral Software Reset register
    union   SOFTPRES14_REG                   SOFTPRES14;                  // 0x13c Peripheral Software Reset register
    union   SOFTPRES15_REG                   SOFTPRES15;                  // 0x140 Peripheral Software Reset register
    union   SOFTPRES16_REG                   SOFTPRES16;                  // 0x144 Peripheral Software Reset register
    union   SOFTPRES17_REG                   SOFTPRES17;                  // 0x148 Peripheral Software Reset register
    union   SOFTPRES18_REG                   SOFTPRES18;                  // 0x14c Peripheral Software Reset register
    union   SOFTPRES19_REG                   SOFTPRES19;                  // 0x150 Peripheral Software Reset register
    union   SOFTPRES20_REG                   SOFTPRES20;                  // 0x154 Peripheral Software Reset register
    union   SOFTPRES21_REG                   SOFTPRES21;                  // 0x158 Peripheral Software Reset register
    Uint32                                   rsvd8[4];                    // 0x15c Reserved
    union   SOFTPRES26_REG                   SOFTPRES26;                  // 0x16c Peripheral Software Reset register
    Uint32                                   rsvd9[60];                   // 0x170 Reserved
    union   TAP_STATUS_REG                   TAP_STATUS;                  // 0x260 Status of JTAG State machine & Debugger Connect
};

struct CLKCFGLOCK1_BITS {                     // bits description
    Uint32 CLKSRCCTL1:1;                      // 0 Lock bit for CLKSRCCTL1 register
    Uint32 CLKSRCCTL2:1;                      // 1 Lock bit for CLKSRCCTL2 register
    Uint32 CLKSRCCTL3:1;                      // 2 Lock bit for CLKSRCCTL3 register
    Uint32 SYSPLLCTL1:1;                      // 3 Lock bit for SYSPLLCTL1 register
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 rsvd2:1;                           // 5 Reserved
    Uint32 SYSPLLMULT:1;                      // 6 Lock bit for SYSPLLMULT register
    Uint32 rsvd3:1;                           // 7 Reserved
    Uint32 rsvd4:1;                           // 8 Reserved
    Uint32 rsvd5:1;                           // 9 Reserved
    Uint32 rsvd6:1;                           // 10 Reserved
    Uint32 SYSCLKDIVSEL:1;                    // 11 Lock bit for SYSCLKDIVSEL register
    Uint32 rsvd7:1;                           // 12 Reserved
    Uint32 rsvd8:1;                           // 13 Reserved
    Uint32 rsvd9:1;                           // 14 Reserved
    Uint32 LOSPCP:1;                          // 15 Lock bit for LOSPCP register
    Uint32 XTALCR:1;                          // 16 Lock bit for XTALCR register
    Uint32 rsvd10:15;                         // 31:17 Reserved
};

union CLKCFGLOCK1_REG {
    Uint32  all;
    struct  CLKCFGLOCK1_BITS  bit;
};

struct CLKSRCCTL1_BITS {                      // bits description
    Uint32 OSCCLKSRCSEL:2;                    // 1:0 OSCCLK Source Select Bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 INTOSC2OFF:1;                      // 3 Internal Oscillator 2 Off Bit
    Uint32 rsvd2:1;                           // 4 Reserved
    Uint32 WDHALTI:1;                         // 5 Watchdog HALT Mode Ignore Bit
    Uint32 rsvd3:10;                          // 15:6 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union CLKSRCCTL1_REG {
    Uint32  all;
    struct  CLKSRCCTL1_BITS  bit;
};

struct CLKSRCCTL2_BITS {                      // bits description
    Uint32 rsvd1:2;                           // 1:0 Reserved
    Uint32 CANABCLKSEL:2;                     // 3:2 CANA Bit Clock Source Select Bit
    Uint32 CANBBCLKSEL:2;                     // 5:4 CANB Bit Clock Source Select Bit
    Uint32 rsvd2:2;                           // 7:6 Reserved
    Uint32 rsvd3:2;                           // 9:8 Reserved
    Uint32 rsvd4:6;                           // 15:10 Reserved
    Uint32 rsvd5:16;                          // 31:16 Reserved
};

union CLKSRCCTL2_REG {
    Uint32  all;
    struct  CLKSRCCTL2_BITS  bit;
};

struct CLKSRCCTL3_BITS {                      // bits description
    Uint32 XCLKOUTSEL:3;                      // 2:0 XCLKOUT Source Select Bit
    Uint32 rsvd1:13;                          // 15:3 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CLKSRCCTL3_REG {
    Uint32  all;
    struct  CLKSRCCTL3_BITS  bit;
};

struct SYSPLLCTL1_BITS {                      // bits description
    Uint32 PLLEN:1;                           // 0 SYSPLL enable/disable bit
    Uint32 PLLCLKEN:1;                        // 1 SYSPLL bypassed or included in the PLLSYSCLK path
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SYSPLLCTL1_REG {
    Uint32  all;
    struct  SYSPLLCTL1_BITS  bit;
};

struct SYSPLLMULT_BITS {                      // bits description
    Uint32 IMULT:8;                           // 7:0 SYSPLL Integer Multiplier
    Uint32 VCO:3;                             // 10:8 SYSPLL Voltage-Controlled Oscillator
    Uint32 rsvd1:5;                           // 15:11 Reserved
    Uint32 ODIV:6;                            // 21:16 Output Clock Divider
    Uint32 rsvd2:2;                           // 23:22 Reserved
    Uint32 REFDIV:6;                          // 29:24 Reference Clock Divider
    Uint32 rsvd3:2;                           // 31:30 Reserved
};

union SYSPLLMULT_REG {
    Uint32  all;
    struct  SYSPLLMULT_BITS  bit;
};

struct SYSPLLSTS_BITS {                       // bits description
    Uint32 LOCKS:1;                           // 0 SYSPLL Lock Status Bit
    Uint32 SLIPS:1;                           // 1 SYSPLL Slip Status Bit
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SYSPLLSTS_REG {
    Uint32  all;
    struct  SYSPLLSTS_BITS  bit;
};

struct SYSCLKDIVSEL_BITS {                    // bits description
    Uint32 PLLSYSCLKDIV:6;                    // 5:0 PLLSYSCLK Divide Select
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SYSCLKDIVSEL_REG {
    Uint32  all;
    struct  SYSCLKDIVSEL_BITS  bit;
};

struct XCLKOUTDIVSEL_BITS {                   // bits description
    Uint32 XCLKOUTDIV:2;                      // 1:0 XCLKOUT Divide Select
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union XCLKOUTDIVSEL_REG {
    Uint32  all;
    struct  XCLKOUTDIVSEL_BITS  bit;
};

struct LOSPCP_BITS {                          // bits description
    Uint32 LSPCLKDIV:3;                       // 2:0 LSPCLK Divide Select
    Uint32 rsvd1:13;                          // 15:3 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union LOSPCP_REG {
    Uint32  all;
    struct  LOSPCP_BITS  bit;
};

struct MCDCR_BITS {                           // bits description
    Uint32 MCLKSTS:1;                         // 0 Missing Clock Status Bit
    Uint32 MCLKCLR:1;                         // 1 Missing Clock Clear Bit
    Uint32 MCLKOFF:1;                         // 2 Missing Clock Detect Off Bit
    Uint32 OSCOFF:1;                          // 3 Oscillator Clock Off Bit
    Uint32 rsvd1:12;                          // 15:4 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union MCDCR_REG {
    Uint32  all;
    struct  MCDCR_BITS  bit;
};

struct X1CNT_BITS {                           // bits description
    Uint32 X1CNT:10;                          // 9:0 X1 Counter
    Uint32 rsvd1:6;                           // 15:10 Reserved
    Uint32 CLR:1;                             // 16 X1 Counter Clear
    Uint32 rsvd2:15;                          // 31:17 Reserved
};

union X1CNT_REG {
    Uint32  all;
    struct  X1CNT_BITS  bit;
};

struct XTALCR_BITS {                          // bits description
    Uint32 OSCOFF:1;                          // 0 XTAL Oscillator powered-down
    Uint32 SE:1;                              // 1 XTAL Oscilator in Single-Ended mode
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:13;                          // 15:3 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union XTALCR_REG {
    Uint32  all;
    struct  XTALCR_BITS  bit;
};

struct HRCAPCLKSEL_BITS {                     // bits description
    Uint32 HRCAPCLK:1;                        // 0 HRCAP oscclk 0 is osc2 and 1 is xtal
    Uint32 rsvd1:31;                          // 31:1 Reserved
};

union HRCAPCLKSEL_REG {
    Uint32  all;
    struct  HRCAPCLKSEL_BITS  bit;
};

struct  CLK_CFG_REGS {
    Uint32                                   rsvd1;                       // 0x0 Reserved
    union   CLKCFGLOCK1_REG                  CLKCFGLOCK1;                 // 0x4 Lock bit for CLKCFG registers
    Uint32                                   rsvd2[2];                    // 0x8 Reserved
    union   CLKSRCCTL1_REG                   CLKSRCCTL1;                  // 0x10 Clock Source Control register-1
    union   CLKSRCCTL2_REG                   CLKSRCCTL2;                  // 0x14 Clock Source Control register-2
    union   CLKSRCCTL3_REG                   CLKSRCCTL3;                  // 0x18 Clock Source Control register-3
    union   SYSPLLCTL1_REG                   SYSPLLCTL1;                  // 0x1c SYSPLL Control register-1
    Uint32                                   rsvd3[2];                    // 0x20 Reserved
    union   SYSPLLMULT_REG                   SYSPLLMULT;                  // 0x28 SYSPLL Multiplier register
    union   SYSPLLSTS_REG                    SYSPLLSTS;                   // 0x2c SYSPLL Status register
    Uint32                                   rsvd4[5];                    // 0x30 Reserved
    union   SYSCLKDIVSEL_REG                 SYSCLKDIVSEL;                // 0x44 System Clock Divider Select register
    Uint32                                   rsvd5[2];                    // 0x48 Reserved
    union   XCLKOUTDIVSEL_REG                XCLKOUTDIVSEL;               // 0x50 XCLKOUT Divider Select register
    Uint32                                   rsvd6;                       // 0x54 Reserved
    union   LOSPCP_REG                       LOSPCP;                      // 0x58 Low Speed Clock Source Prescalar
    union   MCDCR_REG                        MCDCR;                       // 0x5c Missing Clock Detect Control Register
    union   X1CNT_REG                        X1CNT;                       // 0x60 10-bit Counter on X1 Clock
    union   XTALCR_REG                       XTALCR;                      // 0x64 XTAL Control Register
    Uint32                                   rsvd7[7];                    // 0x68 Reserved
    union   HRCAPCLKSEL_REG                  HRCAPCLKSEL;                 // 0x84 HRCAP OSC CLK
};

struct CPUSYSLOCK1_BITS {                     // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 rsvd2:1;                           // 1 Reserved
    Uint32 PIEVERRADDR:1;                     // 2 Lock bit for PIEVERRADDR Register
    Uint32 PCLKCR0:1;                         // 3 Lock bit for PCLKCR0 Register
    Uint32 rsvd3:1;                           // 4 Reserved
    Uint32 PCLKCR2:1;                         // 5 Lock bit for PCLKCR2 Register
    Uint32 PCLKCR3:1;                         // 6 Lock bit for PCLKCR3 Register
    Uint32 PCLKCR4:1;                         // 7 Lock bit for PCLKCR4 Register
    Uint32 rsvd4:1;                           // 8 Reserved
    Uint32 PCLKCR6:1;                         // 9 Lock bit for PCLKCR6 Register
    Uint32 PCLKCR7:1;                         // 10 Lock bit for PCLKCR7 Register
    Uint32 PCLKCR8:1;                         // 11 Lock bit for PCLKCR8 Register
    Uint32 PCLKCR9:1;                         // 12 Lock bit for PCLKCR9 Register
    Uint32 PCLKCR10:1;                        // 13 Lock bit for PCLKCR10 Register
    Uint32 rsvd5:1;                           // 14 Reserved
    Uint32 rsvd6:1;                           // 15 Reserved
    Uint32 PCLKCR13:1;                        // 16 Lock bit for PCLKCR13 Register
    Uint32 PCLKCR14:1;                        // 17 Lock bit for PCLKCR14 Register
    Uint32 PCLKCR15:1;                        // 18 Lock bit for PCLKCR15 Register
    Uint32 PCLKCR16:1;                        // 19 Lock bit for PCLKCR16 Register
    Uint32 rsvd7:1;                           // 20 Reserved
    Uint32 LPMCR:1;                           // 21 Lock bit for LPMCR Register
    Uint32 GPIOLPMSEL0:1;                     // 22 Lock bit for GPIOLPMSEL0 Register
    Uint32 GPIOLPMSEL1:1;                     // 23 Lock bit for GPIOLPMSEL1 Register
    Uint32 PCLKCR17:1;                        // 24 Lock bit for PCLKCR17 Register
    Uint32 PCLKCR18:1;                        // 25 Lock bit for PCLKCR18 Register
    Uint32 PCLKCR19:1;                        // 26 Lock bit for PCLKCR19 Register
    Uint32 PCLKCR20:1;                        // 27 Lock bit for PCLKCR20 Register
    Uint32 PCLKCR21:1;                        // 28 Lock bit for PCLKCR21 Register
    Uint32 rsvd8:1;                           // 29 Reserved
    Uint32 rsvd9:1;                           // 30 Reserved
    Uint32 rsvd10:1;                          // 31 Reserved
};

union CPUSYSLOCK1_REG {
    Uint32  all;
    struct  CPUSYSLOCK1_BITS  bit;
};

struct PIEVERRADDR_BITS {                     // bits description
    Uint32 ADDR:22;                           // 21:0 PIE Vector Fetch Error Handler Routine Address
    Uint32 rsvd1:10;                          // 31:22 Reserved
};

union PIEVERRADDR_REG {
    Uint32  all;
    struct  PIEVERRADDR_BITS  bit;
};

struct PCLKCR0_BITS {                         // bits description
    Uint32 CLA1:1;                            // 0 CLA1 Clock Enable Bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 DMA:1;                             // 2 DMA Clock Enable bit
    Uint32 CPUTIMER0:1;                       // 3 CPUTIMER0 Clock Enable bit
    Uint32 CPUTIMER1:1;                       // 4 CPUTIMER1 Clock Enable bit
    Uint32 CPUTIMER2:1;                       // 5 CPUTIMER2 Clock Enable bit
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 HRPWM:1;                           // 16 HRPWM Clock Enable Bit
    Uint32 rsvd3:1;                           // 17 Reserved
    Uint32 TBCLKSYNC:1;                       // 18 EPWM Time Base Clock sync
    Uint32 rsvd4:1;                           // 19 Reserved
    Uint32 rsvd5:12;                          // 31:20 Reserved
};

union PCLKCR0_REG {
    Uint32  all;
    struct  PCLKCR0_BITS  bit;
};

struct PCLKCR2_BITS {                         // bits description
    Uint32 EPWM1:1;                           // 0 EPWM1 Clock Enable bit
    Uint32 EPWM2:1;                           // 1 EPWM2 Clock Enable bit
    Uint32 EPWM3:1;                           // 2 EPWM3 Clock Enable bit
    Uint32 EPWM4:1;                           // 3 EPWM4 Clock Enable bit
    Uint32 EPWM5:1;                           // 4 EPWM5 Clock Enable bit
    Uint32 EPWM6:1;                           // 5 EPWM6 Clock Enable bit
    Uint32 EPWM7:1;                           // 6 EPWM7 Clock Enable bit
    Uint32 EPWM8:1;                           // 7 EPWM8 Clock Enable bit
    Uint32 rsvd1:1;                           // 8 Reserved
    Uint32 rsvd2:1;                           // 9 Reserved
    Uint32 rsvd3:1;                           // 10 Reserved
    Uint32 rsvd4:1;                           // 11 Reserved
    Uint32 rsvd5:1;                           // 12 Reserved
    Uint32 rsvd6:1;                           // 13 Reserved
    Uint32 rsvd7:1;                           // 14 Reserved
    Uint32 rsvd8:1;                           // 15 Reserved
    Uint32 rsvd9:16;                          // 31:16 Reserved
};

union PCLKCR2_REG {
    Uint32  all;
    struct  PCLKCR2_BITS  bit;
};

struct PCLKCR3_BITS {                         // bits description
    Uint32 ECAP1:1;                           // 0 ECAP1 Clock Enable bit
    Uint32 ECAP2:1;                           // 1 ECAP2 Clock Enable bit
    Uint32 ECAP3:1;                           // 2 ECAP3 Clock Enable bit
    Uint32 ECAP4:1;                           // 3 ECAP4 Clock Enable bit
    Uint32 ECAP5:1;                           // 4 ECAP5 Clock Enable bit
    Uint32 ECAP6:1;                           // 5 ECAP6 Clock Enable bit
    Uint32 ECAP7:1;                           // 6 ECAP7 Clock Enable bit
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PCLKCR3_REG {
    Uint32  all;
    struct  PCLKCR3_BITS  bit;
};

struct PCLKCR4_BITS {                         // bits description
    Uint32 EQEP1:1;                           // 0 EQEP1 Clock Enable bit
    Uint32 EQEP2:1;                           // 1 EQEP2 Clock Enable bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union PCLKCR4_REG {
    Uint32  all;
    struct  PCLKCR4_BITS  bit;
};

struct PCLKCR6_BITS {                         // bits description
    Uint32 SD1:1;                             // 0 SD1 Clock Enable bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:1;                           // 2 Reserved
    Uint32 rsvd3:1;                           // 3 Reserved
    Uint32 rsvd4:1;                           // 4 Reserved
    Uint32 rsvd5:1;                           // 5 Reserved
    Uint32 rsvd6:1;                           // 6 Reserved
    Uint32 rsvd7:1;                           // 7 Reserved
    Uint32 rsvd8:8;                           // 15:8 Reserved
    Uint32 rsvd9:16;                          // 31:16 Reserved
};

union PCLKCR6_REG {
    Uint32  all;
    struct  PCLKCR6_BITS  bit;
};

struct PCLKCR7_BITS {                         // bits description
    Uint32 SCI_A:1;                           // 0 SCI_A Clock Enable bit
    Uint32 SCI_B:1;                           // 1 SCI_B Clock Enable bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union PCLKCR7_REG {
    Uint32  all;
    struct  PCLKCR7_BITS  bit;
};

struct PCLKCR8_BITS {                         // bits description
    Uint32 SPI_A:1;                           // 0 SPI_A Clock Enable bit
    Uint32 SPI_B:1;                           // 1 SPI_B Clock Enable bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:1;                           // 16 Reserved
    Uint32 rsvd5:1;                           // 17 Reserved
    Uint32 rsvd6:14;                          // 31:18 Reserved
};

union PCLKCR8_REG {
    Uint32  all;
    struct  PCLKCR8_BITS  bit;
};

struct PCLKCR9_BITS {                         // bits description
    Uint32 I2C_A:1;                           // 0 I2C_A Clock Enable bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:14;                          // 15:2 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PCLKCR9_REG {
    Uint32  all;
    struct  PCLKCR9_BITS  bit;
};

struct PCLKCR10_BITS {                        // bits description
    Uint32 CAN_A:1;                           // 0 CAN_A Clock Enable bit
    Uint32 CAN_B:1;                           // 1 CAN_B Clock Enable bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union PCLKCR10_REG {
    Uint32  all;
    struct  PCLKCR10_BITS  bit;
};

struct PCLKCR13_BITS {                        // bits description
    Uint32 ADC_A:1;                           // 0 ADC_A Clock Enable bit
    Uint32 ADC_B:1;                           // 1 ADC_B Clock Enable bit
    Uint32 ADC_C:1;                           // 2 ADC_C Clock Enable bit
    Uint32 rsvd1:1;                           // 3 Reserved
    Uint32 rsvd2:12;                          // 15:4 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PCLKCR13_REG {
    Uint32  all;
    struct  PCLKCR13_BITS  bit;
};

struct PCLKCR14_BITS {                        // bits description
    Uint32 CMPSS1:1;                          // 0 CMPSS1 Clock Enable bit
    Uint32 CMPSS2:1;                          // 1 CMPSS2 Clock Enable bit
    Uint32 CMPSS3:1;                          // 2 CMPSS3 Clock Enable bit
    Uint32 CMPSS4:1;                          // 3 CMPSS4 Clock Enable bit
    Uint32 CMPSS5:1;                          // 4 CMPSS5 Clock Enable bit
    Uint32 CMPSS6:1;                          // 5 CMPSS6 Clock Enable bit
    Uint32 CMPSS7:1;                          // 6 CMPSS7 Clock Enable bit
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PCLKCR14_REG {
    Uint32  all;
    struct  PCLKCR14_BITS  bit;
};

struct PCLKCR15_BITS {                        // bits description
    Uint32 PGA1:1;                            // 0 PGA1 Clock Enable bit
    Uint32 PGA2:1;                            // 1 PGA2 Clock Enable bit
    Uint32 PGA3:1;                            // 2 PGA3 Clock Enable bit
    Uint32 PGA4:1;                            // 3 PGA4 Clock Enable bit
    Uint32 PGA5:1;                            // 4 PGA5 Clock Enable bit
    Uint32 PGA6:1;                            // 5 PGA6 Clock Enable bit
    Uint32 PGA7:1;                            // 6 PGA7 Clock Enable bit
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PCLKCR15_REG {
    Uint32  all;
    struct  PCLKCR15_BITS  bit;
};

struct PCLKCR16_BITS {                        // bits description
    Uint32 rsvd1:1;                           // 0 Reserved
    Uint32 rsvd2:1;                           // 1 Reserved
    Uint32 rsvd3:1;                           // 2 Reserved
    Uint32 rsvd4:1;                           // 3 Reserved
    Uint32 rsvd5:12;                          // 15:4 Reserved
    Uint32 DAC_A:1;                           // 16 Buffered_DAC_A Clock Enable Bit
    Uint32 DAC_B:1;                           // 17 Buffered_DAC_B Clock Enable Bit
    Uint32 rsvd6:1;                           // 18 Reserved
    Uint32 rsvd7:1;                           // 19 Reserved
    Uint32 rsvd8:12;                          // 31:20 Reserved
};

union PCLKCR16_REG {
    Uint32  all;
    struct  PCLKCR16_BITS  bit;
};

struct PCLKCR17_BITS {                        // bits description
    Uint32 CLB1:1;                            // 0 CLB1 Clock Enable bit
    Uint32 CLB2:1;                            // 1 CLB2 Clock Enable bit
    Uint32 CLB3:1;                            // 2 CLB3 Clock Enable bit
    Uint32 CLB4:1;                            // 3 CLB4 Clock Enable bit
    Uint32 rsvd1:12;                          // 15:4 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PCLKCR17_REG {
    Uint32  all;
    struct  PCLKCR17_BITS  bit;
};

struct PCLKCR18_BITS {                        // bits description
    Uint32 FSITX_A:1;                         // 0 FSITX_A Clock Enable bit
    Uint32 FSIRX_A:1;                         // 1 FSIRX_A Clock Enable bit
    Uint32 rsvd1:1;                           // 2 Reserved
    Uint32 rsvd2:1;                           // 3 Reserved
    Uint32 rsvd3:12;                          // 15:4 Reserved
    Uint32 rsvd4:16;                          // 31:16 Reserved
};

union PCLKCR18_REG {
    Uint32  all;
    struct  PCLKCR18_BITS  bit;
};

struct PCLKCR19_BITS {                        // bits description
    Uint32 LIN_A:1;                           // 0 LIN_A Clock Enable bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:1;                           // 2 Reserved
    Uint32 rsvd3:1;                           // 3 Reserved
    Uint32 rsvd4:12;                          // 15:4 Reserved
    Uint32 rsvd5:16;                          // 31:16 Reserved
};

union PCLKCR19_REG {
    Uint32  all;
    struct  PCLKCR19_BITS  bit;
};

struct PCLKCR20_BITS {                        // bits description
    Uint32 PMBUS_A:1;                         // 0 PMBUS_A Clock Enable bit
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 rsvd2:14;                          // 15:2 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PCLKCR20_REG {
    Uint32  all;
    struct  PCLKCR20_BITS  bit;
};

struct PCLKCR21_BITS {                        // bits description
    Uint32 DCC_0:1;                           // 0 DCC_0 Clock Enable Bit
    Uint32 rsvd1:15;                          // 15:1 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PCLKCR21_REG {
    Uint32  all;
    struct  PCLKCR21_BITS  bit;
};

struct LPMCR_BITS {                           // bits description
    Uint32 LPM:2;                             // 1:0 Low Power Mode setting
    Uint32 rsvd1:6;                           // 7:2 Reserved
    Uint32 rsvd2:7;                           // 14:8 Reserved
    Uint32 rsvd3:1;                           // 15 Reserved
    Uint32 rsvd4:2;                           // 17:16 Reserved
    Uint32 rsvd5:13;                          // 30:18 Reserved
    Uint32 rsvd6:1;                           // 31 Reserved
};

union LPMCR_REG {
    Uint32  all;
    struct  LPMCR_BITS  bit;
};

struct GPIOLPMSEL0_BITS {                     // bits description
    Uint32 GPIO0:1;                           // 0 GPIO0 Enable for LPM Wakeup
    Uint32 GPIO1:1;                           // 1 GPIO1 Enable for LPM Wakeup
    Uint32 GPIO2:1;                           // 2 GPIO2 Enable for LPM Wakeup
    Uint32 GPIO3:1;                           // 3 GPIO3 Enable for LPM Wakeup
    Uint32 GPIO4:1;                           // 4 GPIO4 Enable for LPM Wakeup
    Uint32 GPIO5:1;                           // 5 GPIO5 Enable for LPM Wakeup
    Uint32 GPIO6:1;                           // 6 GPIO6 Enable for LPM Wakeup
    Uint32 GPIO7:1;                           // 7 GPIO7 Enable for LPM Wakeup
    Uint32 GPIO8:1;                           // 8 GPIO8 Enable for LPM Wakeup
    Uint32 GPIO9:1;                           // 9 GPIO9 Enable for LPM Wakeup
    Uint32 GPIO10:1;                          // 10 GPIO10 Enable for LPM Wakeup
    Uint32 GPIO11:1;                          // 11 GPIO11 Enable for LPM Wakeup
    Uint32 GPIO12:1;                          // 12 GPIO12 Enable for LPM Wakeup
    Uint32 GPIO13:1;                          // 13 GPIO13 Enable for LPM Wakeup
    Uint32 GPIO14:1;                          // 14 GPIO14 Enable for LPM Wakeup
    Uint32 GPIO15:1;                          // 15 GPIO15 Enable for LPM Wakeup
    Uint32 GPIO16:1;                          // 16 GPIO16 Enable for LPM Wakeup
    Uint32 GPIO17:1;                          // 17 GPIO17 Enable for LPM Wakeup
    Uint32 GPIO18:1;                          // 18 GPIO18 Enable for LPM Wakeup
    Uint32 GPIO19:1;                          // 19 GPIO19 Enable for LPM Wakeup
    Uint32 GPIO20:1;                          // 20 GPIO20 Enable for LPM Wakeup
    Uint32 GPIO21:1;                          // 21 GPIO21 Enable for LPM Wakeup
    Uint32 GPIO22:1;                          // 22 GPIO22 Enable for LPM Wakeup
    Uint32 GPIO23:1;                          // 23 GPIO23 Enable for LPM Wakeup
    Uint32 GPIO24:1;                          // 24 GPIO24 Enable for LPM Wakeup
    Uint32 GPIO25:1;                          // 25 GPIO25 Enable for LPM Wakeup
    Uint32 GPIO26:1;                          // 26 GPIO26 Enable for LPM Wakeup
    Uint32 GPIO27:1;                          // 27 GPIO27 Enable for LPM Wakeup
    Uint32 GPIO28:1;                          // 28 GPIO28 Enable for LPM Wakeup
    Uint32 GPIO29:1;                          // 29 GPIO29 Enable for LPM Wakeup
    Uint32 GPIO30:1;                          // 30 GPIO30 Enable for LPM Wakeup
    Uint32 GPIO31:1;                          // 31 GPIO31 Enable for LPM Wakeup
};

union GPIOLPMSEL0_REG {
    Uint32  all;
    struct  GPIOLPMSEL0_BITS  bit;
};

struct GPIOLPMSEL1_BITS {                     // bits description
    Uint32 GPIO32:1;                          // 0 GPIO32 Enable for LPM Wakeup
    Uint32 GPIO33:1;                          // 1 GPIO33 Enable for LPM Wakeup
    Uint32 GPIO34:1;                          // 2 GPIO34 Enable for LPM Wakeup
    Uint32 GPIO35:1;                          // 3 GPIO35 Enable for LPM Wakeup
    Uint32 GPIO36:1;                          // 4 GPIO36 Enable for LPM Wakeup
    Uint32 GPIO37:1;                          // 5 GPIO37 Enable for LPM Wakeup
    Uint32 GPIO38:1;                          // 6 GPIO38 Enable for LPM Wakeup
    Uint32 GPIO39:1;                          // 7 GPIO39 Enable for LPM Wakeup
    Uint32 GPIO40:1;                          // 8 GPIO40 Enable for LPM Wakeup
    Uint32 GPIO41:1;                          // 9 GPIO41 Enable for LPM Wakeup
    Uint32 GPIO42:1;                          // 10 GPIO42 Enable for LPM Wakeup
    Uint32 GPIO43:1;                          // 11 GPIO43 Enable for LPM Wakeup
    Uint32 GPIO44:1;                          // 12 GPIO44 Enable for LPM Wakeup
    Uint32 GPIO45:1;                          // 13 GPIO45 Enable for LPM Wakeup
    Uint32 GPIO46:1;                          // 14 GPIO46 Enable for LPM Wakeup
    Uint32 GPIO47:1;                          // 15 GPIO47 Enable for LPM Wakeup
    Uint32 GPIO48:1;                          // 16 GPIO48 Enable for LPM Wakeup
    Uint32 GPIO49:1;                          // 17 GPIO49 Enable for LPM Wakeup
    Uint32 GPIO50:1;                          // 18 GPIO50 Enable for LPM Wakeup
    Uint32 GPIO51:1;                          // 19 GPIO51 Enable for LPM Wakeup
    Uint32 GPIO52:1;                          // 20 GPIO52 Enable for LPM Wakeup
    Uint32 GPIO53:1;                          // 21 GPIO53 Enable for LPM Wakeup
    Uint32 GPIO54:1;                          // 22 GPIO54 Enable for LPM Wakeup
    Uint32 GPIO55:1;                          // 23 GPIO55 Enable for LPM Wakeup
    Uint32 GPIO56:1;                          // 24 GPIO56 Enable for LPM Wakeup
    Uint32 GPIO57:1;                          // 25 GPIO57 Enable for LPM Wakeup
    Uint32 GPIO58:1;                          // 26 GPIO58 Enable for LPM Wakeup
    Uint32 GPIO59:1;                          // 27 GPIO59 Enable for LPM Wakeup
    Uint32 GPIO60:1;                          // 28 GPIO60 Enable for LPM Wakeup
    Uint32 GPIO61:1;                          // 29 GPIO61 Enable for LPM Wakeup
    Uint32 GPIO62:1;                          // 30 GPIO62 Enable for LPM Wakeup
    Uint32 GPIO63:1;                          // 31 GPIO63 Enable for LPM Wakeup
};

union GPIOLPMSEL1_REG {
    Uint32  all;
    struct  GPIOLPMSEL1_BITS  bit;
};

struct TMR2CLKCTL_BITS {                      // bits description
    Uint32 TMR2CLKSRCSEL:3;                   // 2:0 CPU Timer 2 Clock Source Select Bit
    Uint32 TMR2CLKPRESCALE:3;                 // 5:3 CPU Timer 2 Clock Pre-Scale Value
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union TMR2CLKCTL_REG {
    Uint32  all;
    struct  TMR2CLKCTL_BITS  bit;
};

struct RESCCLR_BITS {                         // bits description
    Uint32 POR:1;                             // 0 POR Reset Cause Indication Bit
    Uint32 XRSn:1;                            // 1 XRSn Reset Cause Indication Bit
    Uint32 WDRSn:1;                           // 2 WDRSn Reset Cause Indication Bit
    Uint32 NMIWDRSn:1;                        // 3 NMIWDRSn Reset Cause Indication Bit
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 rsvd2:1;                           // 5 Reserved
    Uint32 rsvd3:1;                           // 6 Reserved
    Uint32 rsvd4:1;                           // 7 Reserved
    Uint32 SCCRESETn:1;                       // 8 SCCRESETn Reset Cause Indication Bit
    Uint32 rsvd5:7;                           // 15:9 Reserved
    Uint32 rsvd6:16;                          // 31:16 Reserved
};

union RESCCLR_REG {
    Uint32  all;
    struct  RESCCLR_BITS  bit;
};

struct RESC_BITS {                            // bits description
    Uint32 POR:1;                             // 0 POR Reset Cause Indication Bit
    Uint32 XRSn:1;                            // 1 XRSn Reset Cause Indication Bit
    Uint32 WDRSn:1;                           // 2 WDRSn Reset Cause Indication Bit
    Uint32 NMIWDRSn:1;                        // 3 NMIWDRSn Reset Cause Indication Bit
    Uint32 rsvd1:1;                           // 4 Reserved
    Uint32 rsvd2:1;                           // 5 Reserved
    Uint32 rsvd3:1;                           // 6 Reserved
    Uint32 rsvd4:1;                           // 7 Reserved
    Uint32 SCCRESETn:1;                       // 8 SCCRESETn Reset Cause Indication Bit
    Uint32 rsvd5:7;                           // 15:9 Reserved
    Uint32 rsvd6:14;                          // 29:16 Reserved
    Uint32 XRSn_pin_status:1;                 // 30 XRSN Pin Status
    Uint32 DCON:1;                            // 31 Debugger conntion status to C28x
};

union RESC_REG {
    Uint32  all;
    struct  RESC_BITS  bit;
};

struct  CPU_SYS_REGS {
    union   CPUSYSLOCK1_REG                  CPUSYSLOCK1;                 // 0x0 Lock bit for CPUSYS registers
    Uint32                                   rsvd1[4];                    // 0x4 Reserved
    union   PIEVERRADDR_REG                  PIEVERRADDR;                 // 0x14 PIE Vector Fetch Error Address register
    Uint32                                   rsvd2[11];                   // 0x18 Reserved
    union   PCLKCR0_REG                      PCLKCR0;                     // 0x44 Peripheral Clock Gating Registers
    union   PCLKCR2_REG                      PCLKCR2;                     // 0x48 Peripheral Clock Gating Registers
    union   PCLKCR3_REG                      PCLKCR3;                     // 0x4c Peripheral Clock Gating Registers
    union   PCLKCR4_REG                      PCLKCR4;                     // 0x50 Peripheral Clock Gating Registers
    Uint32                                   rsvd3[2];                    // 0x54 Reserved
    union   PCLKCR6_REG                      PCLKCR6;                     // 0x5c Peripheral Clock Gating Registers
    union   PCLKCR7_REG                      PCLKCR7;                     // 0x60 Peripheral Clock Gating Registers
    union   PCLKCR8_REG                      PCLKCR8;                     // 0x64 Peripheral Clock Gating Registers
    union   PCLKCR9_REG                      PCLKCR9;                     // 0x68 Peripheral Clock Gating Registers
    union   PCLKCR10_REG                     PCLKCR10;                    // 0x6c Peripheral Clock Gating Registers
    Uint32                                   rsvd4[2];                    // 0x70 Reserved
    union   PCLKCR13_REG                     PCLKCR13;                    // 0x78 Peripheral Clock Gating Registers
    union   PCLKCR14_REG                     PCLKCR14;                    // 0x7c Peripheral Clock Gating Registers
    union   PCLKCR15_REG                     PCLKCR15;                    // 0x80 Peripheral Clock Gating Registers
    union   PCLKCR16_REG                     PCLKCR16;                    // 0x84 Peripheral Clock Gating Registers
    union   PCLKCR17_REG                     PCLKCR17;                    // 0x88 Peripheral Clock Gating Registers
    union   PCLKCR18_REG                     PCLKCR18;                    // 0x8c Peripheral Clock Gating Registers
    union   PCLKCR19_REG                     PCLKCR19;                    // 0x90 Peripheral Clock Gating Registers
    union   PCLKCR20_REG                     PCLKCR20;                    // 0x94 Peripheral Clock Gating Registers
    union   PCLKCR21_REG                     PCLKCR21;                    // 0x98 Peripheral Clock Gating Registers
    Uint32                                   rsvd5[20];                   // 0x9c Reserved
    union   LPMCR_REG                        LPMCR;                       // 0xec LPM Control Register
    union   GPIOLPMSEL0_REG                  GPIOLPMSEL0;                 // 0xf0 GPIO LPM Wakeup select registers
    union   GPIOLPMSEL1_REG                  GPIOLPMSEL1;                 // 0xf4 GPIO LPM Wakeup select registers
    union   TMR2CLKCTL_REG                   TMR2CLKCTL;                  // 0xf8 Timer2 Clock Measurement functionality control register
    union   RESCCLR_REG                      RESCCLR;                     // 0xfc Reset Cause Clear Register
    union   RESC_REG                         RESC;                        // 0x100 Reset Cause register
};

struct WDKEY_BITS {                           // bits description
    Uint32 WDKEY:8;                           // 7:0 Key to pet the watchdog timer.
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union WDKEY_REG {
    Uint32  all;
    struct  WDKEY_BITS  bit;
};

struct SCSR_BITS {                            // bits description
    Uint32 WDOVERRIDE:1;                      // 0 WD Override for WDDIS bit
    Uint32 WDENINT:1;                         // 1 WD Interrupt Enable
    Uint32 WDINTS:1;                          // 2 WD Interrupt Status
    Uint32 rsvd1:29;                          // 31:3 Reserved
};

union SCSR_REG {
    Uint32  all;
};

struct WDCNTR_BITS {                          // bits description
    Uint32 WDCNTR:8;                          // 7:0 WD Counter
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union WDCNTR_REG {
    Uint32  all;
    struct  WDCNTR_BITS  bit;
};

struct WDCR_BITS {                            // bits description
    Uint32 WDPS:3;                            // 2:0 WD Clock Prescalar
    Uint32 WDCHK:3;                           // 5:3 WD Check Bits
    Uint32 WDDIS:1;                           // 6 WD Disable
    Uint32 rsvd1:1;                           // 7 Reserved
    Uint32 WDPRECLKDIV:4;                     // 11:8 WD Pre Clock Divider
    Uint32 rsvd2:20;                          // 31:12 Reserved
};

union WDCR_REG {
    Uint32  all;
    struct  WDCR_BITS  bit;
};

struct WDWCR_BITS {                           // bits description
    Uint32 MIN:8;                             // 7:0 WD Min Threshold setting for Windowed Watchdog functionality
    Uint32 rsvd1:1;                           // 8 Reserved
    Uint32 rsvd2:23;                          // 31:9 Reserved
};

union WDWCR_REG {
    Uint32  all;
    struct  WDWCR_BITS  bit;
};

struct  WD_REGS {
    Uint32                                   rsvd1[16];                   // 0x0 Reserved
    union   WDKEY_REG                        WDKEY;                       // 0x40 Watchdog Reset Key Register
    union   SCSR_REG                         SCSR;                        // 0x44 System Control & Status Register
    union   WDCNTR_REG                       WDCNTR;                      // 0x48 Watchdog Counter Register
    Uint32                                   rsvd2;                       // 0x4c Reserved
    union   WDCR_REG                         WDCR;                        // 0x50 Watchdog Control Register
    union   WDWCR_REG                        WDWCR;                       // 0x54 Watchdog Windowed Control Register
};

struct CLA1TASKSRCSELLOCK_BITS {              // bits description
    Uint32 CLA1TASKSRCSEL1:1;                 // 0 CLA1TASKSRCSEL1 Register Lock bit
    Uint32 CLA1TASKSRCSEL2:1;                 // 1 CLA1TASKSRCSEL2 Register Lock bit
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CLA1TASKSRCSELLOCK_REG {
    Uint32  all;
    struct  CLA1TASKSRCSELLOCK_BITS  bit;
};

struct DMACHSRCSELLOCK_BITS {                 // bits description
    Uint32 DMACHSRCSEL1:1;                    // 0 DMACHSRCSEL1 Register Lock bit
    Uint32 DMACHSRCSEL2:1;                    // 1 DMACHSRCSEL2 Register Lock bit
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union DMACHSRCSELLOCK_REG {
    Uint32  all;
    struct  DMACHSRCSELLOCK_BITS  bit;
};

struct CLA1TASKSRCSEL1_BITS {                 // bits description
    Uint32 TASK1:8;                           // 7:0 Selects the Trigger Source for TASK1 of CLA1
    Uint32 TASK2:8;                           // 15:8 Selects the Trigger Source for TASK2 of CLA1
    Uint32 TASK3:8;                           // 23:16 Selects the Trigger Source for TASK3 of CLA1
    Uint32 TASK4:8;                           // 31:24 Selects the Trigger Source for TASK4 of CLA1
};

union CLA1TASKSRCSEL1_REG {
    Uint32  all;
    struct  CLA1TASKSRCSEL1_BITS  bit;
};

struct CLA1TASKSRCSEL2_BITS {                 // bits description
    Uint32 TASK5:8;                           // 7:0 Selects the Trigger Source for TASK5 of CLA1
    Uint32 TASK6:8;                           // 15:8 Selects the Trigger Source for TASK6 of CLA1
    Uint32 TASK7:8;                           // 23:16 Selects the Trigger Source for TASK7 of CLA1
    Uint32 TASK8:8;                           // 31:24 Selects the Trigger Source for TASK8 of CLA1
};

union CLA1TASKSRCSEL2_REG {
    Uint32  all;
    struct  CLA1TASKSRCSEL2_BITS  bit;
};

struct DMACHSRCSEL1_BITS {                    // bits description
    Uint32 CH1:8;                             // 7:0 Selects the Trigger and Sync Source CH1 of DMA
    Uint32 CH2:8;                             // 15:8 Selects the Trigger and Sync Source CH2 of DMA
    Uint32 CH3:8;                             // 23:16 Selects the Trigger and Sync Source CH3 of DMA
    Uint32 CH4:8;                             // 31:24 Selects the Trigger and Sync Source CH4 of DMA
};

union DMACHSRCSEL1_REG {
    Uint32  all;
    struct  DMACHSRCSEL1_BITS  bit;
};

struct DMACHSRCSEL2_BITS {                    // bits description
    Uint32 CH5:8;                             // 7:0 Selects the Trigger and Sync Source CH5 of DMA
    Uint32 CH6:8;                             // 15:8 Selects the Trigger and Sync Source CH6 of DMA
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union DMACHSRCSEL2_REG {
    Uint32  all;
    struct  DMACHSRCSEL2_BITS  bit;
};

struct  DMA_CLA_SRC_SEL_REGS {
    union   CLA1TASKSRCSELLOCK_REG           CLA1TASKSRCSELLOCK;          // 0x0 CLA1 Task Trigger Source Select Lock Register
    Uint32                                   rsvd1;                       // 0x4 Reserved
    union   DMACHSRCSELLOCK_REG              DMACHSRCSELLOCK;             // 0x8 DMA Channel Triger Source Select Lock Register
    union   CLA1TASKSRCSEL1_REG              CLA1TASKSRCSEL1;             // 0xc CLA1 Task Trigger Source Select Register-1
    union   CLA1TASKSRCSEL2_REG              CLA1TASKSRCSEL2;             // 0x10 CLA1 Task Trigger Source Select Register-2
    Uint32                                   rsvd2[6];                    // 0x14 Reserved
    union   DMACHSRCSEL1_REG                 DMACHSRCSEL1;                // 0x2c DMA Channel Trigger Source Select Register-1
    union   DMACHSRCSEL2_REG                 DMACHSRCSEL2;                // 0x30 DMA Channel Trigger Source Select Register-2
};

struct ADCA_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ADCA_AC_REG {
    Uint32  all;
    struct  ADCA_AC_BITS  bit;
};

struct ADCB_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ADCB_AC_REG {
    Uint32  all;
    struct  ADCB_AC_BITS  bit;
};

struct ADCC_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ADCC_AC_REG {
    Uint32  all;
    struct  ADCC_AC_BITS  bit;
};

struct CMPSS1_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS1_AC_REG {
    Uint32  all;
    struct  CMPSS1_AC_BITS  bit;
};

struct CMPSS2_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS2_AC_REG {
    Uint32  all;
    struct  CMPSS2_AC_BITS  bit;
};

struct CMPSS3_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS3_AC_REG {
    Uint32  all;
    struct  CMPSS3_AC_BITS  bit;
};

struct CMPSS4_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS4_AC_REG {
    Uint32  all;
    struct  CMPSS4_AC_BITS  bit;
};

struct CMPSS5_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS5_AC_REG {
    Uint32  all;
    struct  CMPSS5_AC_BITS  bit;
};

struct CMPSS6_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS6_AC_REG {
    Uint32  all;
    struct  CMPSS6_AC_BITS  bit;
};

struct CMPSS7_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union CMPSS7_AC_REG {
    Uint32  all;
    struct  CMPSS7_AC_BITS  bit;
};

struct DACA_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union DACA_AC_REG {
    Uint32  all;
    struct  DACA_AC_BITS  bit;
};

struct DACB_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union DACB_AC_REG {
    Uint32  all;
    struct  DACB_AC_BITS  bit;
};

struct PGA1_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA1_AC_REG {
    Uint32  all;
    struct  PGA1_AC_BITS  bit;
};

struct PGA2_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA2_AC_REG {
    Uint32  all;
    struct  PGA2_AC_BITS  bit;
};

struct PGA3_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA3_AC_REG {
    Uint32  all;
    struct  PGA3_AC_BITS  bit;
};

struct PGA4_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA4_AC_REG {
    Uint32  all;
    struct  PGA4_AC_BITS  bit;
};

struct PGA5_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA5_AC_REG {
    Uint32  all;
    struct  PGA5_AC_BITS  bit;
};

struct PGA6_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA6_AC_REG {
    Uint32  all;
    struct  PGA6_AC_BITS  bit;
};

struct PGA7_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGA7_AC_REG {
    Uint32  all;
    struct  PGA7_AC_BITS  bit;
};

struct EPWM1_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM1_AC_REG {
    Uint32  all;
    struct  EPWM1_AC_BITS  bit;
};

struct EPWM2_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM2_AC_REG {
    Uint32  all;
    struct  EPWM2_AC_BITS  bit;
};

struct EPWM3_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM3_AC_REG {
    Uint32  all;
    struct  EPWM3_AC_BITS  bit;
};

struct EPWM4_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM4_AC_REG {
    Uint32  all;
    struct  EPWM4_AC_BITS  bit;
};

struct EPWM5_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM5_AC_REG {
    Uint32  all;
    struct  EPWM5_AC_BITS  bit;
};

struct EPWM6_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM6_AC_REG {
    Uint32  all;
    struct  EPWM6_AC_BITS  bit;
};

struct EPWM7_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM7_AC_REG {
    Uint32  all;
    struct  EPWM7_AC_BITS  bit;
};

struct EPWM8_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EPWM8_AC_REG {
    Uint32  all;
    struct  EPWM8_AC_BITS  bit;
};

struct EQEP1_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EQEP1_AC_REG {
    Uint32  all;
    struct  EQEP1_AC_BITS  bit;
};

struct EQEP2_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union EQEP2_AC_REG {
    Uint32  all;
    struct  EQEP2_AC_BITS  bit;
};

struct ECAP1_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP1_AC_REG {
    Uint32  all;
    struct  ECAP1_AC_BITS  bit;
};

struct ECAP2_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP2_AC_REG {
    Uint32  all;
    struct  ECAP2_AC_BITS  bit;
};

struct ECAP3_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP3_AC_REG {
    Uint32  all;
    struct  ECAP3_AC_BITS  bit;
};

struct ECAP4_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP4_AC_REG {
    Uint32  all;
    struct  ECAP4_AC_BITS  bit;
};

struct ECAP5_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP5_AC_REG {
    Uint32  all;
    struct  ECAP5_AC_BITS  bit;
};

struct ECAP6_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP6_AC_REG {
    Uint32  all;
    struct  ECAP6_AC_BITS  bit;
};

struct ECAP7_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union ECAP7_AC_REG {
    Uint32  all;
    struct  ECAP7_AC_BITS  bit;
};

struct SDFM1_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SDFM1_AC_REG {
    Uint32  all;
    struct  SDFM1_AC_BITS  bit;
};

struct CLB1_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 rsvd1:2;                           // 5:4 Reserved
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union CLB1_AC_REG {
    Uint32  all;
    struct  CLB1_AC_BITS  bit;
};

struct CLB2_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 rsvd1:2;                           // 5:4 Reserved
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union CLB2_AC_REG {
    Uint32  all;
    struct  CLB2_AC_BITS  bit;
};

struct CLB3_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 rsvd1:2;                           // 5:4 Reserved
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union CLB3_AC_REG {
    Uint32  all;
    struct  CLB3_AC_BITS  bit;
};

struct CLB4_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 rsvd1:2;                           // 5:4 Reserved
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union CLB4_AC_REG {
    Uint32  all;
    struct  CLB4_AC_BITS  bit;
};

struct CLA1PROMCRC_AC_BITS {                  // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 rsvd1:2;                           // 5:4 Reserved
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union CLA1PROMCRC_AC_REG {
    Uint32  all;
    struct  CLA1PROMCRC_AC_BITS  bit;
};

struct SCIA_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:26;                          // 31:6 Reserved
};

union SCIA_AC_REG {
    Uint32  all;
    struct  SCIA_AC_BITS  bit;
};

struct SCIB_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:26;                          // 31:6 Reserved
};

union SCIB_AC_REG {
    Uint32  all;
    struct  SCIB_AC_BITS  bit;
};

struct SPIA_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SPIA_AC_REG {
    Uint32  all;
    struct  SPIA_AC_BITS  bit;
};

struct SPIB_AC_BITS {                         // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SPIB_AC_REG {
    Uint32  all;
    struct  SPIB_AC_BITS  bit;
};

struct PMBUS_A_AC_BITS {                      // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PMBUS_A_AC_REG {
    Uint32  all;
    struct  PMBUS_A_AC_BITS  bit;
};

struct LIN_A_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union LIN_A_AC_REG {
    Uint32  all;
    struct  LIN_A_AC_BITS  bit;
};

struct DCANA_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 rsvd1:2;                           // 3:2 Reserved
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union DCANA_AC_REG {
    Uint32  all;
    struct  DCANA_AC_BITS  bit;
};

struct DCANB_AC_BITS {                        // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 rsvd1:2;                           // 3:2 Reserved
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd2:10;                          // 15:6 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union DCANB_AC_REG {
    Uint32  all;
    struct  DCANB_AC_BITS  bit;
};

struct FSIATX_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union FSIATX_AC_REG {
    Uint32  all;
    struct  FSIATX_AC_BITS  bit;
};

struct FSIARX_AC_BITS {                       // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union FSIARX_AC_REG {
    Uint32  all;
    struct  FSIARX_AC_BITS  bit;
};

struct HRPWM_A_AC_BITS {                      // bits description
    Uint32 CPU1_ACC:2;                        // 1:0 CPU1 Access conditions to peripheral
    Uint32 CLA1_ACC:2;                        // 3:2 CLA1 Access Conditions to Peripheral
    Uint32 DMA1_ACC:2;                        // 5:4 DMA1 Access Conditions to Peripheral
    Uint32 rsvd1:10;                          // 15:6 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union HRPWM_A_AC_REG {
    Uint32  all;
    struct  HRPWM_A_AC_BITS  bit;
};

struct PERIPH_AC_LOCK_BITS {                  // bits description
    Uint32 LOCK_AC_WR:1;                      // 0 Lock control for Access control registers write.
    Uint32 rsvd1:15;                          // 15:1 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PERIPH_AC_LOCK_REG {
    Uint32  all;
    struct  PERIPH_AC_LOCK_BITS  bit;
};

struct  PERIPH_AC_REGS {
    union   ADCA_AC_REG                      ADCA_AC;                     // 0x0 ADCA Master Access Control Register
    union   ADCB_AC_REG                      ADCB_AC;                     // 0x4 ADCB Master Access Control Register
    union   ADCC_AC_REG                      ADCC_AC;                     // 0x8 ADCC Master Access Control Register
    Uint32                                   rsvd1[5];                    // 0xc Reserved
    union   CMPSS1_AC_REG                    CMPSS1_AC;                   // 0x20 CMPSS1 Master Access Control Register
    union   CMPSS2_AC_REG                    CMPSS2_AC;                   // 0x24 CMPSS2 Master Access Control Register
    union   CMPSS3_AC_REG                    CMPSS3_AC;                   // 0x28 CMPSS3 Master Access Control Register
    union   CMPSS4_AC_REG                    CMPSS4_AC;                   // 0x2c CMPSS4 Master Access Control Register
    union   CMPSS5_AC_REG                    CMPSS5_AC;                   // 0x30 CMPSS5 Master Access Control Register
    union   CMPSS6_AC_REG                    CMPSS6_AC;                   // 0x34 CMPSS6 Master Access Control Register
    union   CMPSS7_AC_REG                    CMPSS7_AC;                   // 0x38 CMPSS7 Master Access Control Register
    Uint32                                   rsvd2[5];                    // 0x3c Reserved
    union   DACA_AC_REG                      DACA_AC;                     // 0x50 DACA Master Access Control Register
    union   DACB_AC_REG                      DACB_AC;                     // 0x54 DACB Master Access Control Register
    Uint32                                   rsvd3[6];                    // 0x58 Reserved
    union   PGA1_AC_REG                      PGA1_AC;                     // 0x70 PGAA Master Access Control Register
    union   PGA2_AC_REG                      PGA2_AC;                     // 0x74 PGAB Master Access Control Register
    union   PGA3_AC_REG                      PGA3_AC;                     // 0x78 PGAC Master Access Control Register
    union   PGA4_AC_REG                      PGA4_AC;                     // 0x7c PGAD Master Access Control Register
    union   PGA5_AC_REG                      PGA5_AC;                     // 0x80 PGAE Master Access Control Register
    union   PGA6_AC_REG                      PGA6_AC;                     // 0x84 PGAF Master Access Control Register
    union   PGA7_AC_REG                      PGA7_AC;                     // 0x88 PGAG Master Access Control Register
    Uint32                                   rsvd4;                       // 0x8c Reserved
    union   EPWM1_AC_REG                     EPWM1_AC;                    // 0x90 EPWM1 Master Access Control Register
    union   EPWM2_AC_REG                     EPWM2_AC;                    // 0x94 EPWM2 Master Access Control Register
    union   EPWM3_AC_REG                     EPWM3_AC;                    // 0x98 EPWM3 Master Access Control Register
    union   EPWM4_AC_REG                     EPWM4_AC;                    // 0x9c EPWM4 Master Access Control Register
    union   EPWM5_AC_REG                     EPWM5_AC;                    // 0xa0 EPWM5 Master Access Control Register
    union   EPWM6_AC_REG                     EPWM6_AC;                    // 0xa4 EPWM6 Master Access Control Register
    union   EPWM7_AC_REG                     EPWM7_AC;                    // 0xa8 EPWM7 Master Access Control Register
    union   EPWM8_AC_REG                     EPWM8_AC;                    // 0xac EPWM8 Master Access Control Register
    Uint32                                   rsvd5[12];                   // 0xb0 Reserved
    union   EQEP1_AC_REG                     EQEP1_AC;                    // 0xe0 EQEP1 Master Access Control Register
    union   EQEP2_AC_REG                     EQEP2_AC;                    // 0xe4 EQEP2 Master Access Control Register
    Uint32                                   rsvd6[6];                    // 0xe8 Reserved
    union   ECAP1_AC_REG                     ECAP1_AC;                    // 0x100 ECAP1 Master Access Control Register
    union   ECAP2_AC_REG                     ECAP2_AC;                    // 0x104 ECAP2 Master Access Control Register
    union   ECAP3_AC_REG                     ECAP3_AC;                    // 0x108 ECAP3 Master Access Control Register
    union   ECAP4_AC_REG                     ECAP4_AC;                    // 0x10c ECAP4 Master Access Control Register
    union   ECAP5_AC_REG                     ECAP5_AC;                    // 0x110 ECAP5 Master Access Control Register
    union   ECAP6_AC_REG                     ECAP6_AC;                    // 0x114 ECAP6 Master Access Control Register
    union   ECAP7_AC_REG                     ECAP7_AC;                    // 0x118 ECAP7 Master Access Control Register
    Uint32                                   rsvd7[13];                   // 0x11c Reserved
    union   SDFM1_AC_REG                     SDFM1_AC;                    // 0x150 SDFM1 Master Access Control Register
    Uint32                                   rsvd8[3];                    // 0x154 Reserved
    union   CLB1_AC_REG                      CLB1_AC;                     // 0x160 CLB1 Master Access Control Register
    union   CLB2_AC_REG                      CLB2_AC;                     // 0x164 CLB2 Master Access Control Register
    union   CLB3_AC_REG                      CLB3_AC;                     // 0x168 CLB3 Master Access Control Register
    union   CLB4_AC_REG                      CLB4_AC;                     // 0x16c CLB4 Master Access Control Register
    Uint32                                   rsvd9[4];                    // 0x170 Reserved
    union   CLA1PROMCRC_AC_REG               CLA1PROMCRC_AC;              // 0x180 CLA1PROMCRC Master Access Control Register
    Uint32                                   rsvd10[31];                  // 0x184 Reserved
    union   SCIA_AC_REG                      SCIA_AC;                     // 0x200 SCIA Master Access Control Register
    union   SCIB_AC_REG                      SCIB_AC;                     // 0x204 SCIB Master Access Control Register
    Uint32                                   rsvd11[6];                   // 0x208 Reserved
    union   SPIA_AC_REG                      SPIA_AC;                     // 0x220 SPIA Master Access Control Register
    union   SPIB_AC_REG                      SPIB_AC;                     // 0x224 SPIB Master Access Control Register
    Uint32                                   rsvd12[14];                  // 0x228 Reserved
    union   PMBUS_A_AC_REG                   PMBUS_A_AC;                  // 0x260 PMBUSA Master Access Control Register
    Uint32                                   rsvd13[3];                   // 0x264 Reserved
    union   LIN_A_AC_REG                     LIN_A_AC;                    // 0x270 LINA Master Access Control Register
    Uint32                                   rsvd14[3];                   // 0x274 Reserved
    union   DCANA_AC_REG                     DCANA_AC;                    // 0x280 DCANA Master Access Control Register
    union   DCANB_AC_REG                     DCANB_AC;                    // 0x284 DCANB Master Access Control Register
    Uint32                                   rsvd15[10];                  // 0x288 Reserved
    union   FSIATX_AC_REG                    FSIATX_AC;                   // 0x2b0 FSIA TX Master Access Control Register
    union   FSIARX_AC_REG                    FSIARX_AC;                   // 0x2b4 FSIA RX Master Access Control Register
    Uint32                                   rsvd16[39];                  // 0x2b8 Reserved
    union   HRPWM_A_AC_REG                   HRPWM_A_AC;                  // 0x354 HRPWM Master Access Control Register
    Uint32                                   rsvd17[41];                  // 0x358 Reserved
    union   PERIPH_AC_LOCK_REG               PERIPH_AC_LOCK;              // 0x3fc Lock Register to stop Write access to peripheral Access register.
};

struct SYNCSELECT_BITS {                      // bits description
    Uint32 EPWM4SYNCIN:3;                     // 2:0 Selects Sync Input Source for EPWM4
    Uint32 EPWM7SYNCIN:3;                     // 5:3 Selects Sync Input Source for EPWM7
    Uint32 rsvd1:3;                           // 8:6 Reserved
    Uint32 ECAP1SYNCIN:3;                     // 11:9 Selects Sync Input Source for ECAP1
    Uint32 ECAP4SYNCIN:3;                     // 14:12 Selects Sync Input Source for ECAP4
    Uint32 ECAP6SYNCIN:3;                     // 17:15 Selects Sync Input Source for ECAP6
    Uint32 rsvd2:9;                           // 26:18 Reserved
    Uint32 SYNCOUT:2;                         // 28:27 Select Syncout Source
    Uint32 EPWM1SYNCIN:3;                     // 31:29 Selects Sync Input Source for EPWM1
};

union SYNCSELECT_REG {
    Uint32  all;
    struct  SYNCSELECT_BITS  bit;
};

struct ADCSOCOUTSELECT_BITS {                 // bits description
    Uint32 PWM1SOCAEN:1;                      // 0 PWM1SOCAEN Enable for ADCSOCAOn
    Uint32 PWM2SOCAEN:1;                      // 1 PWM2SOCAEN Enable for ADCSOCAOn
    Uint32 PWM3SOCAEN:1;                      // 2 PWM3SOCAEN Enable for ADCSOCAOn
    Uint32 PWM4SOCAEN:1;                      // 3 PWM4SOCAEN Enable for ADCSOCAOn
    Uint32 PWM5SOCAEN:1;                      // 4 PWM5SOCAEN Enable for ADCSOCAOn
    Uint32 PWM6SOCAEN:1;                      // 5 PWM6SOCAEN Enable for ADCSOCAOn
    Uint32 PWM7SOCAEN:1;                      // 6 PWM7SOCAEN Enable for ADCSOCAOn
    Uint32 PWM8SOCAEN:1;                      // 7 PWM8SOCAEN Enable for ADCSOCAOn
    Uint32 rsvd1:1;                           // 8 Reserved
    Uint32 rsvd2:1;                           // 9 Reserved
    Uint32 rsvd3:1;                           // 10 Reserved
    Uint32 rsvd4:1;                           // 11 Reserved
    Uint32 rsvd5:4;                           // 15:12 Reserved
    Uint32 PWM1SOCBEN:1;                      // 16 PWM1SOCBEN Enable for ADCSOCBOn
    Uint32 PWM2SOCBEN:1;                      // 17 PWM2SOCBEN Enable for ADCSOCBOn
    Uint32 PWM3SOCBEN:1;                      // 18 PWM3SOCBEN Enable for ADCSOCBOn
    Uint32 PWM4SOCBEN:1;                      // 19 PWM4SOCBEN Enable for ADCSOCBOn
    Uint32 PWM5SOCBEN:1;                      // 20 PWM5SOCBEN Enable for ADCSOCBOn
    Uint32 PWM6SOCBEN:1;                      // 21 PWM6SOCBEN Enable for ADCSOCBOn
    Uint32 PWM7SOCBEN:1;                      // 22 PWM7SOCBEN Enable for ADCSOCBOn
    Uint32 PWM8SOCBEN:1;                      // 23 PWM8SOCBEN Enable for ADCSOCBOn
    Uint32 rsvd6:1;                           // 24 Reserved
    Uint32 rsvd7:1;                           // 25 Reserved
    Uint32 rsvd8:1;                           // 26 Reserved
    Uint32 rsvd9:1;                           // 27 Reserved
    Uint32 rsvd10:4;                          // 31:28 Reserved
};

union ADCSOCOUTSELECT_REG {
    Uint32  all;
    struct  ADCSOCOUTSELECT_BITS  bit;
};

struct SYNCSOCLOCK_BITS {                     // bits description
    Uint32 SYNCSELECT:1;                      // 0 SYNCSEL Register Lock bit
    Uint32 ADCSOCOUTSELECT:1;                 // 1 ADCSOCOUTSELECT Register Lock bit
    Uint32 rsvd1:14;                          // 15:2 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union SYNCSOCLOCK_REG {
    Uint32  all;
    struct  SYNCSOCLOCK_BITS  bit;
};

struct  SYNC_SOC_REGS {
    union   SYNCSELECT_REG                   SYNCSELECT;                  // 0x0 Sync Input and Output Select Register
    union   ADCSOCOUTSELECT_REG              ADCSOCOUTSELECT;             // 0x4 External ADCSOC Select Register
    union   SYNCSOCLOCK_REG                  SYNCSOCLOCK;                 // 0x8 SYNCSEL and EXTADCSOC Select Lock register
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
