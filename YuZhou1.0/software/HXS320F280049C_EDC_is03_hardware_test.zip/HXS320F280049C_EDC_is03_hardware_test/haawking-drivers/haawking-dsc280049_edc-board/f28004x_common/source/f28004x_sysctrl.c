//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################

//
// Included Files
//
#include "f28004x_device.h"     // Headerfile Include File
#include "f28004x_examples.h"   // Examples Include File

#define PMUTrims_cal ((void (*)(void))((uintptr_t)0x7e9544))
#define OscTrims_cal ((void (*)(void))((uintptr_t)0x7e9614))
#define AdcTrims_cal ((void (*)(void))((uintptr_t)0x7e96e4))

//
// Functions that will be run from RAM need to be assigned to
// a different section.  This section will then be mapped to a load and
// run address using the linker cmd file.
//
// *IMPORTANT*
// IF RUNNING FROM FLASH, PLEASE COPY OVER THE SECTION ".TI.ramfunc"  FROM FLASH
// TO RAM PRIOR TO CALLING InitSysCtrl(). THIS PREVENTS THE MCU FROM THROWING
// AN EXCEPTION WHEN A CALL TO DELAY_US() IS MADE.
//

//
// The following values are used to validate PLL Frequency using DCC
//
#define   PLL_RETRIES              100
#define   PLL_LOCK_TIMEOUT        2000
#define   DCC_COUNTER0_WINDOW      100

//
// InitSysCtrl - Initialization of system resources.
//
void
InitSysCtrl(void)
{
    //
    // Disable the watchdog
    //
    DisableDog();

    OscTrims_cal();
	PMUTrims_cal();

#ifdef __RUNNING_IN_FLASH_

    //
    // Call Flash Initialization to setup flash waitstates
    // This function must reside in RAM
    //
    InitFlash();
#endif

    //
    // PLLSYSCLK = (XTAL_OSC) / (ODIV) * (IMULT) / (REFDIV) / (PLLSYSCLKDIV)
    //
    //InitSysPll(XTAL_OSC, IMULT_32, REFDIV_2, ODIV_1, PLLCLK_BY_2);
    InitSysPll(INT_OSC2, IMULT_16, REFDIV_1, ODIV_1, PLLCLK_BY_1);

    //
    // Call Device_cal function when run using debugger
    // This function is called as part of the Boot code. The function is called
    // in the InitSysCtrl function since during debug time resets, the boot code
    // will not be executed and the gel script will reinitialize all the
    // registers and the calibrated values will be lost.
    //
    AdcTrims_cal();

    //
    // Turn on all peripherals
    //
    InitPeripheralClocks();
}

//
// InitPeripheralClocks - This function initializes the clocks for the
// peripherals. Note: In order to reduce power consumption, turn off the
// clocks to any peripheral that is not specified for your part-number or is
// not used in the application
//
void
InitPeripheralClocks()
{
    EALLOW;

    CpuSysRegs.PCLKCR0.bit.CLA1 = 1;
    CpuSysRegs.PCLKCR0.bit.DMA = 1;
    CpuSysRegs.PCLKCR0.bit.CPUTIMER0 = 1;
    CpuSysRegs.PCLKCR0.bit.CPUTIMER1 = 1;
    CpuSysRegs.PCLKCR0.bit.CPUTIMER2 = 1;
    CpuSysRegs.PCLKCR0.bit.HRPWM = 1;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;

    CpuSysRegs.PCLKCR2.bit.EPWM1 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM2 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM3 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM4 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM5 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM6 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM7 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM8 = 1;

    CpuSysRegs.PCLKCR3.bit.ECAP1 = 1;
    CpuSysRegs.PCLKCR3.bit.ECAP2 = 1;
    CpuSysRegs.PCLKCR3.bit.ECAP3 = 1;
    CpuSysRegs.PCLKCR3.bit.ECAP4 = 1;
    CpuSysRegs.PCLKCR3.bit.ECAP5 = 1;
    CpuSysRegs.PCLKCR3.bit.ECAP6 = 1;
    CpuSysRegs.PCLKCR3.bit.ECAP7 = 1;

    CpuSysRegs.PCLKCR4.bit.EQEP1 = 1;
    CpuSysRegs.PCLKCR4.bit.EQEP2 = 1;

    CpuSysRegs.PCLKCR6.bit.SD1 = 1;

    CpuSysRegs.PCLKCR7.bit.SCI_A = 1;
    CpuSysRegs.PCLKCR7.bit.SCI_B = 1;

    CpuSysRegs.PCLKCR8.bit.SPI_A = 1;
    CpuSysRegs.PCLKCR8.bit.SPI_B = 1;

    CpuSysRegs.PCLKCR9.bit.I2C_A = 1;

    CpuSysRegs.PCLKCR10.bit.CAN_A = 1;
    CpuSysRegs.PCLKCR10.bit.CAN_B = 1;

    CpuSysRegs.PCLKCR13.bit.ADC_A = 1;
    CpuSysRegs.PCLKCR13.bit.ADC_B = 1;
    CpuSysRegs.PCLKCR13.bit.ADC_C = 1;

    CpuSysRegs.PCLKCR14.bit.CMPSS1 = 1;
    CpuSysRegs.PCLKCR14.bit.CMPSS2 = 1;
    CpuSysRegs.PCLKCR14.bit.CMPSS3 = 1;
    CpuSysRegs.PCLKCR14.bit.CMPSS4 = 1;
    CpuSysRegs.PCLKCR14.bit.CMPSS5 = 1;
    CpuSysRegs.PCLKCR14.bit.CMPSS6 = 1;
    CpuSysRegs.PCLKCR14.bit.CMPSS7 = 1;

    CpuSysRegs.PCLKCR15.bit.PGA1 = 1;
    CpuSysRegs.PCLKCR15.bit.PGA2 = 1;
    CpuSysRegs.PCLKCR15.bit.PGA3 = 1;
    CpuSysRegs.PCLKCR15.bit.PGA4 = 1;
    CpuSysRegs.PCLKCR15.bit.PGA5 = 1;
    CpuSysRegs.PCLKCR15.bit.PGA6 = 1;
    CpuSysRegs.PCLKCR15.bit.PGA7 = 1;

    CpuSysRegs.PCLKCR18.bit.FSIRX_A = 1;
    CpuSysRegs.PCLKCR18.bit.FSITX_A = 1;

    CpuSysRegs.PCLKCR16.bit.DAC_A = 1;
    CpuSysRegs.PCLKCR16.bit.DAC_B = 1;

    CpuSysRegs.PCLKCR19.bit.LIN_A = 1;

    CpuSysRegs.PCLKCR20.bit.PMBUS_A = 1;

    CpuSysRegs.PCLKCR21.bit.DCC_0 = 1;

    EDIS;
}

//
// DisablePeripheralClocks -
//
void
DisablePeripheralClocks()
{
    EALLOW;

    CpuSysRegs.PCLKCR0.all = 0;
    CpuSysRegs.PCLKCR2.all = 0;
    CpuSysRegs.PCLKCR3.all = 0;
    CpuSysRegs.PCLKCR4.all = 0;
    CpuSysRegs.PCLKCR6.all = 0;
    CpuSysRegs.PCLKCR7.all = 0;
    CpuSysRegs.PCLKCR8.all = 0;
    CpuSysRegs.PCLKCR9.all = 0;
    CpuSysRegs.PCLKCR10.all = 0;
    CpuSysRegs.PCLKCR13.all = 0;
    CpuSysRegs.PCLKCR14.all = 0;
    CpuSysRegs.PCLKCR15.all = 0;
    CpuSysRegs.PCLKCR16.all = 0;
    CpuSysRegs.PCLKCR18.all = 0;
    CpuSysRegs.PCLKCR19.all = 0;
    CpuSysRegs.PCLKCR20.all = 0;
    CpuSysRegs.PCLKCR21.all = 0;

    EDIS;
}

//
// InitFlash - This function initializes the Flash Control registers
//                  CAUTION
// This function MUST be executed out of RAM. Executing it
// out of OTP/Flash will yield unpredictable results
//
void CODE_SECTION("ramfuncs") InitFlash(void)
{
    EALLOW;

    //
    // At reset bank and pump are in sleep
    // A Flash access will power up the bank and pump automatically
    //
    // Power up Flash bank and pump and this also sets the fall back mode of
    // flash and pump as active
    //
    Flash0CtrlRegs.FBFALLBACK.bit.BNKPWR0 = 0x3;
	Flash1CtrlRegs.FBFALLBACK.bit.BNKPWR0 = 0x3;

    //
    // Disable Cache and prefetch mechanism before changing wait states
    //
    Flash0CtrlRegs.FRD_INTF_CTRL.bit.DATA_CACHE_EN = 0;
    Flash0CtrlRegs.FRD_INTF_CTRL.bit.PREFETCH_EN = 0;
	Flash1CtrlRegs.FRD_INTF_CTRL.bit.DATA_CACHE_EN = 0;
    Flash1CtrlRegs.FRD_INTF_CTRL.bit.PREFETCH_EN = 0;

    //
    // Set waitstates according to frequency
    //                CAUTION
    // Minimum waitstates required for the flash operating
    // at a given CPU rate must be characterized by TI.
    // Refer to the datasheet for the latest information.
    //
#if CPU_FRQ_160MHZ
	Flash0CtrlRegs.FRDCNTL.bit.RWAIT = 0x5;
	Flash1CtrlRegs.FRDCNTL.bit.RWAIT = 0x5;
#endif

    //
    // At reset, ECC is enabled. If it is disabled by application software
    // and if application again wants to enable ECC
    //
    Flash0EccRegs.ECC_ENABLE.bit.ENABLE = 0xA;
	Flash1EccRegs.ECC_ENABLE.bit.ENABLE = 0xA;

    EDIS;
}

//
// FlashOff - This function powers down the flash
//                   CAUTION
// This function MUST be executed out of RAM. Executing it
// out of OTP/Flash will yield unpredictable results.
// Note: a flash access after the flash pump and banks are powered down will
// wake the pump and bank
//
void CODE_SECTION("ramfuncs") FlashOff(void)
{
    EALLOW;

    //
    // Configure the fallback power mode as sleep
    //
    Flash0CtrlRegs.FBFALLBACK.bit.BNKPWR0 = 0;
	Flash1CtrlRegs.FBFALLBACK.bit.BNKPWR0 = 0;

    EDIS;
}

//
// ServiceDog - This function resets the watchdog timer.
// Enable this function for using ServiceDog in the application
//
void
ServiceDog(void)
{
    EALLOW;
    WdRegs.WDKEY.bit.WDKEY = 0x0055;
    WdRegs.WDKEY.bit.WDKEY = 0x00AA;
    EDIS;
}

//
// DisableDog - This function disables the watchdog timer.
//
void
DisableDog(void)
{
    volatile Uint16 temp;
    EALLOW;

    //
    // Grab the clock config so we don't clobber it
    //
    EALLOW;
    temp = (WdRegs.WDCR.all & ~(1 << 7)) & 0x0007;
    WdRegs.WDCR.all = 0x0068 | temp;
    EDIS;
}

//
// EnableDog - This function enables the watchdog timer.
//
void EnableDog(void)
{
    volatile Uint16 temp;

    //
    // Grab the clock config first so we don't clobber it
    //
    EALLOW;
    temp = (WdRegs.WDCR.all & ~(1 << 7)) & 0x0007;
    WdRegs.WDCR.all = 0x0028 | temp;
    EDIS;
}

//
// InitPll - This function initializes the PLL registers.
//
// Note: This function uses the DCC to check that the PLLRAWCLK is running at
// the expected rate. If you are using the DCC, you must back up its
// configuration before calling this function and restore it afterward.
//
void
InitSysPll(Uint16 clock_source, Uint16 imult, Uint32 refdiv, Uint32 odiv,
        Uint16 divsel)
{
	Uint32 timeout,temp_syspllmult, pllLockStatus;
	bool status;
	Uint32 pllRawClkMhz;
	Uint8 vco;

	if(((clock_source & 0x3) == ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL)    &&
	   (((clock_source & 0x4) >> 2) == ClkCfgRegs.XTALCR.bit.SE)           &&
	   (imult  == ClkCfgRegs.SYSPLLMULT.bit.IMULT)           &&
	   (refdiv  == ClkCfgRegs.SYSPLLMULT.bit.REFDIV)          &&
	   (odiv == ClkCfgRegs.SYSPLLMULT.bit.ODIV)               &&
	   (divsel == ClkCfgRegs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV)	&&
	   (1 == ClkCfgRegs.SYSPLLCTL1.bit.PLLCLKEN) &&
	   (1U == ClkCfgRegs.SYSPLLCTL1.bit.PLLEN))
	{
		//
		// Everything is set as required, so just return
		//
		return;
	}

	pllRawClkMhz = 10 * imult / refdiv / odiv;

	if(((clock_source & 0x3) != ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL) ||
	  (((clock_source & 0x4) >> 2) != ClkCfgRegs.XTALCR.bit.SE))
	{
		switch (clock_source)
		{
			case INT_OSC1:
				SysIntOsc1Sel();
				break;

			case INT_OSC2:
				SysIntOsc2Sel();
				break;

			case XTAL_OSC:
				SysXtalOscSel();
				pllRawClkMhz *= 2;
				break;

			case XTAL_OSC_SE:
				SysXtalOscSESel();
				break;
		}
	}

	EALLOW;

	//
	// First modify the PLL multipliers if the multipliers need an update or PLL needs
	// to be powered on / enabled
	//
	if((imult != ClkCfgRegs.SYSPLLMULT.bit.IMULT) ||
	   (refdiv != ClkCfgRegs.SYSPLLMULT.bit.REFDIV)||
	   (odiv != ClkCfgRegs.SYSPLLMULT.bit.ODIV) ||
	   (1U != ClkCfgRegs.SYSPLLCTL1.bit.PLLEN) ||
	   (1U != ClkCfgRegs.SYSPLLCTL1.bit.PLLCLKEN))
	{
		//
		// Bypass PLL and set dividers to /1
		//
		ClkCfgRegs.SYSPLLCTL1.bit.PLLCLKEN = 0;
		ClkCfgRegs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = 0;

		//
		// Evaluate PLL multipliers and dividers
		//
		temp_syspllmult = ((refdiv << 24U) | (odiv << 16U) | imult);

		if(pllRawClkMhz >= 410U)
		{
			vco = 7U;
		}
		else if(pllRawClkMhz >= 350U)
		{
			vco = 6U;
		}
		else if(pllRawClkMhz >= 270U)
		{
			vco = 5U;
		}
		else if(pllRawClkMhz >= 230U)
		{
			vco = 4U;
		}
		else if(pllRawClkMhz >= 170U)
		{
			vco = 3U;
		}
		else if(pllRawClkMhz >= 110U)
		{
			vco = 2U;
		}
		else
		{
			vco = 1U;
		}

		temp_syspllmult |= (vco << 8U);

		//
		// Turnoff the PLL
		//
		ClkCfgRegs.SYSPLLCTL1.bit.PLLEN = 0;

		//
		// Set dividers to /1 to ensure the fastest PLL configuration
		//
		ClkCfgRegs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = 0;

		//
		// Program PLL multipliers
		//
		ClkCfgRegs.SYSPLLMULT.all = temp_syspllmult;

		//
		// Enable SYSPLL
		//
		ClkCfgRegs.SYSPLLCTL1.bit.PLLEN = 1;

		//
		// Lock time is 1024 OSCCLK * (REFDIV+1)
		//
		timeout = (1024U * (refdiv + 1U));
		pllLockStatus = ClkCfgRegs.SYSPLLSTS.bit.LOCKS;

		//
		// Wait for the SYSPLL lock
		//
		while((pllLockStatus != 1) && (timeout != 0U))
		{
			pllLockStatus = ClkCfgRegs.SYSPLLSTS.bit.LOCKS;
			timeout--;
		}

		EDIS;

		//
		// Check PLL Frequency using DCC
		//
		status = IsPLLValid(clock_source, imult, odiv , refdiv);
	}
	else
	{
		//
		// Re-Lock of PLL not needed since the multipliers
		// are not updated
		//
		status = true;
	}

	if(status)
	{
		EALLOW;
		//
		// Set divider to produce slower output frequency to limit current increase
		//
		if(divsel != PLLCLK_BY_126)
		{
			ClkCfgRegs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = divsel + 1;
		}
		else
		{
			ClkCfgRegs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = divsel;
		}

		//
		// Enable PLLSYSCLK is fed from system PLL clock
		//
		ClkCfgRegs.SYSPLLCTL1.bit.PLLCLKEN = 1;

		//
		// Set the divider to user value
		//
		ClkCfgRegs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = divsel;
		EDIS;
	}
	else
	{
		asm("ebreak"); // If the frequency is out of range, stop here.
	}
}

//
// CsmUnlock - This function unlocks the CSM. User must replace 0xFFFF's with
// current password for the DSP.
//
Uint16
CsmUnlock()
{
    //
    // Write to the key registers to unlock the device. The 0x0FFFFFFFF's
    // are dummmy passwords. User should replace them with the correct password
    // for the DSP.
    // Note: F28004x has default password keys which are not all 0xFFFFFFFF.
    // See DCSM chapter of Technical Reference Manual for default passwords.
    EALLOW;

    DcsmBank0Z1Regs.Z1_CSMKEY0 = 0xFFFFFFFF;
    DcsmBank0Z1Regs.Z1_CSMKEY1 = 0xFFFFFFFF;
    DcsmBank0Z1Regs.Z1_CSMKEY2 = 0xFFFFFFFF;
    DcsmBank0Z1Regs.Z1_CSMKEY3 = 0xFFFFFFFF;

    DcsmBank0Z2Regs.Z2_CSMKEY0 = 0xFFFFFFFF;
    DcsmBank0Z2Regs.Z2_CSMKEY1 = 0xFFFFFFFF;
    DcsmBank0Z2Regs.Z2_CSMKEY2 = 0xFFFFFFFF;
    DcsmBank0Z2Regs.Z2_CSMKEY3 = 0xFFFFFFFF;
    EDIS;

    return 0;
}

//
// SysIntOsc1Sel - This function switches to Internal Oscillator 1 and turns
// off all other clock sources to minimize power consumption
//
void
SysIntOsc1Sel (void)
{
    EALLOW;
    ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 2; // Clk Src = INTOSC1
    ClkCfgRegs.XTALCR.bit.OSCOFF=1;             // Turn off XTALOSC
    EDIS;
}

//
// SysIntOsc2Sel - This function switches to Internal oscillator 2 from
// External Oscillator and turns off all other clock sources to minimize
// power consumption
// NOTE: If there is no external clock connection, when switching from
//       INTOSC1 to INTOSC2, EXTOSC and XLCKIN must be turned OFF prior
//       to switching to internal oscillator 1
//
void
SysIntOsc2Sel (void)
{
    EALLOW;
    ClkCfgRegs.CLKSRCCTL1.bit.INTOSC2OFF=0;         // Turn on INTOSC2
    ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 0;     // Clk Src = INTOSC2
    ClkCfgRegs.XTALCR.bit.OSCOFF=1;                 // Turn off XTALOSC
    EDIS;
}

//
// PollX1Counter - Clear the X1CNT counter and then wait for it to saturate
// four times.
//
static void
PollX1Counter(void)
{
    Uint16 loopCount = 0;

    //
    // Delay for 1 ms while the XTAL powers up
    //
    // 2000 loops, 5 cycles per loop + 9 cycles overhead = 10009 cycles
    //
    F28x_usDelay(2000);

    //
    // Clear and saturate X1CNT 4 times to guarantee operation
    //
    do
    {
        //
        // Keep clearing the counter until it is no longer saturated
        //
        while(ClkCfgRegs.X1CNT.all > 0x1FF)
        {
            ClkCfgRegs.X1CNT.bit.CLR = 1;
        }

        //
        // Wait for the X1 clock to saturate
        //
        while(ClkCfgRegs.X1CNT.all != 0x3FFU)
        {
            ;
        }

        //
        // Increment the counter
        //
        loopCount++;
    }while(loopCount < 4);
}

//
// SysXtalOscSel - This function switches to External CRYSTAL oscillator and
// turns off all other clock sources to minimize power consumption. This option
// may not be available on all device packages
//
void
SysXtalOscSel (void)
{
    EALLOW;
    ClkCfgRegs.XTALCR.bit.OSCOFF = 0;     // Turn on XTALOSC
    ClkCfgRegs.XTALCR.bit.SE = 0;         // Select crystal mode
    EDIS;

    //
    // Wait for the X1 clock to saturate
    //
    PollX1Counter();

    //
    // Select XTAL as the oscillator source
    //
    EALLOW;
    ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 1;
    EDIS;

    //
    // If a missing clock failure was detected, try waiting for the X1 counter
    // to saturate again. Consider modifying this code to add a 10ms timeout.
    //
    while(ClkCfgRegs.MCDCR.bit.MCLKSTS != 0)
    {
        EALLOW;
        ClkCfgRegs.MCDCR.bit.MCLKCLR = 1;
        EDIS;

        //
        // Wait for the X1 clock to saturate
        //
        PollX1Counter();

        //
        // Select XTAL as the oscillator source
        //
        EALLOW;
        ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 1;
        EDIS;
    }
}

//
// SysXtalOscSESel - This function switches to external oscillator in
// single-ended mode and turns off all other clock sources to minimize power
// consumption. This option may not be available on all device packages
//
void
SysXtalOscSESel (void)
{
    EALLOW;
    ClkCfgRegs.XTALCR.bit.OSCOFF = 0;     // Turn on XTALOSC
    ClkCfgRegs.XTALCR.bit.SE = 1;         // Select single-ended mode
    EDIS;

    //
    // Wait for the X1 clock to saturate
    //
    PollX1Counter();

    //
    // Select XTALOSC as the oscillator source
    //
    EALLOW;
    ClkCfgRegs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 1;
    EDIS;

    //
    // If missing clock detected, there is something wrong with the oscillator
    // module.
    //
    if(ClkCfgRegs.MCDCR.bit.MCLKSTS != 0)
    {
        ESTOP0;
    }
}

//
// IDLE - Enter IDLE mode
//
void
IDLE()
{
    EALLOW;
    CpuSysRegs.LPMCR.bit.LPM = LPM_IDLE;
    EDIS;
    NOP;
}

//
// HALT - Enter HALT mode
//
void
HALT()
{
    EALLOW;
    CpuSysRegs.LPMCR.bit.LPM = LPM_HALT;
    ClkCfgRegs.SYSPLLCTL1.bit.PLLCLKEN = 0;
    ClkCfgRegs.SYSPLLCTL1.bit.PLLEN = 0;
    EDIS;
    asm(" wfi");
}

//*****************************************************************************
//
// SysCtl_isPLLValid()
//
//*****************************************************************************
bool
IsPLLValid(Uint16 oscSource, Uint16 imult,
        Uint16 odiv, Uint16 refdiv)
{
	float fclk1_0ratio;

	EALLOW;

	//
	// Assigning DCC for PLL validation
	// Enable Peripheral Clock Domain PCLKCR21 for DCC
	//
	CpuSysRegs.PCLKCR21.bit.DCC_0 = 1;

	//
	// Clear Error & Done Flag
	//
	Dcc0Regs.DCCSTATUS.bit.ERR = 1;
	Dcc0Regs.DCCSTATUS.bit.DONE = 1;

	//
	// Disable DCC
	//
	Dcc0Regs.DCCGCTRL.bit.DCCENA = 0x5;

	//
	// Disable Error Signal
	//
	Dcc0Regs.DCCGCTRL.bit.ERRENA = 0x5;

	//
	// Disable Done Signal
	//
	Dcc0Regs.DCCGCTRL.bit.DONEENA = 0x5;

	//
	// Configure Clock Source1 to PLL
	//
	// Clk Src1 Key 0xA to enable clock source selection
	//
	Dcc0Regs.DCCCLKSRC1.all = 0xA000; // Clk Src1 = SYSPLL

	//
	// Configure Clock Source0 to whatever is set as a reference
	// clock source for PLL
	//
	// Clk Src0 Key 0xA to enable clock source selection
	//
	switch(oscSource)
	{
		case INT_OSC1:
			Dcc0Regs.DCCCLKSRC0.all = 0xA001; // Clk Src0 = INTOSC1
			break;

		case INT_OSC2:
			Dcc0Regs.DCCCLKSRC0.all = 0xA002; // Clk Src0 = INTOSC2
			break;

		case XTAL_OSC:
		case XTAL_OSC_SE:
			Dcc0Regs.DCCCLKSRC0.all = 0xA000; // Clk Src0 = XTAL
			break;

		default:
			//
			// Code shouldn't reach here
			//
			break;
	}

	//
	// Calculating frequency ratio of output clock(f1) vs reference clock(f0)
	//
	fclk1_0ratio = (float)imult / (odiv * refdiv);

	//
	// Computing and configuring Counter0 , Counter1 & Valid Seed Values
	// with +/-1% tolerance for the desired DCC
	//
	ComputeCntrSeedValue(oscSource, fclk1_0ratio, 1);

	//
	// Enable Single Shot Mode
	//
	Dcc0Regs.DCCGCTRL.bit.SINGLESHOT = 0xA;

	//
	// Enable DCC to start counting
	//
	Dcc0Regs.DCCGCTRL.bit.DCCENA = 0xA;
	EDIS;

	//
	// Wait until Error or Done Flag is generated
	//
	while((Dcc0Regs.DCCSTATUS.all & 3) == 0)
	{
	}

	//
	// Returns true if DCC completes without error
	//
	return((Dcc0Regs.DCCSTATUS.all & 3) == 2);
}

//*****************************************************************************
//
// ComputeCntSeedValid - Compute Counter seed values based on the frequency ratio of output
// clock vs reference clock & tolerance expected for the desired DCC
//
//*****************************************************************************
void ComputeCntrSeedValue(Uint16 oscSource, float fclk1_0ratio, Uint32 tolerance)
{
    Uint32  count0, count1, valid ;
    float PLLSYS_Freq,DCCSRC0_Freq;
    float count1_div,valid_div;

    switch(oscSource)
    {
        case INT_OSC1:
        	DCCSRC0_Freq = 10.0F;
        	PLLSYS_Freq = fclk1_0ratio *10.0F;
            break;

        case INT_OSC2:
        	DCCSRC0_Freq = 10.0F;
        	PLLSYS_Freq = fclk1_0ratio *10.0F;
            break;

        case XTAL_OSC:
        case XTAL_OSC_SE:
        	DCCSRC0_Freq = 20.0F;
        	PLLSYS_Freq = fclk1_0ratio *20.0F;
            break;

        default:
        	DCCSRC0_Freq = 0.0F;
        	PLLSYS_Freq = 0.0F;
            //
            // Code shouldn't reach here
            //
            break;
    }


    count0 = 5000;

    count1_div = (float)(((count0+2)*(1000/DCCSRC0_Freq)*(100+tolerance)/100 + 2*(1000/PLLSYS_Freq)*1.03 - 2*(1000/PLLSYS_Freq)*(100 - 10)/100)/((1000/PLLSYS_Freq)*(100 - 10)/100));
    count1_div = (float)(count1_div/10);
    count1 = (uint32_t)((count1_div+1)*10);



    valid_div =(float)(((count1 + 2)*(1000/PLLSYS_Freq)*(100+10)/100 +  2*(1000/PLLSYS_Freq)*1.03 - (2 + 5000)*(1000/DCCSRC0_Freq)*(100-tolerance)/100)/((1000/DCCSRC0_Freq)*(100-tolerance)/100));
    valid_div = (float)valid_div/10;
    valid = (uint32_t)((valid_div+1)*10);

    //
    // Configure COUNTER-0, COUNTER-1 & Valid Window
    //
    Dcc0Regs.DCCCNTSEED0.bit.COUNTSEED0 = count0; // Loaded Counter0 Value
    Dcc0Regs.DCCVALIDSEED0.bit.VALIDSEED = valid;  // Loaded Valid Value
    Dcc0Regs.DCCCNTSEED1.bit.COUNTSEED1 = count1; // Loaded Counter1 Value
}
//
// End of File
//

