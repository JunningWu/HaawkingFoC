
#include "F28x_project.h"
#include <syscalls.h>

extern void Scia_Send(uint8 data);
extern void Scia_Config(uint32 baud);
extern void InitSciGpio();
