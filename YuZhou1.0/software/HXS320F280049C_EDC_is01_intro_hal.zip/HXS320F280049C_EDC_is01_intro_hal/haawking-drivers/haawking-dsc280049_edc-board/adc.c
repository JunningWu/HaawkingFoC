//###########################################################################
//
// FILE:   adc.c
//
// TITLE:  H28x ADC driver.
//
//###########################################################################
// $HAAWKING Release: Hal Driver Support Library V1.0.0 $
// $Release Date: 2023-04-28 06:49:27 $
// $Copyright:
// Copyright (C) 2019-2023 Beijing Haawking Technology Co.,Ltd - http://www.haawking.com/
//###########################################################################

#include "adc.h"

//*****************************************************************************
//
// Defines for locations of ADC calibration functions in OTP for use in
// ADC_setVREF(), ADC_setOffsetTrimAll() and ADC_setOffsetTrim(). Not intended
// for use by application code.
//
//*****************************************************************************
#define ADC_OFFSET_TRIM_OTP    0x640868U                       //


#define ADC_VOLTAGE_REF_REG_OFFSET              8U            //

//*****************************************************************************
//
// ADC_setVREF
//
//*****************************************************************************
void
ADC_setVREF(uint32_t base, ADC_ReferenceMode refMode,
            ADC_ReferenceVoltage refVoltage)
{
    //
    // Check the arguments.
    //
    ASSERT(ADC_isBaseValid(base));
    ASSERT(((refMode == ADC_REFERENCE_INTERNAL) && (refVoltage == ADC_REFERENCE_2_5V))
    	 ||((refMode == ADC_REFERENCE_EXTERNAL)));

	base += base;

    //
    // All ADCs must be configured to use the same reference source
    //

    EALLOW;

    //
    // Configure the reference mode (internal or external).
    //
    if(refMode == ADC_REFERENCE_INTERNAL)
    {
        //
        // Configure the reference voltage (3.3V or 2.5V).
        //
    	if(refVoltage == ADC_REFERENCE_2_5V)
    	{
    		HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_PMULDOCTL) &= ~(ASYSCTL_PMULDOCTL_PMUVREFHIA2P5 \
    		    										| ASYSCTL_PMULDOCTL_PMUVREFHIB2P5 \
    													| ASYSCTL_PMULDOCTL_PMUVREFHIA1P65 \
    													| ASYSCTL_PMULDOCTL_PMUVREFHIB1P65);
    		HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) = (HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) \
    												& ~ASYSCTL_ANAREFCTL_ANAREFAVDDSEL) | ASYSCTL_ANAREFCTL_ANAVREFHIAEN;
    		HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) = (HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) \
    		    									& ~ASYSCTL_ANAREFCTL_ANAREFBVDDSEL) | ASYSCTL_ANAREFCTL_ANAVREFHIBEN;
    		HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) &= ~ASYSCTL_ANAREFCTL_ANAREFCVDDSEL;
    	}
    	else
    	{
    		//
    		// Not allowed to be choosen
    		//
    		ESTOP0;
    	}
    }
    else
    {
    	//
		// External reference 2.5V and 3.3V use the same configuration
		//
    	HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_PMULDOCTL) &= ~(ASYSCTL_PMULDOCTL_PMUVREFHIA2P5 \
    												| ASYSCTL_PMULDOCTL_PMUVREFHIB2P5 \
    												| ASYSCTL_PMULDOCTL_PMUVREFHIA1P65 \
    												| ASYSCTL_PMULDOCTL_PMUVREFHIB1P65);
    	HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) &= ~(ASYSCTL_ANAREFCTL_ANAREFAVDDSEL \
    												| ASYSCTL_ANAREFCTL_ANAVREFHIAEN);
    	HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) &= ~(ASYSCTL_ANAREFCTL_ANAREFBVDDSEL \
    	    										| ASYSCTL_ANAREFCTL_ANAVREFHIBEN);
    	HWREG(ANALOGSUBSYS_BASE + ASYSCTL_O_ANAREFCTL) &= ~ASYSCTL_ANAREFCTL_ANAREFCVDDSEL;
    }

    EDIS;
}


//*****************************************************************************
//
// ADC_setOffsetTrim
//
//*****************************************************************************
void
ADC_setOffsetTrim(uint32_t base)
{
    //
    // Check the arguments.
    //
    ASSERT(ADC_isBaseValid(base));
}

//*****************************************************************************
//
// ADC_setOffsetTrimAll
//
//*****************************************************************************
void
ADC_setOffsetTrimAll(ADC_ReferenceMode refMode, ADC_ReferenceVoltage refVoltage)
{
    refMode += refMode;
	refVoltage += refVoltage;
}

//*****************************************************************************
//
// ADC_setPPBTripLimits
//
//*****************************************************************************
void
ADC_setPPBTripLimits(uint32_t base, ADC_PPBNumber ppbNumber,
                     int32_t tripHiLimit, int32_t tripLoLimit)
{
    uint32_t ppbHiOffset;
    uint32_t ppbLoOffset;

    //
    // Check the arguments.
    //
    ASSERT(ADC_isBaseValid(base));
    ASSERT((tripHiLimit <= 65535) && (tripHiLimit >= -65536));
    ASSERT((tripLoLimit <= 65535) && (tripLoLimit >= -65536));

    //
    // Get the offset to the appropriate trip limit registers.
    //
    ppbHiOffset = (ADC_PPBxTRIPHI_STEP * (uint32_t)ppbNumber) +
                  ADC_O_PPB1TRIPHI;
    ppbLoOffset = (ADC_PPBxTRIPLO_STEP * (uint32_t)ppbNumber) +
                  ADC_O_PPB1TRIPLO;

    EALLOW;

    //
    // Set the trip high limit.
    //
    HWREG(base + ppbHiOffset) =
        (HWREG(base + ppbHiOffset) & ~ADC_PPBTRIP_MASK) |
        ((uint32_t)tripHiLimit & ADC_PPBTRIP_MASK);

    //
    // Set the trip low limit.
    //
    HWREG(base + ppbLoOffset) =
        (HWREG(base + ppbLoOffset) & ~ADC_PPBTRIP_MASK) |
        ((uint32_t)tripLoLimit & ADC_PPBTRIP_MASK);

    EDIS;
}
