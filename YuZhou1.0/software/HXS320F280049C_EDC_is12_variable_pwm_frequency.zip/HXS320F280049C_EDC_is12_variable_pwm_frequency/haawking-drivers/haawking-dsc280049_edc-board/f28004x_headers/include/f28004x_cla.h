//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:01:13.466078
//
//#############################################################################


#ifndef F28004X_CLA_H
#define F28004X_CLA_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// CLA Individual Register Bit Definitions:

struct MCTL_BITS {                            // bits description
    Uint32 HARDRESET:1;                       // 0 Hard Reset
    Uint32 SOFTRESET:1;                       // 1 Soft Reset
    Uint32 IACKE:1;                           // 2 IACK enable
    Uint32 rsvd1:29;                          // 31:3 Reserved
};

union MCTL_REG {
    Uint32  all;
    struct  MCTL_BITS  bit;
};

struct SOFTINTEN_BITS {                       // bits description
    Uint32 TASK1:1;                           // 0 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK2:1;                           // 1 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK3:1;                           // 2 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK4:1;                           // 3 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK5:1;                           // 4 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK6:1;                           // 5 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK7:1;                           // 6 Configure Software Interrupt or End of Task interrupt.
    Uint32 TASK8:1;                           // 7 Configure Software Interrupt or End of Task interrupt.
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union SOFTINTEN_REG {
    Uint32  all;
    struct  SOFTINTEN_BITS  bit;
};

struct _MSTSBGRND_BITS {                      // bits description
    Uint32 RUN:1;                             // 0 Background task run status bit.
    Uint32 _BGINTM:1;                         // 1 Indicates whether background task can be interrupted.
    Uint32 BGOVF:1;                           // 2 background task harware trigger overflow.
    Uint32 rsvd1:29;                          // 31:3 Reserved
};

union _MSTSBGRND_REG {
    Uint32  all;
    struct  _MSTSBGRND_BITS  bit;
};

struct _MCTLBGRND_BITS {                      // bits description
    Uint32 BGSTART:1;                         // 0 Background task start bit
    Uint32 TRIGEN:1;                          // 1 Background task hardware trigger enable
    Uint32 rsvd1:13;                          // 14:2 Reserved
    Uint32 BGEN:1;                            // 15 Enable background task
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union _MCTLBGRND_REG {
    Uint32  all;
    struct  _MCTLBGRND_BITS  bit;
};

struct MIFR_BITS {                            // bits description
    Uint32 INT1:1;                            // 0 Task 1 Interrupt Flag
    Uint32 INT2:1;                            // 1 Task 2 Interrupt Flag
    Uint32 INT3:1;                            // 2 Task 3 Interrupt Flag
    Uint32 INT4:1;                            // 3 Task 4 Interrupt Flag
    Uint32 INT5:1;                            // 4 Task 5 Interrupt Flag
    Uint32 INT6:1;                            // 5 Task 6 Interrupt Flag
    Uint32 INT7:1;                            // 6 Task 7 Interrupt Flag
    Uint32 INT8:1;                            // 7 Task 8 Interrupt Flag
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MIFR_REG {
    Uint32  all;
    struct  MIFR_BITS  bit;
};

struct MIOVF_BITS {                           // bits description
    Uint32 INT1:1;                            // 0 Task 1 Interrupt Overflow Flag
    Uint32 INT2:1;                            // 1 Task 2 Interrupt Overflow Flag
    Uint32 INT3:1;                            // 2 Task 3 Interrupt Overflow Flag
    Uint32 INT4:1;                            // 3 Task 4 Interrupt Overflow Flag
    Uint32 INT5:1;                            // 4 Task 5 Interrupt Overflow Flag
    Uint32 INT6:1;                            // 5 Task 6 Interrupt Overflow Flag
    Uint32 INT7:1;                            // 6 Task 7 Interrupt Overflow Flag
    Uint32 INT8:1;                            // 7 Task 8 Interrupt Overflow Flag
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MIOVF_REG {
    Uint32  all;
    struct  MIOVF_BITS  bit;
};

struct MIFRC_BITS {                           // bits description
    Uint32 INT1:1;                            // 0 Task 1 Interrupt Force
    Uint32 INT2:1;                            // 1 Task 2 Interrupt Force
    Uint32 INT3:1;                            // 2 Task 3 Interrupt Force
    Uint32 INT4:1;                            // 3 Task 4 Interrupt Force
    Uint32 INT5:1;                            // 4 Task 5 Interrupt Force
    Uint32 INT6:1;                            // 5 Task 6 Interrupt Force
    Uint32 INT7:1;                            // 6 Task 7 Interrupt Force
    Uint32 INT8:1;                            // 7 Task 8 Interrupt Force
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MIFRC_REG {
    Uint32  all;
    struct  MIFRC_BITS  bit;
};

struct MICLR_BITS {                           // bits description
    Uint32 INT1:1;                            // 0 Task 1 Interrupt Flag Clear
    Uint32 INT2:1;                            // 1 Task 2 Interrupt Flag Clear
    Uint32 INT3:1;                            // 2 Task 3 Interrupt Flag Clear
    Uint32 INT4:1;                            // 3 Task 4 Interrupt Flag Clear
    Uint32 INT5:1;                            // 4 Task 5 Interrupt Flag Clear
    Uint32 INT6:1;                            // 5 Task 6 Interrupt Flag Clear
    Uint32 INT7:1;                            // 6 Task 7 Interrupt Flag Clear
    Uint32 INT8:1;                            // 7 Task 8 Interrupt Flag Clear
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MICLR_REG {
    Uint32  all;
    struct  MICLR_BITS  bit;
};

struct MICLROVF_BITS {                        // bits description
    Uint32 INT1:1;                            // 0 Task 1 Interrupt Overflow Flag Clear
    Uint32 INT2:1;                            // 1 Task 2 Interrupt Overflow Flag Clear
    Uint32 INT3:1;                            // 2 Task 3 Interrupt Overflow Flag Clear
    Uint32 INT4:1;                            // 3 Task 4 Interrupt Overflow Flag Clear
    Uint32 INT5:1;                            // 4 Task 5 Interrupt Overflow Flag Clear
    Uint32 INT6:1;                            // 5 Task 6 Interrupt Overflow Flag Clear
    Uint32 INT7:1;                            // 6 Task 7 Interrupt Overflow Flag Clear
    Uint32 INT8:1;                            // 7 Task 8 Interrupt Overflow Flag Clear
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MICLROVF_REG {
    Uint32  all;
    struct  MICLROVF_BITS  bit;
};

struct MIER_BITS {                            // bits description
    Uint32 INT1:1;                            // 0 Task 1 Interrupt Enable
    Uint32 INT2:1;                            // 1 Task 2 Interrupt Enable
    Uint32 INT3:1;                            // 2 Task 3 Interrupt Enable
    Uint32 INT4:1;                            // 3 Task 4 Interrupt Enable
    Uint32 INT5:1;                            // 4 Task 5 Interrupt Enable
    Uint32 INT6:1;                            // 5 Task 6 Interrupt Enable
    Uint32 INT7:1;                            // 6 Task 7 Interrupt Enable
    Uint32 INT8:1;                            // 7 Task 8 Interrupt Enable
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MIER_REG {
    Uint32  all;
    struct  MIER_BITS  bit;
};

struct MIRUN_BITS {                           // bits description
    Uint32 INT1:1;                            // 0 Task 1 Run Status
    Uint32 INT2:1;                            // 1 Task 2 Run Status
    Uint32 INT3:1;                            // 2 Task 3 Run Status
    Uint32 INT4:1;                            // 3 Task 4 Run Status
    Uint32 INT5:1;                            // 4 Task 5 Run Status
    Uint32 INT6:1;                            // 5 Task 6 Run Status
    Uint32 INT7:1;                            // 6 Task 7 Run Status
    Uint32 INT8:1;                            // 7 Task 8 Run Status
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union MIRUN_REG {
    Uint32  all;
    struct  MIRUN_BITS  bit;
};

struct _MSTF_BITS {                           // bits description
    Uint32 LVF:1;                             // 0 Latched Overflow Flag
    Uint32 LUF:1;                             // 1 Latched Underflow Flag
    Uint32 NF:1;                              // 2 Negative Float Flag
    Uint32 ZF:1;                              // 3 Zero Float Flag
    Uint32 rsvd1:2;                           // 5:4 Reserved
    Uint32 TF:1;                              // 6 Test Flag
    Uint32 rsvd2:2;                           // 8:7 Reserved
    Uint32 RNDF32:1;                          // 9 Round 32-bit Floating-Point Mode
    Uint32 rsvd3:1;                           // 10 Reserved
    Uint32 MEALLOW:1;                         // 11 MEALLOW Status
    Uint32 rsvd4:20;                          // 31:12 Reserved
};

union _MSTF_REG {
    Uint32  all;
    struct  _MSTF_BITS  bit;
};

struct _MPSACTL_BITS {                        // bits description
    Uint32 MPABSTART:1;                       // 0 Start logging PAB onto PSA1
    Uint32 MPABCYC:1;                         // 1 PAB logging into PSA1 is on every cycle or when PAB changes.
    Uint32 MDWDBSTART:1;                      // 2 Start logging DWDB onto PSA2
    Uint32 MDWDBCYC:1;                        // 3 DWDB logging into PSA2 is on every cycle.
    Uint32 MPSA1CLEAR:1;                      // 4 PSA1 clear
    Uint32 MPSA2CLEAR:1;                      // 5 PSA2 Clear
    Uint32 MPSA2CFG:2;                        // 7:6 PSA2 Polynomial Configuration
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union _MPSACTL_REG {
    Uint32  all;
    struct  _MPSACTL_BITS  bit;
};

struct  CLA_REGS {
    Uint32                                   MVECT1;                      // 0x0 Task Interrupt Vector
    Uint32                                   MVECT2;                      // 0x4 Task Interrupt Vector
    Uint32                                   MVECT3;                      // 0x8 Task Interrupt Vector
    Uint32                                   MVECT4;                      // 0xc Task Interrupt Vector
    Uint32                                   MVECT5;                      // 0x10 Task Interrupt Vector
    Uint32                                   MVECT6;                      // 0x14 Task Interrupt Vector
    Uint32                                   MVECT7;                      // 0x18 Task Interrupt Vector
    Uint32                                   MVECT8;                      // 0x1c Task Interrupt Vector
    union   MCTL_REG                         MCTL;                        // 0x20 Control Register
    Uint32                                   _MVECTBGRNDACTIVE;           // 0x24 Active register for MVECTBGRND.
    union   SOFTINTEN_REG                    SOFTINTEN;                   // 0x28 CLA Software Interrupt Enable Register
    union   _MSTSBGRND_REG                   _MSTSBGRND;                  // 0x2c Status register for the back ground task.
    union   _MCTLBGRND_REG                   _MCTLBGRND;                  // 0x30 Control register for the back ground task.
    Uint32                                   _MVECTBGRND;                 // 0x34 Vector for the back ground task.
    union   MIFR_REG                         MIFR;                        // 0x38 Interrupt Flag Register
    union   MIOVF_REG                        MIOVF;                       // 0x3c Interrupt Overflow Flag Register
    union   MIFRC_REG                        MIFRC;                       // 0x40 Interrupt Force Register
    union   MICLR_REG                        MICLR;                       // 0x44 Interrupt Flag Clear Register
    union   MICLROVF_REG                     MICLROVF;                    // 0x48 Interrupt Overflow Flag Clear Register
    union   MIER_REG                         MIER;                        // 0x4c Interrupt Enable Register
    union   MIRUN_REG                        MIRUN;                       // 0x50 Interrupt Run Status Register
    Uint32                                   _MPC;                        // 0x54 CLA Program Counter
    union   _MSTF_REG                        _MSTF;                       // 0x58 CLA Floating-Point Status Register
    union   _MPSACTL_REG                     _MPSACTL;                    // 0x5c CLA PSA Control Register
    Uint32                                   _MPSA1;                      // 0x60 CLA PSA1 Register
    Uint32                                   _MPSA2;                      // 0x64 CLA PSA2 Register
    Uint32                                   rsvd1[7];                    // 0x68 Reserved
    Uint32                                   RPC;                         // 0x84 CLA Return Program Counter Register
};

struct SOFTINTFRC_BITS {                      // bits description
    Uint32 TASK1:1;                           // 0 Force CLA software interrupt for the corresponding task.
    Uint32 TASK2:1;                           // 1 Force CLA software interrupt for the corresponding task.
    Uint32 TASK3:1;                           // 2 Force CLA software interrupt for the corresponding task.
    Uint32 TASK4:1;                           // 3 Force CLA software interrupt for the corresponding task.
    Uint32 TASK5:1;                           // 4 Force CLA software interrupt for the corresponding task.
    Uint32 TASK6:1;                           // 5 Force CLA software interrupt for the corresponding task.
    Uint32 TASK7:1;                           // 6 Force CLA software interrupt for the corresponding task.
    Uint32 TASK8:1;                           // 7 Force CLA software interrupt for the corresponding task.
    Uint32 rsvd1:24;                          // 31:8 Reserved
};

union SOFTINTFRC_REG {
    Uint32  all;
    struct  SOFTINTFRC_BITS  bit;
};

struct  CLA_ONLY_REGS {
    Uint32                                   _MVECTBGRNDACTIVE;           // 0x0 Active register for MVECTBGRND.
    union   _MPSACTL_REG                     _MPSACTL;                    // 0x4 CLA PSA Control Register
    Uint32                                   _MPSA1;                      // 0x8 CLA PSA1 Register
    Uint32                                   _MPSA2;                      // 0xc CLA PSA2 Register
    union   SOFTINTEN_REG                    SOFTINTEN;                   // 0x10 CLA Software Interrupt Enable Register
    union   SOFTINTFRC_REG                   SOFTINTFRC;                  // 0x14 CLA Software Interrupt Force Register
};

struct  CLA_SOFTINT_REGS {
    union   SOFTINTEN_REG                    SOFTINTEN;                   // 0x0 CLA Software Interrupt Enable Register
    union   SOFTINTFRC_REG                   SOFTINTFRC;                  // 0x4 CLA Software Interrupt Force Register
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
