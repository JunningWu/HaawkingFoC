//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:13:46.049288
//
//#############################################################################


#ifndef F28004X_PGA_H
#define F28004X_PGA_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// PGA Individual Register Bit Definitions:

struct PGACTL_BITS {                          // bits description
    Uint32 PGAEN:1;                           // 0 PGA Enable
    Uint32 rsvd1:4;                           // 4:1 Reserved
    Uint32 GAIN:3;                            // 7:5 PGA gain setting
    Uint32 rsvd2:8;                           // 15:8 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union PGACTL_REG {
    Uint32  all;
    struct  PGACTL_BITS  bit;
};

struct PGALOCK_BITS {                         // bits description
    Uint32 PGACTL:1;                          // 0 Lock bit for PGACTL.
    Uint32 rsvd1:1;                           // 1 Reserved
    Uint32 PGAFILTER:1;                       // 2  
    Uint32 PGAPM:1;                           // 3  
    Uint32 rsvd2:1;                           // 4 Reserved
    Uint32 rsvd3:1;                           // 5 Reserved
    Uint32 rsvd4:1;                           // 6 Reserved
    Uint32 rsvd5:1;                           // 7 Reserved
    Uint32 rsvd6:24;                          // 31:8 Reserved
};

union PGALOCK_REG {
    Uint32  all;
    struct  PGALOCK_BITS  bit;
};

struct PGAPM_BITS {                           // bits description
    Uint32 PM:3;                              // 2:0 Power Manage Control Signal
    Uint32 rsvd1:13;                          // 15:3 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGAPM_REG {
    Uint32  all;
    struct  PGAPM_BITS  bit;
};

struct PGAFILTER_BITS {                       // bits description
    Uint32 FILTEREN:1;                        // 0 Filter Enable
    Uint32 FILTERSEL:4;                       // 4:1 Filter Select
    Uint32 rsvd1:11;                          // 15:5 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union PGAFILTER_REG {
    Uint32  all;
    struct  PGAFILTER_BITS  bit;
};

struct PGATYPE_BITS {                         // bits description
    Uint32 REV:8;                             // 7:0 PGA Revision Field
    Uint32 TYPE:8;                            // 15:8 PGA Type Field
    Uint32 rsvd1:16;                          // 31:16 Reserved
};

union PGATYPE_REG {
    Uint32  all;
    struct  PGATYPE_BITS  bit;
};

struct  PGA_REGS {
    union   PGACTL_REG                       PGACTL;                      // 0x0 PGA Control Register
    union   PGALOCK_REG                      PGALOCK;                     // 0x4 PGA Lock Register
    union   PGAPM_REG                        PGAPM;                       // 0x8 PGA Power Manage Control Signal Register
    union   PGAFILTER_REG                    PGAFILTER;                   // 0xc PGA filter resistance signal
    union   PGATYPE_REG                      PGATYPE;                     // 0x10 PGA Type Register
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
