//#############################################################################
//
// FILE:   hal_data.h
//
// TITLE:  H28x InstaSPIN hardware abstraction layer (HAL) library
//         
//
#ifndef HAL_DATA_H
#define HAL_DATA_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//*****************************************************************************
//
//! \addtogroup HAL_DATA
//! @{
//
//*****************************************************************************

#include "math_hx.h"

//*****************************************************************************
//
//! \brief Defines the ADC data
//
//*****************************************************************************
typedef struct _HAL_ADCData_t_
{
    MATH_Vec3 I_A;         //!< the current values
    MATH_Vec3 V_V;         //!< the voltage values
    float32_t dcBus_V;       //!< the dcBus value
    float32_t throttle;      //!< the throttle input
} HAL_ADCData_t;


//*****************************************************************************
//
//! \brief Defines the ADC data
//
//*****************************************************************************
typedef struct _HAL_ADCData_SS_t_
{
    MATH_Vec3 I_A;          //!< the current values
    MATH_Vec3 I1_A;         //!< the current values
    MATH_Vec3 I2_A;         //!< the current values
    MATH_Vec3 V_V;          //!< the voltage values
    float32_t dcBus_V;      //!< the dcBus value
    float32_t throttle;     //!< the throttle input
} HAL_ADCData_SS_t;

//*****************************************************************************
//
//! \brief Defines the PWM data
//
//*****************************************************************************
typedef struct _HAL_PWMData_t_
{
    MATH_Vec3 Vabc_pu;     //!< the PWM time-durations for each motor phase
    uint16_t  cmpValue[3];
    uint16_t  deadband[3];
    uint16_t  noiseWindow;
    uint16_t  period;
    uint16_t  socCMP;
    bool      flagEnablePwm;
} HAL_PWMData_t;


//*****************************************************************************
//
//! \brief Defines the DAC data
//
//*****************************************************************************
typedef struct _HAL_BuffDACData_t_
{
    int16_t dacValue[2];
    float32_t *ptrData[2];        //!< Input: First input pointer

    float32_t value[2];           //!< the DAC data
    float32_t offset[2];          //!< the DAC data
    float32_t gain[2];            //!< the DAC data
} HAL_BuffDACData_t;


typedef struct _HAL_PwmDacData_t_
{
    uint16_t periodMax;
    int16_t cmpValue[4];

    float32_t *ptrData[4];        //!< Input: First input pointer

    float32_t offset[4];          //!< the DAC data
    float32_t gain[4];            //!< the DAC data
} HAL_PWMDACData_t;

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif // HAL_DATA_H
