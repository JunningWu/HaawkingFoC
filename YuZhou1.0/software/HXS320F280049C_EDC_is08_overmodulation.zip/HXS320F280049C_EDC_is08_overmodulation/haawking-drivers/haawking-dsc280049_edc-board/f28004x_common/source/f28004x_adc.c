//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################

//
// Included Files
//
#include "f28004x_device.h"      // Header File Include File
#include "f28004x_examples.h"    // Examples Include File

//
// SetVREF - Set Vref mode. Function to select reference mode.
// All ADCs must be configured to use the same reference source.
//
void SetVREF(int module, int mode, int ref)
{
	module += module;

    if(mode == ADC_INTERNAL)
    {
    	EALLOW;

    	if(ref == ADC_VREF2P5)
    	{
    		AnalogSubsysRegs.PMULDOCTL.all = 0;
    		AnalogSubsysRegs.ANAREFCTL.all = 0x3;
    	}
    	else
    	{
    		//
			// Not allowed to be choosen
			//
			ESTOP0;
    	}

		EDIS;
    }
    else
    {
		EALLOW;
		AnalogSubsysRegs.PMULDOCTL.all = 0;
		AnalogSubsysRegs.ANAREFCTL.all = 0;
		EDIS;
    }
}

//
// End of File
//
