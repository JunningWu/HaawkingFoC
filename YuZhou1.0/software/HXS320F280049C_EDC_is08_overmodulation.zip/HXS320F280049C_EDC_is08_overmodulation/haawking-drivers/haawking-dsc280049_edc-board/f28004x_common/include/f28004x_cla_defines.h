//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################
#ifndef F28004X_CLA_DEFINES_H_
#define F28004X_CLA_DEFINES_H_

#ifdef __cplusplus
extern "C" {
#endif

//
// Defines
//

//
// MCTL Register
//
#define CLA_FORCE_RESET           0x1
#define CLA_IACK_ENABLE           0x1
#define CLA_IACK_DISABLE          0x0

//
// MMEMCFG Register
//
#define CLA_CLA_SPACE             0x1
#define CLA_CPU_SPACE             0x0

//
// MIER Interrupt Enable Register
//
#define CLA_INT_ENABLE            0x1
#define CLA_INT_DISABLE           0x0

//
// Peripheral Interrupt Source Select define for DMAnCLASourceSelect Register
//
#define CLA_TRIG_NOPERPH     0
#define CLA_TRIG_ADCAINT1    1
#define CLA_TRIG_ADCAINT2    2
#define CLA_TRIG_ADCAINT3    3
#define CLA_TRIG_ADCAINT4    4
#define CLA_TRIG_ADCAEVT     5
#define CLA_TRIG_ADCBINT1    6
#define CLA_TRIG_ADCBINT2    7
#define CLA_TRIG_ADCBINT3    8
#define CLA_TRIG_ADCBINT4    9
#define CLA_TRIG_ADCBEVT     10
#define CLA_TRIG_ADCCINT1    11
#define CLA_TRIG_ADCCINT2    12
#define CLA_TRIG_ADCCINT3    13
#define CLA_TRIG_ADCCINT4    14
#define CLA_TRIG_ADCCEVT     15

#define CLA_TRIG_XINT1      29
#define CLA_TRIG_XINT2      30
#define CLA_TRIG_XINT3      31
#define CLA_TRIG_XINT4      32
#define CLA_TRIG_XINT5      33

#define CLA_TRIG_EPWM1INT   36
#define CLA_TRIG_EPWM2INT   37
#define CLA_TRIG_EPWM3INT   38
#define CLA_TRIG_EPWM4INT   39
#define CLA_TRIG_EPWM5INT   40
#define CLA_TRIG_EPWM6INT   41
#define CLA_TRIG_EPWM7INT   42
#define CLA_TRIG_EPWM8INT   43

#define CLA_TRIG_TINT0      68
#define CLA_TRIG_TINT1      69
#define CLA_TRIG_TINT2      70

#define CLA_TRIG_ECAP1INT   75
#define CLA_TRIG_ECAP2INT   76
#define CLA_TRIG_ECAP3INT   77
#define CLA_TRIG_ECAP4INT   78
#define CLA_TRIG_ECAP5INT   79
#define CLA_TRIG_ECAP6INT   80
#define CLA_TRIG_ECAP7INT   81

#define CLA_TRIG_EQEP1INT   83
#define CLA_TRIG_EQEP2INT   84

#define CLA_TRIG_ECAP6INT2  92
#define CLA_TRIG_ECAP7INT2  93

#define CLA_TRIG_SD1INT     95
#define CLA_TRIG_SD1DRINT1  96
#define CLA_TRIG_SD1DRINT2  97
#define CLA_TRIG_SD1DRINT3  98
#define CLA_TRIG_SD1DRINT4  99

#define CLA_TRIG_PMBUSAINT  105

#define CLA_TRIG_SPITXINTA  109
#define CLA_TRIG_SPIRXINTA  110
#define CLA_TRIG_SPITXINTB  111
#define CLA_TRIG_SPIRXINTB  112

#define CLA_TRIG_LINA_INT1  117
#define CLA_TRIG_LINA_INT0  118

#define CLA_TRIG_CLA1PROMCRC  121

#define CLA_TRIG_FSITXINT1  123
#define CLA_TRIG_FSITXINT2  124
#define CLA_TRIG_FSIRXINT1  125
#define CLA_TRIG_FSIRXINT2  126
#define CLA_TRIG_CLB1INT    127
#define CLA_TRIG_CLB2INT    128
#define CLA_TRIG_CLB3INT    129
#define CLA_TRIG_CLB4INT    130

#define Cla1ForceTask1andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT1=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
                                while(Cla1Regs.MIRUN.bit.INT1 == 1);

#define Cla1ForceTask2andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT2=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT2 == 1);

#define Cla1ForceTask3andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT3=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT3 == 1);

#define Cla1ForceTask4andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT4=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT4 == 1);

#define Cla1ForceTask5andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT5=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT5 == 1);

#define Cla1ForceTask6andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT6=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT6 == 1);

#define Cla1ForceTask7andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT7=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT7 == 1);

#define Cla1ForceTask8andWait() EALLOW;             \
								Cla1Regs.MIFRC.bit.INT8=1; \
								EDIS; \
								NOP; \
								NOP; \
								NOP; \
								while(Cla1Regs.MIRUN.bit.INT8 == 1);

#define Cla1ForceTask1()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT1=1; \
											EDIS;
#define Cla1ForceTask2()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT2=1; \
											EDIS;
#define Cla1ForceTask3()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT3=1; \
											EDIS;
#define Cla1ForceTask4()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT4=1; \
											EDIS;
#define Cla1ForceTask5()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT5=1; \
											EDIS;
#define Cla1ForceTask6()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT6=1; \
											EDIS;
#define Cla1ForceTask7()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT7=1; \
											EDIS;
#define Cla1ForceTask8()       EALLOW;             \
											Cla1Regs.MIFRC.bit.INT8=1; \
											EDIS;

#ifdef __cplusplus
}
#endif



#endif /* F2004X_CLA_DEFINES_H_ */
