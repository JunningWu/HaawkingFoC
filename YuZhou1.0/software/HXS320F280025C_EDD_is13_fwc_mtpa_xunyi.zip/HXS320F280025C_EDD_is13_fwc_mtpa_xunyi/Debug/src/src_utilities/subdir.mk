################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/src_utilities/angle_gen.c \
../src/src_utilities/cpu_time.c \
../src/src_utilities/graph.c 

OBJS += \
./src/src_utilities/angle_gen.o \
./src/src_utilities/cpu_time.o \
./src/src_utilities/graph.o 

C_DEPS += \
./src/src_utilities/angle_gen.d \
./src/src_utilities/cpu_time.d \
./src/src_utilities/graph.d 


# Each subdirectory must supply rules for building sources it contributes
src/src_utilities/%.o: ../src/src_utilities/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: GNU RISC-V Cross C Compiler'
	riscv32-haawking-elf-gcc -march=rv32imfc_xhaawkaa1p0_xhaawkab1p0_xhaawkac1p0 -D__RUNNING_IN_FLASH_ -T "D:/Users/Administrator/haawking-workspace-V2.2.11Pre/HXS320F280025C_EDD_is13_fwc_mtpa_xunyi/haawking-drivers/ldscripts/HXS320F280025C_EDD_link_FLASH.ld" -mabi=ilp32f -mcmodel=medlow -mno-save-restore -menable-experimental-extensions --target=riscv32-unknown-elf --sysroot="D:/Program Files (x86)/Haawking-IDE_V2.2.11Pre\haawking-tools/compiler/haawking-elf-gcc/riscv32-unknown-elf" --gcc-toolchain="D:/Program Files (x86)/Haawking-IDE_V2.2.11Pre\haawking-tools/compiler/haawking-elf-gcc" -Odefault -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-inline-functions -cl-single-precision-constant -Wall -Wextra -Wl,--no-warn-rwx-segments  -g3 -gdwarf-3 -Wl,--defsym,IDE_VERSION_2_2_11Pre=0 -DDSC280025C_EDD -D_YUZHOU_1P2_ -DCPU_FREQ_160MHZ -DDEBUG -I../haawking-drivers/haawking-dsc280025_edd-board/common -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\haawking-drivers\haawking-dsc280025_edd-board\f28002x_common\include" -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\haawking-drivers\haawking-dsc280025_edd-board\f28002x_headers\include" -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board" -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast" -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc" -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_freemaster" -I"D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_utilities" -I../device -I../haawking-drivers/haawking-dsc280025_edd-board -I../src -std=gnu99 -x c -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


