src/src_foc/filter_so.o: ..\src\src_foc\filter_so.c \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc\filter_so.h \
  ..\src\types.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_types.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\common\hx_rv32_type.h

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc\filter_so.h:

..\src\types.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_types.h:

..\haawking-drivers\haawking-dsc280025_edd-board\common\hx_rv32_type.h:
