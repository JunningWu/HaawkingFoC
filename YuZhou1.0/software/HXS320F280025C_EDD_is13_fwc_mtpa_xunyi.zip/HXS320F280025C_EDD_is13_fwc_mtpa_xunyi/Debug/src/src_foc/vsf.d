src/src_foc/vsf.o: ..\src\src_foc\vsf.c \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc\vsf.h \
  ..\src\math_hx.h ..\src\types.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_types.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\common\hx_rv32_type.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\userParams.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\motor.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\ctrl_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Flux_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Ls_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Rr_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Rs_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Traj_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_states.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\user.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\hal.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\hal_obj.h \
  ..\device\device.h ..\device\driverlib.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_memmap.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_hrcap.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\adc.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_adc.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_asysctl.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\cpu.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\common\hx_rv32_dev.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\debug.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\asysctl.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\bgcrc.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_bgcrc.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\can.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_can.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\sysctl.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_nmi.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_sysctl.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\interrupt.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_ints.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_pie.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\clb.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_clb.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\cmpss.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_cmpss.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\cputimer.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_cputimer.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\dcc.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_dcc.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\dcsm.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_dcsm.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\dma.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_dma.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\ecap.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_ecap.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\epwm.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_epwm.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\hrpwm.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_hrpwm.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\eqep.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_eqep.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\erad.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_erad.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\flash.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_flash.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\fsi.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_fsi.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\hw_reg_inclusive_terminology.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\gpio.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_gpio.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_xint.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\xbar.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_clbxbar.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_epwmxbar.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_inputxbar.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_outputxbar.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_xbar.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\i2c.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_i2c.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\lin.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_lin.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\memcfg.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_memcfg.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\pin_map.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\pin_map_legacy.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\pmbus.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_pmbus.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\pmbus_common.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\sci.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_sci.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\spi.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_spi.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\version.h \
  ..\haawking-drivers\haawking-dsc280025_edd-board\driver_inclusive_terminology_mapping.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\pwmdac.h \
  ..\src\hal_data.h \
  D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc\svgen_current.h

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc\vsf.h:

..\src\math_hx.h:

..\src\types.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_types.h:

..\haawking-drivers\haawking-dsc280025_edd-board\common\hx_rv32_type.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\userParams.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\motor.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\ctrl_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Flux_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Ls_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Rr_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Rs_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_Traj_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_fast\est_states.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\user.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\hal.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\hal_obj.h:

..\device\device.h:

..\device\driverlib.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_memmap.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_hrcap.h:

..\haawking-drivers\haawking-dsc280025_edd-board\adc.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_adc.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_asysctl.h:

..\haawking-drivers\haawking-dsc280025_edd-board\cpu.h:

..\haawking-drivers\haawking-dsc280025_edd-board\common\hx_rv32_dev.h:

..\haawking-drivers\haawking-dsc280025_edd-board\debug.h:

..\haawking-drivers\haawking-dsc280025_edd-board\asysctl.h:

..\haawking-drivers\haawking-dsc280025_edd-board\bgcrc.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_bgcrc.h:

..\haawking-drivers\haawking-dsc280025_edd-board\can.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_can.h:

..\haawking-drivers\haawking-dsc280025_edd-board\sysctl.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_nmi.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_sysctl.h:

..\haawking-drivers\haawking-dsc280025_edd-board\interrupt.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_ints.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_pie.h:

..\haawking-drivers\haawking-dsc280025_edd-board\clb.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_clb.h:

..\haawking-drivers\haawking-dsc280025_edd-board\cmpss.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_cmpss.h:

..\haawking-drivers\haawking-dsc280025_edd-board\cputimer.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_cputimer.h:

..\haawking-drivers\haawking-dsc280025_edd-board\dcc.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_dcc.h:

..\haawking-drivers\haawking-dsc280025_edd-board\dcsm.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_dcsm.h:

..\haawking-drivers\haawking-dsc280025_edd-board\dma.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_dma.h:

..\haawking-drivers\haawking-dsc280025_edd-board\ecap.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_ecap.h:

..\haawking-drivers\haawking-dsc280025_edd-board\epwm.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_epwm.h:

..\haawking-drivers\haawking-dsc280025_edd-board\hrpwm.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_hrpwm.h:

..\haawking-drivers\haawking-dsc280025_edd-board\eqep.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_eqep.h:

..\haawking-drivers\haawking-dsc280025_edd-board\erad.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_erad.h:

..\haawking-drivers\haawking-dsc280025_edd-board\flash.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_flash.h:

..\haawking-drivers\haawking-dsc280025_edd-board\fsi.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_fsi.h:

..\haawking-drivers\haawking-dsc280025_edd-board\hw_reg_inclusive_terminology.h:

..\haawking-drivers\haawking-dsc280025_edd-board\gpio.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_gpio.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_xint.h:

..\haawking-drivers\haawking-dsc280025_edd-board\xbar.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_clbxbar.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_epwmxbar.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_inputxbar.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_outputxbar.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_xbar.h:

..\haawking-drivers\haawking-dsc280025_edd-board\i2c.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_i2c.h:

..\haawking-drivers\haawking-dsc280025_edd-board\lin.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_lin.h:

..\haawking-drivers\haawking-dsc280025_edd-board\memcfg.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_memcfg.h:

..\haawking-drivers\haawking-dsc280025_edd-board\pin_map.h:

..\haawking-drivers\haawking-dsc280025_edd-board\pin_map_legacy.h:

..\haawking-drivers\haawking-dsc280025_edd-board\pmbus.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_pmbus.h:

..\haawking-drivers\haawking-dsc280025_edd-board\pmbus_common.h:

..\haawking-drivers\haawking-dsc280025_edd-board\sci.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_sci.h:

..\haawking-drivers\haawking-dsc280025_edd-board\spi.h:

..\haawking-drivers\haawking-dsc280025_edd-board\inc\hw_spi.h:

..\haawking-drivers\haawking-dsc280025_edd-board\version.h:

..\haawking-drivers\haawking-dsc280025_edd-board\driver_inclusive_terminology_mapping.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_board\pwmdac.h:

..\src\hal_data.h:

D:\Users\Administrator\haawking-workspace-V2.2.11Pre\HXS320F280025C_EDD_is13_fwc_mtpa_xunyi\src\src_foc\svgen_current.h:
