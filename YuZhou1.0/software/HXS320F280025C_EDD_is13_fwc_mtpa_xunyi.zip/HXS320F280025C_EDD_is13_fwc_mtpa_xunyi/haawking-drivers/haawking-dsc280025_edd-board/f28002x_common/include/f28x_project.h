//###########################################################################
//
// FILE:   f28x_project.h
//
// TITLE:  F28x Project Headerfile and Examples Include File
//
//###########################################################################


#ifndef F28X_PROJECT_H
#define F28X_PROJECT_H

#include "f28002x_device.h"         // f28002x Headerfile Include File
#include "f28002x_examples.h"       // f28002x Examples Include File

#endif  // end of F28X_PROJECT_H definition

