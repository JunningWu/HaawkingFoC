//###########################################################################
//
// FILE:    f28002x_sysctrl_defines.h
//
// TITLE:   f28002x LPM support definitions
//
//###########################################################################

#ifndef F28002x_SYSCTRL_DEFINES_H
#define F28002x_SYSCTRL_DEFINES_H

//
// Defines
//
#define LPM_IDLE    0x0
#define LPM_HALT    0x2
#define LPM_HIB     0x3

#endif  // end of F28002x_SYSCTRL_DEFINES_H definition

//
// End of file.
//


