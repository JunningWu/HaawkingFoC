//###########################################################################
//
// FILE:   f28002x_tempsensorconv.c
//
// TITLE:  F28002x Temperature Sensor Conversion Functions
//
//###########################################################################

//
// Included Files
//
#include "f28002x_device.h"
#include "f28002x_examples.h"
#include "driverlib.h"




//
// Globals
//
float32_t tempSensor_tempSlope;
float32_t tempSensor_tempOffset;
float32_t tempSensor_scaleFactor;

//
// InitTempSensor - Initialize the temperature sensor by powering up the
//                  sensor, loading the calibration values from OTP to RAM,
//                  and recording the intended VREFHI voltage.
//                  Note: This function doesn't support VREFLO != 0.0V,
//                  but this could be implemented if desired.
//
void InitTempSensor(float vrefhi_voltage)
{
    EALLOW;

    //
    //power up the the temperature sensor
    //
    AnalogSubsysRegs.TSNSCTL.bit.ENABLE = 1;

    //
    //delay to allow the sensor to power up
    //
    DELAY_US(1000);


    //
    //need to remember VREFHI voltage so that sensor readings can be scaled
    //to match 2.5V values used for calibration data.
    //
    tempSensor_scaleFactor = vrefhi_voltage;

    EDIS;
}

//
// GetTemperatureC - This function uses the reference data stored in OTP to
//                   convert the raw temperature sensor reading into degrees C
//
int32_t GetTemperatureC(uint16_t sensorSample)
{
    float32_t temp;
    temp = (float32_t)(tempSensor_scaleFactor * sensorSample / 4095.0f);

    //
    //Read the Slope and Offset from OTP
    //
    tempSensor_tempSlope = 0.006f;
    tempSensor_tempOffset = 1.1f;

    return((int32_t)((temp - tempSensor_tempOffset) /
            tempSensor_tempSlope));

}

//
// GetTemperatureK - This function uses the reference data stored in OTP to
//                   convert the raw temperature sensor reading into degrees K
//
int32_t GetTemperatureK(uint16_t sensorSample)
{
	float32_t temp;
	temp = (float32_t)(tempSensor_scaleFactor * sensorSample / 4095.0f);

	//
	//Read the Slope and Offset from OTP
	//
	tempSensor_tempSlope = 0.006f;
	tempSensor_tempOffset = 1.1f;

	return((int32_t)((temp - tempSensor_tempOffset) /
			tempSensor_tempSlope) + 273);
}

//
// End of file
//
