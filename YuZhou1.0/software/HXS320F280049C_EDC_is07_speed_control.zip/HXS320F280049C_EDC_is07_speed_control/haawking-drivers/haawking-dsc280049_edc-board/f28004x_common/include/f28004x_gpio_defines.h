//###########################################################################
// $HAAWKING Release: BitField Support Library V1.0.0 $
// $Release Date: 2023-09-19 $
// $Copyright:
// Copyright(C): 2019-2023 Beijing Haawking Technology Co.,Ltd
// Website: http://www.haawking.com/
//###########################################################################

#ifndef F28004x_GPIO_DEFINES_H
#define F28004x_GPIO_DEFINES_H

//
// Defines
//

//
// CPU pin masters for GPIO_SelectPinMux()
//
#define GPIO_MUX_CPU1       0x0
#define GPIO_MUX_CPU1CLA    0x1

//
// Flags for GPIO_SetupPinOptions(). The qualification flags (SYNC, QUAL3,
// QUAL6, and ASYNC) take up two bits and must be in the order specified.
//
#define GPIO_INPUT      0
#define GPIO_OUTPUT     1
#define GPIO_PUSHPULL   0
#define GPIO_PULLUP     (1 << 0)
#define GPIO_INVERT     (1 << 1)
#define GPIO_OPENDRAIN  (1 << 2)
#define GPIO_SYNC       (0x0 << 4)
#define GPIO_QUAL3      (0x1 << 4)
#define GPIO_QUAL6      (0x2 << 4)
#define GPIO_ASYNC      (0x3 << 4)

//
// Flags for GPIO_SetupLock().
//
#define GPIO_UNLOCK     0
#define GPIO_LOCK       1

//
// Helpful constants for array-based access to GPIO registers
//
#define GPY_CTRL_OFFSET (0x80/4)
#define GPY_DATA_OFFSET (0x10/4)

#define GPYQSEL     (0x4/4)
#define GPYMUX      (0xC/4)
#define GPYDIR      (0x14/4)
#define GPYPUD      (0x18/4)
#define GPYINV      (0x20/4)
#define GPYODR      (0x24/4)
#define GPYGMUX     (0x40/4)
#define GPYCSEL     (0x50/4)
#define GPYLOCK     (0x78/4)
#define GPYCR       (0x7C/4)

#define GPYDAT      (0x0/4)
#define GPYSET      (0x4/4)
#define GPYCLEAR    (0x8/4)
#define GPYTOGGLE   (0xC/4)

#endif  // end of F28004x_GPIO_DEFINES_H definition

//
// End of file
//


