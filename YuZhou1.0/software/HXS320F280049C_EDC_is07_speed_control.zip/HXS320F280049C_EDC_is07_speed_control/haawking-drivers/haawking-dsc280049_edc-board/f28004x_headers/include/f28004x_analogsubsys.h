//#############################################################################
//
// $Copyright:
// Copyright (C) 2019-2024 Beijing Haawking Technology Co.,Ltd
// http://www.haawking.com/ All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Beijing Haawking Technology Co.,Ltd nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
//#############################################################################
//
// Release for HXS320F280049CEDC, Bitfield DriverLib, 1.0.0
//
// Release time: 2024-05-11 10:01:13.411273
//
//#############################################################################


#ifndef F28004X_ANALOGSUBSYS_H
#define F28004X_ANALOGSUBSYS_H

#ifdef __cplusplus
extern "C" {
#endif


//---------------------------------------------------------------------------
// ANALOGSUBSYS Individual Register Bit Definitions:

struct ANAREFPP_BITS {                        // bits description
    Uint32 ANAREFBDIS:1;                      // 0 Disable ANAREFB
    Uint32 ANAREFCDIS:1;                      // 1 Disable ANAREFC
    Uint32 rsvd1:30;                          // 31:2 Reserved
};

union ANAREFPP_REG {
    Uint32  all;
    struct  ANAREFPP_BITS  bit;
};

struct TSNSCTL_BITS {                         // bits description
    Uint32 ENABLE:1;                          // 0 Temperature Sensor Enable
    Uint32 rsvd1:31;                          // 31:1 Reserved
};

union TSNSCTL_REG {
    Uint32  all;
    struct  TSNSCTL_BITS  bit;
};

struct ANAREFCTL_BITS {                       // bits description
    Uint32 ANAVREFHIAEN:1;                    // 0 Analog Reference High A Enable
    Uint32 ANAVREFHIBEN:1;                    // 1 Analog Reference High B Enable
    Uint32 ANAVREFHICEN:1;                    // 2 Analog Reference High C Enable
    Uint32 ANAREFASEL:1;                      // 3 Analog DAC-A Reference Selection
    Uint32 ANAREFBSEL:1;                      // 4 Analog DAC-B Reference Selection
    Uint32 rsvd1:3;                           // 7:5 Reserved
    Uint32 ANAREFAVDDSEL:1;                   // 8 Reference voltage selection circuit for analog ADCA
    Uint32 ANAREFBVDDSEL:1;                   // 9 Reference voltage selection circuit for analog ADCB
    Uint32 ANAREFCVDDSEL:1;                   // 10 Reference voltage selection circuit for analog ADCC
    Uint32 ANAREFA2P5SEL:1;                   // 11 Analog reference A 2.5V source selection
    Uint32 ANAREFB2P5SEL:1;                   // 12 Analog reference B 2.5V source selection
    Uint32 rsvd2:3;                           // 15:13 Reserved
    Uint32 rsvd3:16;                          // 31:16 Reserved
};

union ANAREFCTL_REG {
    Uint32  all;
    struct  ANAREFCTL_BITS  bit;
};

struct VMONCTL_BITS {                         // bits description
    Uint32 BOR_LV:3;                          // 2:0 Reserved
    Uint32 rsvd1:5;                           // 7:3 Reserved
    Uint32 BORLVMONDIS:1;                     // 8 Disable BORL(ow) feature on VDDIO
    Uint32 rsvd2:23;                          // 31:9 Reserved
};

union VMONCTL_REG {
    Uint32  all;
    struct  VMONCTL_BITS  bit;
};

struct CMPHPMXSEL_BITS {                      // bits description
    Uint32 CMP1HPMXSEL:3;                     // 2:0 CMP1HPMXSEL bits
    Uint32 CMP2HPMXSEL:3;                     // 5:3 CMP2HPMXSEL bits
    Uint32 CMP3HPMXSEL:3;                     // 8:6 CMP3HPMXSEL bits
    Uint32 CMP4HPMXSEL:3;                     // 11:9 CMP4HPMXSEL bits
    Uint32 CMP5HPMXSEL:3;                     // 14:12 CMP5HPMXSEL bits
    Uint32 rsvd1:1;                           // 15 Reserved
    Uint32 CMP6HPMXSEL:3;                     // 18:16 CMP6HPMXSEL bits
    Uint32 CMP7HPMXSEL:3;                     // 21:19 CMP7HPMXSEL bits
    Uint32 rsvd2:10;                          // 31:22 Reserved
};

union CMPHPMXSEL_REG {
    Uint32  all;
    struct  CMPHPMXSEL_BITS  bit;
};

struct CMPLPMXSEL_BITS {                      // bits description
    Uint32 CMP1LPMXSEL:3;                     // 2:0 CMP1LPMXSEL bits
    Uint32 CMP2LPMXSEL:3;                     // 5:3 CMP2LPMXSEL bits
    Uint32 CMP3LPMXSEL:3;                     // 8:6 CMP3LPMXSEL bits
    Uint32 CMP4LPMXSEL:3;                     // 11:9 CMP4LPMXSEL bits
    Uint32 CMP5LPMXSEL:3;                     // 14:12 CMP5LPMXSEL bits
    Uint32 rsvd1:1;                           // 15 Reserved
    Uint32 CMP6LPMXSEL:3;                     // 18:16 CMP6LPMXSEL bits
    Uint32 CMP7LPMXSEL:3;                     // 21:19 CMP7LPMXSEL bits
    Uint32 rsvd2:10;                          // 31:22 Reserved
};

union CMPLPMXSEL_REG {
    Uint32  all;
    struct  CMPLPMXSEL_BITS  bit;
};

struct CMPHNMXSEL_BITS {                      // bits description
    Uint32 CMP1HNMXSEL:1;                     // 0 CMP1HNMXSEL bits
    Uint32 CMP2HNMXSEL:1;                     // 1 CMP2HNMXSEL bits
    Uint32 CMP3HNMXSEL:1;                     // 2 CMP3HNMXSEL bits
    Uint32 CMP4HNMXSEL:1;                     // 3 CMP4HNMXSEL bits
    Uint32 CMP5HNMXSEL:1;                     // 4 CMP5HNMXSEL bits
    Uint32 CMP6HNMXSEL:1;                     // 5 CMP6HNMXSEL bits
    Uint32 CMP7HNMXSEL:1;                     // 6 CMP7HNMXSEL bits
    Uint32 rsvd1:25;                          // 31:7 Reserved
};

union CMPHNMXSEL_REG {
    Uint32  all;
    struct  CMPHNMXSEL_BITS  bit;
};

struct CMPLNMXSEL_BITS {                      // bits description
    Uint32 CMP1LNMXSEL:1;                     // 0 CMP1LNMXSEL bits
    Uint32 CMP2LNMXSEL:1;                     // 1 CMP2LNMXSEL bits
    Uint32 CMP3LNMXSEL:1;                     // 2 CMP3LNMXSEL bits
    Uint32 CMP4LNMXSEL:1;                     // 3 CMP4LNMXSEL bits
    Uint32 CMP5LNMXSEL:1;                     // 4 CMP5LNMXSEL bits
    Uint32 CMP6LNMXSEL:1;                     // 5 CMP6LNMXSEL bits
    Uint32 CMP7LNMXSEL:1;                     // 6 CMP7LNMXSEL bits
    Uint32 rsvd1:25;                          // 31:7 Reserved
};

union CMPLNMXSEL_REG {
    Uint32  all;
    struct  CMPLNMXSEL_BITS  bit;
};

struct ADCDACLOOPBACK_BITS {                  // bits description
    Uint32 ENLB2ADCA:1;                       // 0 Loop the output of the comparator COMPDACA to ADCA
    Uint32 ENLB2ADCB:1;                       // 1 Loop the output of the comparator COMPDACA to ADCB
    Uint32 ENLB2ADCC:1;                       // 2 Loop the output of the comparator COMPDACA to ADCC
    Uint32 rsvd1:13;                          // 15:3 Reserved
    Uint32 KEY:16;                            // 31:16 Secret Key bits
};

union ADCDACLOOPBACK_REG {
    Uint32  all;
    struct  ADCDACLOOPBACK_BITS  bit;
};

struct LOCK_BITS {                            // bits description
    Uint32 TSNSCTL:1;                         // 0 TSNSCTL Register lock bit
    Uint32 ANAREFCTL:1;                       // 1 ANAREFCTL Register lock bit
    Uint32 VMONCTL:1;                         // 2 VMONCTL Register lock bit
    Uint32 DCDCCTL:1;                         // 3 DCDCCTL Register lock bit
    Uint32 ADCINMXSEL:1;                      // 4 ADCINMXSEL Register lock bit
    Uint32 CMPHPMXSEL:1;                      // 5 CMPHPMXSEL Register lock bit
    Uint32 CMPLPMXSEL:1;                      // 6 CMPLPMXSEL Register lock bit
    Uint32 CMPHNMXSEL:1;                      // 7 CMPHNMXSEL Register lock bit
    Uint32 CMPLNMXSEL:1;                      // 8 CMPLNMXSEL Register lock bit
    Uint32 VREGCTL:1;                         // 9 VREGCTL Register lock bit
    Uint32 rsvd1:6;                           // 15:10 Reserved
    Uint32 rsvd2:16;                          // 31:16 Reserved
};

union LOCK_REG {
    Uint32  all;
    struct  LOCK_BITS  bit;
};

struct PMULDOCTL_BITS {                       // bits description
    Uint32 PMUVREFHIA2P5:1;                   // 0  
    Uint32 PMUVREFHIB2P5:1;                   // 1  
    Uint32 PMUVREFHIA1P65:1;                  // 2  
    Uint32 PMUVREFHIB1P65:1;                  // 3  
    Uint32 rsvd1:28;                          // 31:4 Reserved
};

union PMULDOCTL_REG {
    Uint32  all;
    struct  PMULDOCTL_BITS  bit;
};

struct  ANALOG_SUBSYS_REGS {
    union   ANAREFPP_REG                     ANAREFPP;                    // 0x0 ADC Analog Reference Peripheral Properties register. The value of this register is populated during boot rom.
    union   TSNSCTL_REG                      TSNSCTL;                     // 0x4 Temperature Sensor Control Register
    union   ANAREFCTL_REG                    ANAREFCTL;                   // 0x8 Analog Reference Control Register
    union   VMONCTL_REG                      VMONCTL;                     // 0xc Voltage Monitor Control Register
    Uint32                                   rsvd1[2];                    // 0x10 Reserved
    union   CMPHPMXSEL_REG                   CMPHPMXSEL;                  // 0x18 Bits to select one of the many sources on CopmHP inputs. Refer to Pimux diagram for details.
    union   CMPLPMXSEL_REG                   CMPLPMXSEL;                  // 0x1c Bits to select one of the many sources on CopmLP inputs. Refer to Pimux diagram for details.
    union   CMPHNMXSEL_REG                   CMPHNMXSEL;                  // 0x20 Bits to select one of the many sources on CopmHN inputs. Refer to Pimux diagram for details.
    union   CMPLNMXSEL_REG                   CMPLNMXSEL;                  // 0x24 Bits to select one of the many sources on CopmLN inputs. Refer to Pimux diagram for details.
    union   ADCDACLOOPBACK_REG               ADCDACLOOPBACK;              // 0x28 Loopback control register from DAC to ADC
    union   LOCK_REG                         LOCK;                        // 0x2c Lock Register
    union   PMULDOCTL_REG                    PMULDOCTL;                   // 0x30 Pmu Ldo Control Register
};


#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif

//===========================================================================
// End of file.
//===========================================================================
