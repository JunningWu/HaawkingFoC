//#############################################################################
// $Copyright:
// Copyright (C) 2017-2023 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

#ifndef USER_H
#define USER_H

//! \file   solutions/boostxl_drv8320rs/f28004x/drivers/user.h
//! \brief  Contains the user related definitions
//!


// **************************************************************************
// the includes

// modules
#include "userParams.h"
#include "hal.h"
//!
//!
//! \defgroup USER USER
//!
//@{


#ifdef __cplusplus
extern "C" {
#endif


// **************************************************************************
// the defines
#define BOOSTX_to_J1_J2     1
#define BOOSTX_to_J4_J5    0

#define BOOST_to_LPD        BOOSTX_to_J1_J2

//! \brief Defines the nominal DC bus voltage, V
//!
//! \brief Defines the nominal DC bus voltage, V
//!
#define USER_NOMINAL_DC_BUS_VOLTAGE_V         (24.0f)

//! \brief Defines the maximum voltage at the AD converter
#define USER_ADC_FULL_SCALE_VOLTAGE_V         (56.0f)

//! \brief Defines the analog voltage filter pole location, Hz
#define USER_VOLTAGE_FILTER_POLE_Hz           (680.4839141f)     // 47nF

//! \brief Defines the maximum current at the AD converter
#define USER_ADC_FULL_SCALE_CURRENT_A         (33.0f)     // gain=10

//! \brief ADC current offsets for dc-link
// the dc-link offset current for BSXL8323RS_REVA
#define USER_IDC_OFFSET_A            (USER_ADC_FULL_SCALE_CURRENT_A / 2.0f)

//! \brief ADC current offsets for A, B, and C phases
#define USER_IDC_OFFSET_AD           (2048.0f)

#define USER_IDC_OFFSET_AD_MAX       (USER_IDC_OFFSET_AD + 100.0f)
#define USER_IDC_OFFSET_AD_MIN       (USER_IDC_OFFSET_AD - 100.0f)

//! \brief ADC current offsets for A, B, and C phases
#define   IA_OFFSET_A    (16.350033f)           // ~=0.5*USER_ADC_FULL_SCALE_CURRENT_A
#define   IB_OFFSET_A    (16.350033f)           // ~=0.5*USER_ADC_FULL_SCALE_CURRENT_A
#define   IC_OFFSET_A    (16.350033f)           // ~=0.5*USER_ADC_FULL_SCALE_CURRENT_A


//! \brief ADC voltage offsets for A, B, and C phases
#define   VA_OFFSET_V    (0.495257079f)         // ~=0.5
#define   VB_OFFSET_V    (0.493127942f)         // ~=0.5
#define   VC_OFFSET_V    (0.491690784f)         // ~=0.5

//! \brief Defines the system clock frequency, Hz
//! if the CPU clock is not equal to DEVICE_SYSCLK_FREQ due to the settings in
//! SysCtl_setClock(), need to change this efinition accordingly
#define USER_SYSTEM_FREQ_Hz             (float32_t)(DEVICE_SYSCLK_FREQ)

//! \brief Defines the system clock frequency, MHz
#define USER_SYSTEM_FREQ_MHz            (float32_t)(USER_SYSTEM_FREQ_Hz / 1000000.0f)

//! \brief DC bus over voltage threshold
#define USER_OVER_VOLTAGE_FAULT_V        (52.0f)

//! \brief DC bus over voltage threshold
#define USER_OVER_VOLTAGE_NORM_V         (48.0f)

//! \brief DC bus under voltage threshold
#define USER_UNDER_VOLTAGE_FAULT_V       (8.0f)//(0.2f)//(25.0f)//

//! \brief DC bus under voltage threshold
#define USER_UNDER_VOLTAGE_NORM_V        (10.0f)

//! \brief motor lost phase current threshold
#define USER_LOST_PHASE_CURRENT_A        (0.2f)

//! \brief motor unbalance ratio percent threshold
#define USER_UNBALANCE_RATIO             (0.2f)

//! \brief motor over load power threshold
#define USER_OVER_LOAD_POWER_W           (50.0f)

//! \brief motor stall current threshold
#define USER_STALL_CURRENT_A             (2.0f)

//! \brief motor fault check current threshold
#define USER_FAULT_CHECK_CURRENT_A       (11.0f)

//! \brief motor failed maximum speed threshold
#define USER_FAIL_SPEED_MAX_HZ           (1500.0f)

//! \brief motor failed minimum speed threshold
#define USER_FAIL_SPEED_MIN_HZ           (5.0f)

//! \brief Defines the number of failed torque
//!
#define USER_TORQUE_FAILED_SET           (0.000001f)

// end of BSXL8323RS_REVA

/*
//------------------------------------------------------------------------------
//! \brief ADC current offsets checking value for A, B, and C phases
#define USER_IA_OFFSET_AD_MAX    (USER_IA_OFFSET_AD + 150.0f)
#define USER_IB_OFFSET_AD_MAX    (USER_IB_OFFSET_AD + 150.0f)
#define USER_IC_OFFSET_AD_MAX    (USER_IC_OFFSET_AD + 150.0f)

#define USER_IA_OFFSET_AD_MIN    (USER_IA_OFFSET_AD - 150.0f)
#define USER_IB_OFFSET_AD_MIN    (USER_IB_OFFSET_AD - 150.0f)
#define USER_IC_OFFSET_AD_MIN    (USER_IC_OFFSET_AD - 150.0f)

//! \brief ADC voltage offsets for A, B, and C phases
#define USER_VA_OFFSET_SF_MAX    (USER_VA_OFFSET_SF + 0.05f)
#define USER_VB_OFFSET_SF_MAX    (USER_VB_OFFSET_SF + 0.05f)
#define USER_VC_OFFSET_SF_MAX    (USER_VC_OFFSET_SF + 0.05f)

#define USER_VA_OFFSET_SF_MIN    (USER_VA_OFFSET_SF - 0.05f)
#define USER_VB_OFFSET_SF_MIN    (USER_VB_OFFSET_SF - 0.05f)
#define USER_VC_OFFSET_SF_MIN    (USER_VC_OFFSET_SF - 0.05f)
*/
//******************************************************************************
//------------------------------------------------------------------------------
//! \brief Vbus used to calculate the voltage offsets A, B, and C
// =0.5*USER_NOMINAL_DC_BUS_VOLTAGE_V
#define USER_VBUS_OFFSET_V  (0.5*USER_ADC_FULL_SCALE_VOLTAGE_V)


//! \brief Defines the maximum negative current to be applied in Id reference
//!
#define USER_MAX_NEGATIVE_ID_REF_CURRENT_A       ((float32_t)(-2.0))


//! \brief Defines the number of pwm clock ticks per isr clock tick
//!        Note: Valid values are 1, 2 or 3 only
#define USER_NUM_PWM_TICKS_PER_ISR_TICK          (1)


//! \brief Defines the number of ISR clock ticks per current controller clock tick
//!
#define USER_NUM_ISR_TICKS_PER_CURRENT_TICK      (1)


//! \brief Defines the number of ISR clock ticks per speed controller clock tick
//!
#define USER_NUM_ISR_TICKS_PER_SPEED_TICK        (15)


//! \brief Defines the number of current sensors
//!
#define USER_NUM_CURRENT_SENSORS                 (3)


//! \brief Defines the number of voltage sensors
//!
#define USER_NUM_VOLTAGE_SENSORS                 (3)


//! \brief Defines the Pulse Width Modulation (PWM) frequency, kHz
//!
#define USER_PWM_FREQ_kHz        ((float32_t)(15.0f))
#define USER_PWM_TBPRD_NUM       (uint16_t)(USER_SYSTEM_FREQ_MHz * 1000.0f / USER_PWM_FREQ_kHz / 2.0f)

//! \brief Defines the Pulse Width Modulation (PWM) period, usec
//!
#define USER_PWM_PERIOD_usec     ((float32_t)1000.0/USER_PWM_FREQ_kHz)


//! \brief Defines the Interrupt Service Routine (ISR) frequency, Hz
//!
#define USER_ISR_FREQ_Hz         (USER_PWM_FREQ_kHz * (float32_t)1000.0 / (float32_t)USER_NUM_PWM_TICKS_PER_ISR_TICK)

//! \brief Defines the SFRA sampling, Hz
//!
#define MOTOR_SAMPLING_FREQ_HZ     USER_ISR_FREQ_Hz


//! \brief Defines the Interrupt Service Routine (ISR) period, usec
//!
#define USER_ISR_PERIOD_usec     (USER_PWM_PERIOD_usec * (float32_t)USER_NUM_PWM_TICKS_PER_ISR_TICK)


//! \brief Defines the direct voltage (Vd) scale factor
//!
#define USER_VD_SF               ((float32_t)(0.95f))


//! \brief Defines the voltage scale factor for the system
//!
#define USER_VOLTAGE_SF          (USER_ADC_FULL_SCALE_VOLTAGE_V / 4096.0f)

//! \brief Defines the current scale factor for the system
//!
#define USER_CURRENT_SF          (USER_ADC_FULL_SCALE_CURRENT_A / 4096.0f)


//! \brief Defines the current scale invert factor for the system
//!
#define USER_CURRENT_INV_SF      (4096.0f / USER_ADC_FULL_SCALE_CURRENT_A)


//! \brief Defines the analog voltage filter pole location, rad/s
//!
#define USER_VOLTAGE_FILTER_POLE_rps  (MATH_TWO_PI * USER_VOLTAGE_FILTER_POLE_Hz)

//! \brief Defines the maximum Vs magnitude in per units allowed
//! \brief This value sets the maximum magnitude for the output of the Id and
//! \brief Iq PI current controllers. The Id and Iq current controller outputs
//! \brief are Vd and Vq. The relationship between Vs, Vd, and Vq is:
//! \brief Vs = sqrt(Vd^2 + Vq^2).  In this FOC controller, the Vd value is set
//! \brief equal to USER_MAX_VS_MAG*USER_VD_MAG_FACTOR.
//! \brief so the Vq value is set equal to sqrt(USER_MAX_VS_MAG^2 - Vd^2).
//!
//! \brief Set USER_MAX_VS_MAG = 0.5 for a pure sinewave with a peak at
//! \brief SQRT(3)/2 = 86.6% duty cycle.  No current reconstruction
//! \brief is needed for this scenario.
//!
//! \brief Set USER_MAX_VS_MAG = 1/SQRT(3) = 0.5774 for a pure sinewave
//! \brief with a peak at 100% duty cycle.  Current reconstruction
//! \brief will be needed for this scenario (Lab08).
//!
//! \brief Set USER_MAX_VS_MAG = 2/3 = 0.6666 to create a trapezoidal
//! \brief voltage waveform.  Current reconstruction will be needed
//! \brief for this scenario (Lab08).
//!
//! \brief For space vector over-modulation, see lab08 for details on
//! \brief system requirements that will allow the SVM generator to
//! \brief go all the way to trapezoidal.
//!
//#define USER_MAX_VS_MAG_PU            (0.66)
//#define USER_MAX_VS_MAG_PU              (0.65)
#define USER_MAX_VS_MAG_PU            (0.576)
//#define USER_MAX_VS_MAG_PU            (0.565)
//#define USER_MAX_VS_MAG_PU            (0.5)


//! \brief Defines the reference Vs magnitude in per units allowed
//! \      Set the value equal from 0.5 to 0.95 of the maximum Vs magnitude
#define USER_VS_REF_MAG_PU             ((float32_t)(0.8) * USER_MAX_VS_MAG_PU)

//! \brief Defines the R/L excitation frequency, Hz
//!
#define USER_R_OVER_L_EXC_FREQ_Hz  ((float32_t)(300.0))


//! \brief Defines the R/L Kp scale factor, pu
//! \brief Kp used during R/L is USER_R_OVER_L_KP_SF * USER_NOMINAL_DC_BUS_VOLTAGE_V / USER_MOTOR_MAX_CURRENT_A;
//!
#define USER_R_OVER_L_KP_SF        ((float32_t)(0.02))


//! \brief Defines maximum acceleration for the estimation speed profiles, Hz/sec
//!
#define USER_MAX_ACCEL_Hzps        ((float32_t)(2.0))


//! \brief Defines the controller execution period, usec
//!
#define USER_CTRL_PERIOD_usec      (USER_ISR_PERIOD_usec)


//! \brief Defines the controller execution period, sec
//!
#define USER_CTRL_PERIOD_sec       ((float32_t)USER_CTRL_PERIOD_usec/(float32_t)1000000.0)


//! \brief Defines the IdRated delta to use during estimation
//!
#define USER_IDRATED_DELTA_A                 ((float32_t)(0.0001))

//! \brief Defines the forced angle frequency, Hz
#define USER_FORCE_ANGLE_FREQ_Hz             ((float32_t)(1.0))

//! \brief Defines the forced angle acceleration, Hz
#define USER_FORCE_ANGLE_ACCEL_Hzps          ((float32_t)(10.0))

//! \brief Defines the near zero speed limit for electrical frequency estimation, Hz
//!        The flux integrator uses this limit to regulate flux integration
#define USER_FREQ_NEARZEROSPEEDLIMIT_Hz      ((float_t)(0.0f))

//! \brief Defines the fraction of IdRated to use during inductance estimation
//!
#define USER_IDRATED_FRACTION_FOR_L_IDENT    ((float32_t)(0.5))


//! \brief Defines the fraction of SpeedMax to use during inductance estimation
//!
#define USER_SPEEDMAX_FRACTION_FOR_L_IDENT  ((float32_t)(1.0))


//! \brief Defines the Power Warp gain for computing Id reference
//! \brief If motor parameters are known, set this gain to:
//! \brief USER_PW_GAIN = SQRT(1.0 + USER_MOTOR_Rr_Ohm / USER_MOTOR_Rs_Ohm)
//!
#define USER_PW_GAIN                        ((float32_t)(1.0))


//! \brief Defines the pole location for the DC bus filter, rad/sec
//!
#define USER_DCBUS_POLE_rps                  ((float32_t)(100.0))


//! \brief Defines the pole location for the voltage and current offset estimation, rad/s
//!
#define USER_OFFSET_POLE_rps                 ((float32_t)(20.0))


//! \brief Defines the pole location for the speed control filter, rad/sec
//!
#define USER_SPEED_POLE_rps                  ((float32_t)(100.0))


//! \brief Defines the pole location for the direction filter, rad/sec
//!
#define USER_DIRECTION_POLE_rps             (MATH_TWO_PI * (float32_t)(10.0))


//! \brief Defines the pole location for the second direction filter, rad/sec
//!
#define USER_DIRECTION_POLE_2_rps           (MATH_TWO_PI * (float32_t)(100.0))


//! \brief Defines the pole location for the flux estimation, rad/sec
//!
#define USER_FLUX_POLE_rps                  ( (float32_t)(10.0))

//! \brief Defines the pole location for the R/L estimation, rad/sec
//!
#define USER_R_OVER_L_POLE_rps              (MATH_TWO_PI * (float32_t)(3.2))

//! \brief Defines the convergence factor for the estimator
//!
#define USER_EST_KAPPAQ                          ((float32_t)(1.5f))


//! \brief Defines the scale factor for the flux estimation
//! the default value is 1.0f, change the value between 0.1f and 1.25f
//!
//#define USER_EST_FLUX_HF_SF                     ((float32_t)(0.120f))
#define USER_EST_FLUX_HF_SF                     ((float32_t)(0.250f))
//#define USER_EST_FLUX_HF_SF                     ((float32_t)(1.00f))

//! \brief Defines the scale factor for the frequency estimation
//! the default value is 1.0f, change the value between 0.5f and 1.5f
//!
#define USER_EST_FREQ_HF_SF                     ((float32_t)(1.00f))

//! \brief Defines the scale factor for the bemf estimation
//! the default value is 1.0f, change the value between 0.50f and 1.25f
//!
#define USER_EST_BEMF_HF_SF                     ((float32_t)(1.00f))

//------------------------------------------------------------------------------
//! brief Define the Kp gain for Field Weakening Control
#define USER_FWC_KP                 0.0225

//! brief Define the Ki gain for Field Weakening Control
#define USER_FWC_KI                 0.00225

//! brief Define the maximum current vector angle for Field Weakening Control
#define USER_FWC_MAX_ANGLE          -10.0f                        // degree
#define USER_FWC_MAX_ANGLE_RAD      USER_FWC_MAX_ANGLE /180.0f * MATH_PI

//! brief Define the minimum current vector angle for Field Weakening Control
#define USER_FWC_MIN_ANGLE          0.0f                          // degree
#define USER_FWC_MIN_ANGLE_RAD      USER_FWC_MIN_ANGLE /180.0f * MATH_PI

//! \brief Defines the number of DC bus over/under voltage setting time
//!  timer base = 5ms
#define USER_VOLTAGE_FAULT_TIME_SET          (500)

//! \brief Defines the number of motor over load setting time
//!  timer base = 5ms, 1s
#define USER_OVER_LOAD_TIME_SET              (200)

//! \brief Defines the number of motor stall setting time
//!  timer base = 5ms, 1s
#define USER_STALL_TIME_SET                  (200)

//! \brief Defines the number of phase unbalance setting time
//!  timer base = 5ms, 5s
#define USER_UNBALANCE_TIME_SET              (1000)

//! \brief Defines the number of lost phase setting time
//!  timer base = 5ms, 10s
#define USER_LOST_PHASE_TIME_SET             (2000)

//! \brief Defines the number of over speed setting time
//!  timer base = 5ms
#define USER_OVER_SPEED_TIME_SET             (600)

//! \brief Defines the number of startup failed setting time
//!  timer base = 5ms, 10s
#define USER_STARTUP_FAIL_TIME_SET           (2000)

//! \brief Defines the number of over load setting times
//!
#define USER_OVER_CURRENT_TIMES_SET          (5)

//! \brief Defines the number of stop wait time
//!  timer base = 5ms, 10s
#define USER_STOP_WAIT_TIME_SET              (2000)

//! \brief Defines the number of restart wait time
//!  timer base = 5ms, 10s
#define USER_RESTART_WAIT_TIME_SET           (2000)

//! \brief Defines the number of restart time
//!
#define USER_START_TIMES_SET                 (3)

//! \brief Defines the alignment time
//!
#define USER_ALIGN_TIMES_SET                 (2000)     // ctrl period

//!
//!
#define USER_QEP_UNIT_TIMER_TICKS            (uint32_t)(USER_SYSTEM_FREQ_MHz/(2.0f * USER_ISR_FREQ_Hz) * 1000000.0f)

//==============================================================================
// Motor defines

#define USER_MOTOR my_pm_motor_1


//------------------------------------------------------------------
#if (USER_MOTOR == my_pm_motor_1)
/*
//36V 200W

#define USER_MOTOR_TYPE                   MOTOR_TYPE_PM
#define USER_MOTOR_NUM_POLE_PAIRS         (5)
#define USER_MOTOR_Rr_Ohm                 (0)
#define USER_MOTOR_Rs_Ohm                 (0.244506612)
#define USER_MOTOR_Ls_d_H                 (0.000343821011)
#define USER_MOTOR_Ls_q_H                 (0.000343821011)
#define USER_MOTOR_RATED_FLUX_VpHz        (0.05490241434)
#define USER_MOTOR_MAGNETIZING_CURRENT_A  (0)
#define USER_MOTOR_RES_EST_CURRENT_A      (1.5f)
#define USER_MOTOR_IND_EST_CURRENT_A      (-1.0f)
#define USER_MOTOR_MAX_CURRENT_A          (6.5f)
#define USER_MOTOR_FLUX_EXC_FREQ_Hz       (20.0f)
*/
///*
//48V 400W

#define USER_MOTOR_TYPE                   MOTOR_TYPE_PM
#define USER_MOTOR_NUM_POLE_PAIRS         (5)
#define USER_MOTOR_Rr_Ohm                 (0)
#define USER_MOTOR_Rs_Ohm                 (0.16110213)
#define USER_MOTOR_Ls_d_H                 (0.0002862567)
#define USER_MOTOR_Ls_q_H                 (0.0002862567)
#define USER_MOTOR_RATED_FLUX_VpHz        (0.07289529)
#define USER_MOTOR_MAGNETIZING_CURRENT_A  (0)
#define USER_MOTOR_RES_EST_CURRENT_A      (1.5f)
#define USER_MOTOR_IND_EST_CURRENT_A      (-1.0f)
#define USER_MOTOR_MAX_CURRENT_A          (1.5f)
#define USER_MOTOR_FLUX_EXC_FREQ_Hz       (20.0f)
//*/
/*
#define USER_MOTOR_TYPE                   MOTOR_TYPE_PM
#define USER_MOTOR_NUM_POLE_PAIRS         (3)
#define USER_MOTOR_Rr_Ohm                 (0)
#define USER_MOTOR_Rs_Ohm                 (1.40885139)
#define USER_MOTOR_Ls_d_H                 (0.00674297567)
#define USER_MOTOR_Ls_q_H                 (0.00674297567)
#define USER_MOTOR_RATED_FLUX_VpHz        (0.554637611)
#define USER_MOTOR_MAGNETIZING_CURRENT_A  (0)
#define USER_MOTOR_RES_EST_CURRENT_A      (2.0f)
#define USER_MOTOR_IND_EST_CURRENT_A      (-1.0f)
#define USER_MOTOR_MAX_CURRENT_A          (6.0f)
#define USER_MOTOR_FLUX_EXC_FREQ_Hz       (15.0f)
*/
// Number of lines on the motor's quadrature encoder
#define USER_MOTOR_NUM_ENC_SLOTS          (2500)

#define USER_MOTOR_INERTIA_Kgm2           (5.8e-05)

#define USER_MOTOR_FREQ_NEARZEROLIMIT_Hz  (0.0f)          // Hz

#define USER_MOTOR_RATED_VOLTAGE_V        (36.0f)
#define USER_MOTOR_RATED_SPEED_KRPM       (3.0f)

#define USER_MOTOR_FREQ_MIN_HZ            (9.0f)          // Hz
#define USER_MOTOR_FREQ_MAX_HZ            (250.0f)         // Hz

#define USER_MOTOR_FREQ_LOW_HZ            (5.0f)            // Hz
#define USER_MOTOR_FREQ_HIGH_HZ           (250.0f)          // Hz
#define USER_MOTOR_VOLT_MIN_V             (1.0f)            // Volt
#define USER_MOTOR_VOLT_MAX_V             (36.0f)           // Volt

#define USER_MOTOR_FORCE_DELTA_A          (0.05f)          // A
#define USER_MOTOR_ALIGN_DELTA_A          (0.01f)          // A
#define USER_MOTOR_FLUX_CURRENT_A         (1.5f)           // A
#define USER_MOTOR_ALIGN_CURRENT_A        (1.5f)//(1.5f)           // A
#define USER_MOTOR_STARTUP_CURRENT_A      (3.5f)           // A
#define USER_MOTOR_TORQUE_CURRENT_A       (2.0f)           // A
#define USER_MOTOR_OVER_CURRENT_A         (6.5f)           // A

#define USER_MOTOR_BRAKE_CURRENT_A        (1.0f)           // A
#define USER_MOTOR_BRAKE_TIME_DELAY       (12000U)        // 60s/5ms

#define USER_MOTOR_SPEED_START_Hz         (30.0f)
#define USER_MOTOR_SPEED_FORCE_Hz         (15.0f)
#define USER_MOTOR_ACCEL_START_Hzps       (10.0f)
#define USER_MOTOR_ACCEL_MAX_Hzps         (20.0f)

#define USER_MOTOR_SPEED_FS_Hz            (3.0f)

// only for encoder
#define USER_MOTOR_ENC_POS_MAX            (USER_MOTOR_NUM_ENC_SLOTS * 4 - 1)
#define USER_MOTOR_ENC_POS_OFFSET         (668)

// Only for eSMO
#define USER_MOTOR_KSLIDE_MAX             (0.75f)      //
#define USER_MOTOR_KSLIDE_MIN             (0.15f)

#define USER_MOTOR_PLL_KP_MAX             (6.75f)      //
#define USER_MOTOR_PLL_KP_MIN             (0.75f)
#define USER_MOTOR_PLL_KP_SF              (5.0f)

#define USER_MOTOR_BEMF_THRESHOLD         (0.5f)
#define USER_MOTOR_BEMF_KSLF_FC_Hz        (1.0f)
#define USER_MOTOR_THETA_OFFSET_SF        (1.0f)
#define USER_MOTOR_SPEED_LPF_FC_Hz        (200.0f)

// for IS-BLDC
#define USER_MOTOR_RAMP_START_Hz           (3.0f)
#define USER_MOTOR_RAMP_END_Hz             (30.0f)
#define USER_MOTOR_RAMP_DELAY              (5)

#define USER_MOTOR_ISBLDC_INT_MAX          (0.015f)
#define USER_MOTOR_ISBLDC_INT_MIN          (0.010f)

// for Rs online calibration
#define USER_MOTOR_RSONLINE_WAIT_TIME      (60000U)    // 5min/300s at 5ms base
#define USER_MOTOR_RSONLINE_WORK_TIME      (24000U)     //2min/120s at 5ms base

#endif


//! \brief Defines the maximum current slope for Id trajectory
//!
#define USER_MAX_CURRENT_DELTA_A        (USER_MOTOR_RES_EST_CURRENT_A / USER_ISR_FREQ_Hz)


//! \brief Defines the maximum current slope for Id trajectory during power warp mode
//!
#define USER_MAX_CURRENT_DELTA_PW_A    (0.3 * USER_MOTOR_RES_EST_CURRENT_A / USER_ISR_FREQ_Hz)

// **************************************************************************
// the Defines
#define USER_POT_ADC_MIN                 (200U)

#define USER_POT_SPEED_SF                USER_MOTOR_FREQ_MAX_HZ / ((float32_t)(4096.0f - USER_POT_ADC_MIN))

//! \brief Defines the minimum frequency for pot
#define USER_POT_SPEED_MIN_Hz            (USER_MOTOR_FREQ_MAX_HZ * 0.1f)

//! \brief Defines the maximum frequency input
#define USER_POT_SPEED_MAX_Hz            (USER_MOTOR_FREQ_MAX_HZ * 0.5f)

//! \brief Defines the pot signal wait delay time
#define USER_WAIT_TIME_SET               (500U)         // 0.5s/1ms

//! \brief Defines the minimum frequency for pulse input
#define USER_SPEED_CAP_MIN_Hz            (20.0f)

//! \brief Defines the maximum frequency for pulse input
#define USER_SPEED_CAP_MAX_Hz            (600.0f)

//! \brief Defines the pulse capture wait delay time
#define USER_CAP_WAIT_TIME_SET           (200U)     // 0.2s/1ms

//! \brief Defines the switch signal wait delay time
#define USER_SWITCH_WAIT_TIME_SET        (50U)      // 0.05s/1ms


// **************************************************************************
// the typedefs


// **************************************************************************
// the globals


// **************************************************************************
// the functions

//! \brief      Sets the user parameter values
//! \param[in]  pUserParams  The pointer to the user param structure
extern void USER_setParams(USER_Params *pUserParams);


//! \brief      Sets the private user parameter values
//! \param[in]  pUserParams  The pointer to the user param structure
extern void USER_setParams_priv(USER_Params *pUserParams);


//! \brief      Sets the private user parameter values
//! \param[in]  pUserParams  The pointer to the user param structure
extern void cla_USER_setParams_priv(USER_Params *pUserParams);


#ifdef __cplusplus
}
#endif // extern "C"

//@}  // ingroup
#endif // end of USER_H definition

