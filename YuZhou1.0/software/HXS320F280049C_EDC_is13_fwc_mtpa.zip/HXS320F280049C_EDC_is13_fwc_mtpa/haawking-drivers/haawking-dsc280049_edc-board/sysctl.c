//###########################################################################
//
// FILE:   sysctl.c
//
// TITLE:  H28x system control driver.
//
//###########################################################################
// $HAAWKING Release: Hal Driver Support Library V1.0.0 $
// $Release Date: 2023-04-28 06:49:27 $
// $Copyright:
// Copyright (C) 2019-2023 Beijing Haawking Technology Co.,Ltd - http://www.haawking.com/
//###########################################################################


#include "sysctl.h"
#include "dcc.h"
#include "device.h"

//
// Macro used for adding delay between 2 consecutive writes to CLKSRCCTL1
// register.
// Delay = 300 NOPs
//
#define SYSCTL_CLKSRCCTL1_DELAY  asm volatile(".align 2;\n RPTI 300, 4;\n NOP");


//*****************************************************************************
//
// SysCtl_pollX1Counter()
//
//*****************************************************************************
static bool
SysCtl_pollX1Counter(void)
{
    uint16_t loopCount = 0U;
    uint32_t localCounter = 0U;
    bool status = false;

    //
    // Delay for 1 ms while the XTAL powers up
    //
    // 2000 loops, 5 cycles per loop + 9 cycles overhead = 10009 cycles
    //
    SysCtl_delay(2000);

    //
    // Clear and saturate X1CNT 4 times to guarantee operation
    //
    do
    {
        //
        // Keep clearing the counter until it is no longer saturated
        //
        while(HWREG(CLKCFG_BASE + SYSCTL_O_X1CNT) > 0x1FFU)
        {
            HWREG(CLKCFG_BASE + SYSCTL_O_X1CNT) |= SYSCTL_X1CNT_CLR;
        }

        //
        // Wait for the X1 clock to saturate
        //
        while(HWREG(CLKCFG_BASE + SYSCTL_O_X1CNT) != SYSCTL_X1CNT_X1CNT_M)
        {
            //
            // If your application is stuck in this loop, please check if the
            // input clock source is valid.
            //
            localCounter++;
            if(localCounter>2500000U)
            {
                if(loopCount == 3U)
                {
                    status = false;
                }
                break;
            }
        }

        if(loopCount == 3U &&
           (HWREG(CLKCFG_BASE + SYSCTL_O_X1CNT) == SYSCTL_X1CNT_X1CNT_M))
        {
            status = true;
        }
        //
        // Increment the counter
        //
        loopCount++;
        localCounter = 0U;
    }while(loopCount < 4U);

    return status;
}

//*****************************************************************************
//
// SysCtl_getClock()
//
//*****************************************************************************
uint32_t
SysCtl_getClock(uint32_t clockInHz)
{
    uint32_t temp;
    uint32_t oscSource;
    uint32_t clockOut;

    //
    // Don't proceed if an MCD failure is detected.
    //
    if(SysCtl_isMCDClockFailureDetected())
    {
        //
        // OSCCLKSRC2 failure detected. Returning the INTOSC1 rate. You need
        // to handle the MCD and clear the failure.
        //
        clockOut = SYSCTL_DEFAULT_OSC_FREQ;
    }
    else
    {
        //
        // If one of the internal oscillators is being used, start from the
        // known default frequency.  Otherwise, use clockInHz parameter.
        //
        oscSource = HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &
                    (uint32_t)SYSCTL_CLKSRCCTL1_OSCCLKSRCSEL_M;

        if((oscSource == ((uint32_t)SYSCTL_OSCSRC_OSC2 >> SYSCTL_OSCSRC_S)) ||
           (oscSource == ((uint32_t)SYSCTL_OSCSRC_OSC1 >> SYSCTL_OSCSRC_S)))
        {
            clockOut = SYSCTL_DEFAULT_OSC_FREQ;
        }
        else
        {
            clockOut = clockInHz;
        }

        //
        // If the PLL is enabled calculate its effect on the clock
        //
        if((HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) &
            (SYSCTL_SYSPLLCTL1_PLLEN | SYSCTL_SYSPLLCTL1_PLLCLKEN)) == 3U)
        {
        	//
        	// Calculate integer multiplier
        	//
        	clockOut = clockOut * ((HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLMULT) &
        	                                  SYSCTL_SYSPLLMULT_IMULT_M) >>
        	                                   SYSCTL_SYSPLLMULT_IMULT_S);
            //
            // Calculate PLL divider
            //
            temp = (((HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLMULT) &
                        SYSCTL_SYSPLLMULT_REFDIV_M) >>
                       SYSCTL_SYSPLLMULT_REFDIV_S) *
                     (HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLMULT) &
                        SYSCTL_SYSPLLMULT_ODIV_M) >>
                       SYSCTL_SYSPLLMULT_ODIV_S);

             //
             //  Divide dividers
             //
             if(temp != 0U)
             {
                 clockOut /= temp;
             }
        }

        if((HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) &
            SYSCTL_SYSCLKDIVSEL_PLLSYSCLKDIV_M) != 0U)
        {
            clockOut /= (2U * (HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) &
                               SYSCTL_SYSCLKDIVSEL_PLLSYSCLKDIV_M));
        }
    }

    return(clockOut);
}

//*****************************************************************************
//
// SysCtl_setClock()
//
//*****************************************************************************
bool
SysCtl_setClock(uint32_t config)
{
	uint32_t divSel, pllen;
    uint32_t pllMultTarget;
    uint32_t pllMultCurrent;
    uint32_t pllLockStatus;
	uint32_t retries = 0U, oscSource;
    uint32_t timeout;
    bool status = false;

    //
    // Check the arguments.
    //
    ASSERT((config & SYSCTL_OSCSRC_M) <= SYSCTL_OSCSRC_M);

    //
    // Don't proceed to the PLL initialization if an MCD failure is detected.
    //
    if(SysCtl_isMCDClockFailureDetected())
    {
        //
        // OSCCLKSRC2 failure detected. Returning false. You'll need to clear
        // the MCD error.
        //
        status = false;
    }
    else
    {
        //
        // Bypass PLL
        //
        EALLOW;
        HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) &=
            ~SYSCTL_SYSPLLCTL1_PLLCLKEN;
        EDIS;

        //
        // Delay required post PLL bypass
        //
        SysCtl_delay(11U);

        //
		// Configure oscillator source
		//
		oscSource = config & SYSCTL_OSCSRC_M;
		SysCtl_selectOscSource(oscSource);

        //
        // Get the PLL multiplier settings from config
        //
        pllMultTarget  = ((config & SYSCTL_SYSPLLMULT_IMULT_M) <<
        		             SYSCTL_SYSPLLMULT_IMULT_S);

        pllMultTarget |= (((config & SYSCTL_REFDIV_M) >>
                        SYSCTL_REFDIV_S) <<
                        SYSCTL_SYSPLLMULT_REFDIV_S);

        pllMultTarget |= (((config & SYSCTL_ODIV_M) >>
                        SYSCTL_ODIV_S) <<
                        SYSCTL_SYSPLLMULT_ODIV_S);

        pllMultTarget |= (((config & SYSCTL_VCO_M) >>
             		    SYSCTL_VCO_S) <<
             		    SYSCTL_SYSPLLMULT_VCO_S);

        //
        // Get the PLL multipliers currently programmed
        //
        pllMultCurrent  = HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLMULT);

        pllen = (HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) &
                 SYSCTL_SYSPLLCTL1_PLLEN);

        //
        // Lock PLL only if the multipliers need an update or PLL needs
        // to be powered on / enabled
        //
        if((pllMultCurrent !=  pllMultTarget) || (pllen != 1U))
        {
            //
            // Configure PLL if enabled
            //
        	if((config & SYSCTL_PLL_ENABLE) == SYSCTL_PLL_ENABLE)
        	{
        		//
				// Set dividers to /1
				//
				EALLOW;
				HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) = 0U;
				EDIS;

				//
				// Loop to retry locking the PLL should the DCC module
				// indicate that it was not successful.
				//
				// If a maximum retry count is required at the system level
				// it can be added here according to the maximum system allowed
				// time for PLL locking.  In this case there should be an error
				// handler at the system level for PLL lock failure. The largest
				// possible timeout should be used.
				// Uncomment the while loop to have a limit for retry count and
				// comment the for loop.
				//while(retries < SYSCTL_PLL_RETRIES)
				for(;;)
				{
					//
					// Turn off PLL
					//
					EALLOW;
					HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) &=
						~SYSCTL_SYSPLLCTL1_PLLEN;

                    //
                    // Delay required between
                    // powerdown to powerup of PLL
                    //
                    SysCtl_delay(11U);
					
					//
					// Write multiplier, which automatically turns on the PLL
					//
					HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLMULT) = pllMultTarget;

					//
					// Enable/ turn on PLL
					//
					HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) |=
						   SYSCTL_SYSPLLCTL1_PLLEN;

					//
					// Wait for the SYSPLL lock counter or a timeout
					//
					timeout = SYSCTL_PLLLOCK_TIMEOUT;
					pllLockStatus = HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLSTS) &
					                                SYSCTL_SYSPLLSTS_LOCKS;

					while((pllLockStatus != 1U) && (timeout != 0U))
					{
						pllLockStatus = HWREG(CLKCFG_BASE +
						                      SYSCTL_O_SYSPLLSTS) &
										SYSCTL_SYSPLLSTS_LOCKS;
						timeout--;
					}
					EDIS;

					//
					// Check PLL Frequency using DCC
					//
				   status = SysCtl_isPLLValid(oscSource,
						                                 (config & (SYSCTL_IMULT_M |
						                                		         SYSCTL_ODIV_M |
									                                     SYSCTL_REFDIV_M)));

				   //
				   // Check DCC Status, if no error break the loop
				   //
				   if(status)
				   {
					   break;
				   }
				   retries++;
				}
            }
            else
            {
                status = true;
            }
        }
        else if((config & SYSCTL_PLL_CONFIG_M) == SYSCTL_PLL_DISABLE)
        {
            //
            // Turn off PLL when the PLL is disabled in config
            //
            EALLOW;
            HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) &=
                   ~SYSCTL_SYSPLLCTL1_PLLEN;
            EDIS;

            //
            // PLL is bypassed and not in use
            // Status is updated to true to allow configuring the dividers later
            //
            status = true;
        }
        else
        {
        	status = true;
        }

        //
        // If PLL locked successfully, configure the dividers
        //
        if(status)
        {
        	//
			// Set divider to produce slower output frequency to limit current
			// increase.
			//
			divSel = (config & SYSCTL_SYSDIV_M) >> SYSCTL_SYSDIV_S;

			EALLOW;
			if(divSel != (126U / 2U))
			{
				HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) =
					(HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) &
					 ~(uint16_t)SYSCTL_SYSCLKDIVSEL_PLLSYSCLKDIV_M) |
					(divSel + 1U);
			}
			else
			{
				HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) =
					(HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) &
					 ~(uint16_t)SYSCTL_SYSCLKDIVSEL_PLLSYSCLKDIV_M) | divSel;
			}

			EDIS;

			//
			// Enable PLLSYSCLK is fed from system PLL clock
			//
			EALLOW;
			HWREG(CLKCFG_BASE + SYSCTL_O_SYSPLLCTL1) |=
				SYSCTL_SYSPLLCTL1_PLLCLKEN;
			EDIS;

			//
			// Delay to allow voltage regulator to stabilize
			// prior to increasing entire system clock frequency.
			//
			SysCtl_delay(40U);

			//
			// Set the divider to user value
			//
			EALLOW;
			HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) =
				(HWREG(CLKCFG_BASE + SYSCTL_O_SYSCLKDIVSEL) &
				 ~SYSCTL_SYSCLKDIVSEL_PLLSYSCLKDIV_M) | divSel;
			EDIS;
        }
        else
        {
            ESTOP0; // If the frequency is out of range, stop here.
        }
    }

    return(status);
}

//*****************************************************************************
//
// SysCtl_selectXTAL()
//
//*****************************************************************************
void
SysCtl_selectXTAL(void)
{
    bool status = false;
    uint32_t loopCount = 0U;

    EALLOW;

    //
    // Turn on XTAL and select crystal mode
    //
    HWREG(CLKCFG_BASE + SYSCTL_O_XTALCR) &= ~SYSCTL_XTALCR_OSCOFF;
    HWREG(CLKCFG_BASE + SYSCTL_O_XTALCR) &= ~SYSCTL_XTALCR_SE;
    EDIS;

    //
    // Wait for the X1 clock to saturate
    //
    status = SysCtl_pollX1Counter();

    //
    // Select XTAL as the oscillator source
    //
    EALLOW;
    HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) =
    ((HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &
      (~SYSCTL_CLKSRCCTL1_OSCCLKSRCSEL_M)) |
     ((uint32_t)SYSCTL_OSCSRC_XTAL >> SYSCTL_OSCSRC_S));
    EDIS;

    //
    // If a missing clock failure was detected, try waiting for the X1 counter
    // to saturate again. Consider modifying this code to add a 10ms timeout.
    //
    while(SysCtl_isMCDClockFailureDetected() && (status == false) &&
          (loopCount < 4U))
    {
        //
        // Clear the MCD failure
        //
        SysCtl_resetMCD();

        //
        // Wait for the X1 clock to saturate
        //
        status = SysCtl_pollX1Counter();

        //
        // Select XTAL as the oscillator source
        //
        EALLOW;
        HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) =
        ((HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &
          (~SYSCTL_CLKSRCCTL1_OSCCLKSRCSEL_M)) |
         ((uint32_t)SYSCTL_OSCSRC_XTAL >> SYSCTL_OSCSRC_S));
        EDIS;
        loopCount ++;
    }
    while(status == false)
    {         
        // If code is stuck here, it means crystal has not started.  
        //Replace crystal or update code below to take necessary actions if 
        //crystal is bad         
        ESTOP0;     
    }
}

//*****************************************************************************
//
// SysCtl_selectXTALSingleEnded()
//
//*****************************************************************************
void
SysCtl_selectXTALSingleEnded(void)
{
    bool status = false;
    
    //
    // Turn on XTAL and select single-ended mode.
    //
    EALLOW;
    HWREG(CLKCFG_BASE + SYSCTL_O_XTALCR) &= ~SYSCTL_XTALCR_OSCOFF;
    HWREG(CLKCFG_BASE + SYSCTL_O_XTALCR) |= SYSCTL_XTALCR_SE;
    EDIS;

    //
    // Wait for the X1 clock to saturate
    //
    status = SysCtl_pollX1Counter();

    //
    // Select XTAL as the oscillator source
    //
    EALLOW;
    HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) =
    ((HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &
      (~SYSCTL_CLKSRCCTL1_OSCCLKSRCSEL_M)) |
     ((uint32_t)SYSCTL_OSCSRC_XTAL >> SYSCTL_OSCSRC_S));
    EDIS;

    //
    // Something is wrong with the oscillator module. Replace the ESTOP0 with
    // an appropriate error-handling routine.
    //
    while(SysCtl_isMCDClockFailureDetected() && (status == false))
    {
        // If code is stuck here, it means crystal has not started.  
        //Replace crystal or update code below to take necessary actions if 
        //crystal is bad 
        ESTOP0;
    }
}

//*****************************************************************************
//
// SysCtl_selectOscSource()
//
//*****************************************************************************
void
SysCtl_selectOscSource(uint32_t oscSource)
{
    ASSERT((oscSource == SYSCTL_OSCSRC_OSC1) ||
           (oscSource == SYSCTL_OSCSRC_OSC2) ||
           (oscSource == SYSCTL_OSCSRC_XTAL) ||
           (oscSource == SYSCTL_OSCSRC_XTAL_SE));

    //
    // Select the specified source.
    //
    EALLOW;
    switch(oscSource)
    {
        case SYSCTL_OSCSRC_OSC2:
            //
            // Turn on INTOSC2
            //
            HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &=
                ~SYSCTL_CLKSRCCTL1_INTOSC2OFF;

            SYSCTL_CLKSRCCTL1_DELAY;

            //
            // Clk Src = INTOSC2
            //
            HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &=
                ~SYSCTL_CLKSRCCTL1_OSCCLKSRCSEL_M;

            break;

        case SYSCTL_OSCSRC_XTAL:
            //
            // Select XTAL in crystal mode and wait for it to power up
            //
            SysCtl_selectXTAL();
            break;

        case SYSCTL_OSCSRC_XTAL_SE:
            //
            // Select XTAL in single-ended mode and wait for it to power up
            //
            SysCtl_selectXTALSingleEnded();
            break;

        case SYSCTL_OSCSRC_OSC1:
            //
            // Clk Src = INTOSC1
            //
            HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) =
                   (HWREG(CLKCFG_BASE + SYSCTL_O_CLKSRCCTL1) &
                    ~SYSCTL_CLKSRCCTL1_OSCCLKSRCSEL_M) |
                   ((uint32_t)SYSCTL_OSCSRC_OSC1 >> SYSCTL_OSCSRC_S);

            break;

        default:
            //
            // Do nothing. Not a valid oscSource value.
            //
            break;
    }
    EDIS;
}

//*****************************************************************************
//
// SysCtl_getLowSpeedClock()
//
//*****************************************************************************
uint32_t
SysCtl_getLowSpeedClock(uint32_t clockInHz)
{
    uint32_t clockOut;

    //
    // Get the main system clock
    //
    clockOut = SysCtl_getClock(clockInHz);

    //
    // Apply the divider to the main clock
    //
    if((HWREG(CLKCFG_BASE + SYSCTL_O_LOSPCP) &
        SYSCTL_LOSPCP_LSPCLKDIV_M) != 0U)
    {
        clockOut /= (2U * (HWREG(CLKCFG_BASE + SYSCTL_O_LOSPCP) &
                            SYSCTL_LOSPCP_LSPCLKDIV_M));
    }

    return(clockOut);
}

//*****************************************************************************
//
// SysCtl_getDeviceParametric()
//
//*****************************************************************************
uint32_t
SysCtl_getDeviceParametric(SysCtl_DeviceParametric parametric)
{
    uint32_t value;

    //
    // Get requested parametric value
    //
    switch(parametric)
    {
        case SYSCTL_DEVICE_QUAL:
            //
            // Qualification Status
            //
            value = ((HWREG(0x6827B4) &
                      SYSCTL_PARTIDL_QUAL_M) >> SYSCTL_PARTIDL_QUAL_S);
            break;

        case SYSCTL_DEVICE_PINCOUNT:
            //
            // Pin Count
            //
            value = ((HWREG(0x6827B4) &
                      SYSCTL_PARTIDL_PIN_COUNT_M) >>
                     SYSCTL_PARTIDL_PIN_COUNT_S);
            break;

        case SYSCTL_DEVICE_INSTASPIN:
            //
            // InstaSPIN Feature Set
            //
            value = ((HWREG(0x6827B4) &
                      SYSCTL_PARTIDL_INSTASPIN_M) >>
                     SYSCTL_PARTIDL_INSTASPIN_S);
            break;

        case SYSCTL_DEVICE_FLASH:
            //
            // Flash Size (KB)
            //
            value = ((HWREG(0x6827B4) &
                      SYSCTL_PARTIDL_FLASH_SIZE_M) >>
                     SYSCTL_PARTIDL_FLASH_SIZE_S);
            break;

        case SYSCTL_DEVICE_FAMILY:
            //
            // Device Family
            //
            value = ((HWREG(0x6827B0) &
                      SYSCTL_PARTIDH_FAMILY_M) >> SYSCTL_PARTIDH_FAMILY_S);
            break;

        case SYSCTL_DEVICE_PARTNO:
            //
            // Part Number
            //
            value = ((HWREG(0x6827B0) &
                      SYSCTL_PARTIDH_PARTNO_M) >> SYSCTL_PARTIDH_PARTNO_S);
            break;

        case SYSCTL_DEVICE_CLASSID:
            //
            // Class ID
            //
            value = ((HWREG(0x6827B0) &
                      SYSCTL_PARTIDH_DEVICE_CLASS_ID_M) >>
                     SYSCTL_PARTIDH_DEVICE_CLASS_ID_S);
            break;

        default:
            //
            // Not a valid value for PARTID register
            //
            value = 0U;
            break;
    }

    return(value);
}

//*****************************************************************************
//
// SysCtl_isPLLValid()
//
//*****************************************************************************
bool
SysCtl_isPLLValid(uint32_t oscSource,uint32_t pllMultDiv)
{
    uint32_t imult, odiv, refdiv, base;
    float  fclk1_0ratio;

    DCC_Count0ClockSource dccClkSrc0;
    DCC_Count1ClockSource dccClkSrc1;
    uint32_t dccCounterSeed0, dccCounterSeed1, dccValidSeed0;

    switch(oscSource)
    {
        case SYSCTL_OSCSRC_OSC2:
            //
            // Select DCC Clk Src0 as INTOSC2
            //
            dccClkSrc0 = DCC_COUNT0SRC_INTOSC2;
            break;
        case SYSCTL_OSCSRC_XTAL:
        case SYSCTL_OSCSRC_XTAL_SE:
            //
            // Select DCC Clk Src0 as XTAL
            //
            dccClkSrc0 = DCC_COUNT0SRC_XTAL;
            break;
        case SYSCTL_OSCSRC_OSC1:
            //
            // Select DCC Clk Src0 as INTOSC1
            //
            dccClkSrc0 = DCC_COUNT0SRC_INTOSC1;
            break;
        default:
            //
            // Select DCC Clk Src0 as INTOSC1
            //
            dccClkSrc0 = DCC_COUNT0SRC_INTOSC1;
            break;
    }

    //
    // Select DCC Clk Src1 as SYSPLL
    //
    dccClkSrc1 = DCC_COUNT1SRC_PLL;

    //
    // Assigning DCC for PLL validation
    //
    base = DCC0_BASE;

    //
    // Retrieving PLL parameters
    //
    imult = pllMultDiv & SYSCTL_IMULT_M;
    odiv = (pllMultDiv & SYSCTL_ODIV_M) >> SYSCTL_ODIV_S;
    refdiv = (pllMultDiv & SYSCTL_REFDIV_M) >> SYSCTL_REFDIV_S;

    fclk1_0ratio = (float)imult / (odiv * refdiv);

	dccCounterSeed1 = 100000;
	dccCounterSeed0 = (uint32_t)(dccCounterSeed1/1.03/fclk1_0ratio);
	dccValidSeed0 = (uint32_t)(dccCounterSeed1*1.03/fclk1_0ratio) - dccCounterSeed0;

    //
    // Enable peripheral clock to DCC
    //
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_DCC0);

    //
    // Clear Error & Done Flag
    //
    DCC_clearErrorFlag(base);
    DCC_clearDoneFlag(base);

    //
    // Disable DCC
    //
    DCC_disableModule(base);

    //
    // Disable Error Signal
    //
    DCC_disableErrorSignal(base);

    //
    // Disable Done Signal
    //
    DCC_disableDoneSignal(base);

    //
    // Configure Clock Source0 to whatever set as a clock source for PLL
    //
    DCC_setCounter0ClkSource(base, dccClkSrc0);

    //
    // Configure Clock Source1 to PLL
    //
    DCC_setCounter1ClkSource(base, dccClkSrc1);

    //
    // Configure COUNTER-0, COUNTER-1 & Valid Window
    //
    DCC_setCounterSeeds(base, dccCounterSeed0, dccValidSeed0,
                        dccCounterSeed1);

    //
    // Enable Single Shot mode
    //
    DCC_enableSingleShotMode(base, DCC_MODE_COUNTER_ZERO);

    //
    // Enable Error Signal
    //
    DCC_enableErrorSignal(base);

    //
    // Enable Done Signal
    //
    DCC_enableDoneSignal(base);

    //
    // Enable DCC to start counting
    //
    DCC_enableModule(base);

    //
    // Timeout for the loop
    //
    uint32_t timeout = dccCounterSeed1;

    //
    // Wait until Error or Done Flag is generated
    //
    while(((HWREG(base + DCC_O_STATUS) &
            (DCC_STATUS_ERR | DCC_STATUS_DONE)) == 0U) && (timeout != 0U))

    {
        timeout--;
    }

    //
    // Returns true if DCC completes without error
    //

    return(((HWREG(base + DCC_O_STATUS) &
            (DCC_STATUS_ERR | DCC_STATUS_DONE)) == DCC_STATUS_DONE) &&
            (HWREG(base + DCC_O_CNT0) == 0U));
}

